func test_WhenRemoveCookiesForDomains_ThenUnaffectedLeftBehind() async {
        let dataStore = await WKWebsiteDataStore.default()
        await dataStore.httpCookieStore.setCookie(.make(name: "Test1", value: "Value", domain: "example.com"))
        await dataStore.httpCookieStore.setCookie(.make(name: "Test4", value: "Value", domain: "sample.com"))
        await dataStore.httpCookieStore.setCookie(.make(name: "Test2", value: "Value", domain: ".example.com"))
        await dataStore.httpCookieStore.setCookie(.make(name: "Test3", value: "Value", domain: "facebook.com"))

        var cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(4, cookies.count)

        let webCacheManager = await makeWebCacheManager()
        await webCacheManager.removeCookies(forDomains: ["example.com", "sample.com"], fromDataStore: dataStore)

        cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(1, cookies.count)
        XCTAssertTrue(cookies.contains(where: { $0.domain == "facebook.com" }))
    }
