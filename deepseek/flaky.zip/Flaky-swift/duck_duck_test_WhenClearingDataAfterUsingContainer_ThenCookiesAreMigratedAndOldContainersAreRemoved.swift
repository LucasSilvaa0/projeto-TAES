func test_WhenClearingDataAfterUsingContainer_ThenCookiesAreMigratedAndOldContainersAreRemoved() async {
        // Mock having a single container so we can validate cleaning it gets called
        dataStoreCleaner.countContainersReturnValue = 1

        // Mock a data store id to force migration to happen
        keyValueStore.store = [DataStoreIDManager.Constants.currentWebContainerID.rawValue: UUID().uuidString]
        dataStoreIDManager = DataStoreIDManager(store: keyValueStore)

        fireproofing = MockFireproofing(domains: ["example.com"])

        MigratableCookieStorage.addCookies([
            .make(name: "Test1", value: "Value", domain: "example.com"),
            .make(name: "Test2", value: "Value", domain: ".example.com"),
            .make(name: "Test3", value: "Value", domain: "facebook.com"),
        ], keyValueStore)

        let dataStore = await WKWebsiteDataStore.default()
        var cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(0, cookies.count)

        let webCacheManager = await makeWebCacheManager()
        await webCacheManager.clear(dataStore: dataStore)

        cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(2, cookies.count)
        XCTAssertTrue(cookies.contains(where: { $0.domain == "example.com" }))
        XCTAssertTrue(cookies.contains(where: { $0.domain == ".example.com" }))

        XCTAssertEqual(1, dataStoreCleaner.removeAllContainersAfterDelayCalls.count)
        XCTAssertEqual(1, dataStoreCleaner.removeAllContainersAfterDelayCalls[0])
    }
