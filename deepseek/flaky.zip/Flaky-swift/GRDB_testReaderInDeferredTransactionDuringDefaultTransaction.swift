func testReaderInDeferredTransactionDuringDefaultTransaction() throws {
        let dbQueue1 = try makeDatabaseQueue()
        #if GRDBCIPHER_USE_ENCRYPTION
            // Work around SQLCipher bug when two connections are open to the
            // same empty database: make sure the database is not empty before
            // running this test
            try dbQueue1.inDatabase { db in
                try db.execute("CREATE TABLE SQLCipherWorkAround (foo INTEGER)")
            }
        #endif
        let dbQueue2 = try makeDatabaseQueue()
        
        // The `SELECT * FROM stuffs` statement of Queue 2 prevents Queue 1
        // from committing with SQLITE_BUSY.
        //
        // Without this select, the Queue 2 COMMIT succeeds right away.
        //
        // Both facts are unexpected.
        //
        //
        // Queue 1                              Queue 2
        // BEGIN IMMEDIATE TRANSACTION
        // INSERT INTO stuffs (id) VALUES (NULL)
        let s1 = DispatchSemaphore(value: 0)
        //                                      BEGIN DEFERRED TRANSACTION
        //                                      SELECT * FROM stuffs
        let s2 = DispatchSemaphore(value: 0)
        // COMMIT <--- Busy
        let s3 = DispatchSemaphore(value: 0)
        //                                      COMMIT
        // COMMIT
        
        var numberOfTries = 0
        self.busyCallback = { n in
            numberOfTries = n
            s3.signal()
            return true
        }
        
        try dbQueue1.inDatabase { db in
            try db.execute("CREATE TABLE stuffs (id INTEGER PRIMARY KEY)")
        }
        
        let queue = DispatchQueue(label: "GRDB", attributes: [.concurrent])
        let group = DispatchGroup()
        
        // Queue 1
        queue.async(group: group) {
            do {
                try dbQueue1.inTransaction { db in
                    try db.execute("INSERT INTO stuffs (id) VALUES (NULL)")
                    s1.signal()
                    _ = s2.wait(timeout: .distantFuture)
                    return .commit
                }
            }
            catch {
                XCTFail("\(error)")
            }
        }
        
        // Queue 2
        queue.async(group: group) {
            do {
                _ = s1.wait(timeout: .distantFuture)
                try dbQueue2.inTransaction(.deferred) { db in
                    _ = try Row.fetchAll(db, "SELECT * FROM stuffs")
                    s2.signal()
                    _ = s3.wait(timeout: .distantFuture)
                    return .commit
                }
            }
            catch {
                XCTFail("\(error)")
            }
        }
        
        _ = group.wait(timeout: .distantFuture)
        
        // TODO: flaky test
        // https://travis-ci.org/groue/GRDB.swift/jobs/236100291
        // https://travis-ci.org/groue/GRDB.swift/jobs/236100305
        XCTAssertTrue(numberOfTries > 0)    // Busy handler has been used.
    }
