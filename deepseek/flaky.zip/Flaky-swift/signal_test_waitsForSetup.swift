func test_waitsForSetup() {
        let message: TSOutgoingMessage = OutgoingMessageFactory().create()

        let sentBeforeReadyExpectation = sentExpectation(message: message)
        sentBeforeReadyExpectation.isInverted = true

        let jobQueue = MessageSenderJobQueue()

        self.write { transaction in
            jobQueue.add(message: message.asPreparer, transaction: transaction)
        }

        self.wait(for: [sentBeforeReadyExpectation], timeout: 0.1)

        let sentAfterReadyExpectation = sentExpectation(message: message)

        jobQueue.setup()

        self.wait(for: [sentAfterReadyExpectation], timeout: 0.1)
    }
