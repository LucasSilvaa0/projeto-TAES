func testBusyCallback() throws {
        let dbQueue1 = try makeDatabaseQueue()
        #if GRDBCIPHER_USE_ENCRYPTION
            // Work around SQLCipher bug when two connections are open to the
            // same empty database: make sure the database is not empty before
            // running this test
            try dbQueue1.inDatabase { db in
                try db.execute("CREATE TABLE SQLCipherWorkAround (foo INTEGER)")
            }
        #endif
        let dbQueue2 = try makeDatabaseQueue()
        
        // Queue 1                              Queue 2
        // BEGIN EXCLUSIVE TRANSACTION
        let s1 = DispatchSemaphore(value: 0)
        // (Waiting)                            BEGIN EXCLUSIVE TRANSACTION <--- Busy
        // (Waiting)                            BEGIN EXCLUSIVE TRANSACTION <--- Busy
        // (Waiting)                            BEGIN EXCLUSIVE TRANSACTION <--- Busy
        // COMMIT
        //                                      BEGIN EXCLUSIVE TRANSACTION
        //                                      COMMIT
        
        var numberOfTries = 0
        self.busyCallback = { n in
            numberOfTries = n
            usleep(10_000) // 0.01s
            return true
        }
        
        let queue = DispatchQueue(label: "GRDB", attributes: [.concurrent])
        let group = DispatchGroup()
        
        // Queue 1
        queue.async(group: group) {
            do {
                try dbQueue1.inTransaction(.exclusive) { db in
                    s1.signal()
                    usleep(100_000) // 0.1s
                    return .commit
                }
            }
            catch {
                XCTFail("\(error)")
            }
        }
        
        // Queue 2
        queue.async(group: group) {
            do {
                _ = s1.wait(timeout: .distantFuture)
                try dbQueue2.inTransaction(.exclusive) { db in
                    return .commit
                }
            }
            catch {
                XCTFail("\(error)")
            }
        }
        
        _ = group.wait(timeout: .distantFuture)
        
        XCTAssertTrue(numberOfTries > 0)    // Busy handler has been used.
    }
