func testWhenRecentlyStartedImportAndSyncAuthStateIsActiveAndHasNotSyncedDesktopDeviceThenNoPixelFired() async {

        appSettings.autofillImportViaSyncStart = Date()
        syncService.authState = .active
        syncService.registeredDevices = []

        let importPasswordsStatusHandler = TestImportPasswordsStatusHandler.init(appSettings: appSettings, syncService: syncService)
        let expectation = XCTestExpectation(description: "CheckSyncSuccessStatus completes")

        importPasswordsStatusHandler.checkSyncSuccessStatus()

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
              expectation.fulfill()
        }

        await fulfillment(of: [expectation], timeout: 2.0)

        XCTAssertNil(importPasswordsStatusHandler.lastFiredPixel)
        XCTAssertNotNil(appSettings.autofillImportViaSyncStart)
    }
