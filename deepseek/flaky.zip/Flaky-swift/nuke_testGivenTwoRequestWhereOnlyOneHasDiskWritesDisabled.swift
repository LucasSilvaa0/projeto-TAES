    func testGivenTwoRequestWhereOnlyOneHasDiskWritesDisabled() {
        // WHEN
        pipeline.registerMultipleRequests {
            request.options.insert(.disableDiskCacheWrites)
            expect(pipeline).toLoadImage(with: request)
            request.options.remove(.disableDiskCacheWrites)
            expect(pipeline).toLoadImage(with: request)
        }
        wait()

        // THEN
        XCTAssertEqual(imageCache.readCount, 6) // Processed + intermediate + original
        XCTAssertEqual(imageCache.writeCount, 2) // Processed
        XCTAssertNotNil(imageCache[request])
        XCTAssertEqual(dataCache.readCount, 4) // Processed + original
        XCTAssertEqual(dataCache.writeCount, 1)
        XCTAssertEqual(dataLoader.createdTaskCount, 1)
    }

