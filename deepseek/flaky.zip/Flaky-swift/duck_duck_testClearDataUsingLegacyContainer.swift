@MainActor
    func testClearDataUsingLegacyContainer() async throws {

        // Using WKWebsiteDataStore(forIdentifier:) doesn't persist cookies in a testable way, so use the legacy container here.
        let fireproofing = UserDefaultsFireproofing.xshared
        fireproofing.clearAll()
        
        for site in testData.fireButtonFireproofing.fireproofedSites {
            let sanitizedSite = sanitizedSite(site)
            print("Adding %s to fireproofed sites", sanitizedSite)
            fireproofing.addToAllowed(domain: sanitizedSite)
        }
        
        let referenceTests = testData.fireButtonFireproofing.tests.filter {
            $0.exceptPlatforms.contains("ios-browser") == false
        }

        for test in referenceTests {
            let cookie = try XCTUnwrap(cookie(for: test))

            let warmupCompleted = XCTestExpectation(description: "Warmup Completed")
            let warmup = WebViewWarmupHelper()
            warmup.warmupWebView(expectation: warmupCompleted)

            await fulfillment(of: [warmupCompleted], timeout: 5)

            let dataStore = WKWebsiteDataStore.default()
            let cookieStore = dataStore.httpCookieStore
            await cookieStore.setCookie(cookie)

            await WebCacheManager(cookieStorage: MigratableCookieStorage(), fireproofing: fireproofing, dataStoreIDManager: DataStoreIDManager(store: MockKeyValueStore())).clear(dataStore: dataStore)

            let testCookie = await cookieStore.allCookies().filter { $0.name == test.cookieName }.first

            if test.expectCookieRemoved {
                XCTAssertNil(testCookie, "Cookie should not exist for test: \(test.name)")
            } else {
                XCTAssertNotNil(testCookie, "Cookie should exist for test: \(test.name)")
            }
            
            // Reset cache
            // cookieStorage.cookies = []
        }

    }
