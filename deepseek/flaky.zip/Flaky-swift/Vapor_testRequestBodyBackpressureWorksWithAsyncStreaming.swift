func testRequestBodyBackpressureWorksWithAsyncStreaming() async throws {
        app.http.server.configuration.hostname = "127.0.0.1"
        app.http.server.configuration.port = 0
        
        let numberOfTimesTheServerGotOfferedBytes = ManagedAtomic<Int>(0)
        let bytesTheServerSaw = ManagedAtomic<Int>(0)
        let bytesTheClientSent = ManagedAtomic<Int>(0)
        let serverSawEnd = ManagedAtomic<Bool>(false)
        let serverSawRequest = ManagedAtomic<Bool>(false)
        
        let requestHandlerTask: NIOLockedValueBox<Task<Response, Error>?> = .init(nil)
        
        app.on(.POST, "hello", body: .stream) { req async throws -> Response in
            requestHandlerTask.withLockedValue {
                $0 = Task {
                    XCTAssertTrue(serverSawRequest.compareExchange(expected: false, desired: true, ordering: .relaxed).exchanged)
                    var bodyIterator = req.body.makeAsyncIterator()
                    let firstChunk = try await bodyIterator.next() // read only first chunk
                    numberOfTimesTheServerGotOfferedBytes.wrappingIncrement(ordering: .relaxed)
                    bytesTheServerSaw.wrappingIncrement(by: firstChunk?.readableBytes ?? 0, ordering: .relaxed)
                    defer {
                        _ = bodyIterator // make sure to not prematurely cancelling the sequence
                    }
                    try await Task.sleep(nanoseconds: 10_000_000_000) // wait "forever"
                    serverSawEnd.store(true, ordering: .relaxed)
                    return Response(status: .ok)
                }
            }
            
            do {
                let task = requestHandlerTask.withLockedValue { $0 }
                return try await task!.value
            } catch {
                throw Abort(.internalServerError)
            }
        }
        
        app.environment.arguments = ["serve"]
        try await app.startup()
        
        XCTAssertNotNil(app.http.server.shared.localAddress)
        guard let localAddress = app.http.server.shared.localAddress,
              let ip = localAddress.ipAddress,
              let port = localAddress.port else {
            XCTFail("couldn't get ip/port from \(app.http.server.shared.localAddress.debugDescription)")
            return
        }
        
        final class ResponseDelegate: HTTPClientResponseDelegate {
            typealias Response = Void
            
            private let bytesTheClientSent: ManagedAtomic<Int>
            
            init(bytesTheClientSent: ManagedAtomic<Int>) {
                self.bytesTheClientSent = bytesTheClientSent
            }
            
            func didFinishRequest(task: HTTPClient.Task<Response>) throws -> Response {
                return ()
            }
            
            func didSendRequestPart(task: HTTPClient.Task<Response>, _ part: IOData) {
                self.bytesTheClientSent.wrappingIncrement(by: part.readableBytes, ordering: .relaxed)
            }
        }
        
        let tenMB = ByteBuffer(repeating: 0x41, count: 10 * 1024 * 1024)
        let request = try! HTTPClient.Request(url: "http://\(ip):\(port)/hello",
                                              method: .POST,
                                              headers: [:],
                                              body: .byteBuffer(tenMB))
        let delegate = ResponseDelegate(bytesTheClientSent: bytesTheClientSent)
        let httpClient = HTTPClient(eventLoopGroup: MultiThreadedEventLoopGroup.singleton)
        XCTAssertThrowsError(try httpClient.execute(request: request,
                                                                delegate: delegate,
                                                                deadline: .now() + .milliseconds(500)).wait()) { error in
            if let error = error as? HTTPClientError {
                XCTAssert(error == .readTimeout || error == .deadlineExceeded)
            } else {
                XCTFail("unexpected error: \(error)")
            }
        }
        
        XCTAssertEqual(1, numberOfTimesTheServerGotOfferedBytes.load(ordering: .relaxed))
        XCTAssertGreaterThan(tenMB.readableBytes, bytesTheServerSaw.load(ordering: .relaxed))
        XCTAssertGreaterThan(tenMB.readableBytes, bytesTheClientSent.load(ordering: .relaxed))
        XCTAssertEqual(0, bytesTheClientSent.load(ordering: .relaxed)) // We'd only see this if we sent the full 10 MB.
        XCTAssertFalse(serverSawEnd.load(ordering: .relaxed))
        XCTAssertTrue(serverSawRequest.load(ordering: .relaxed))
        
        requestHandlerTask.withLockedValue { $0?.cancel() }
        try await httpClient.shutdown()
    }
