@MainActor
func testThatExpiredCertificateRequestFailsWhenPinningLeafCertificateWithCertificateChainValidation() {
    // Given
    let certificates = [TestCertificates.leaf]
    let evaluators = [expiredHost: PinnedCertificatesTrustEvaluator(certificates: certificates)]
    
    let manager = Session(configuration: configuration,
                          serverTrustManager: ServerTrustManager(evaluators: evaluators))
    
    let expectation = expectation(description: "\(expiredURLString)")
    var error: AFError?
    
    // When
    manager.request(expiredURLString)
        .response { resp in
            error = resp.error
            expectation.fulfill()
        }
    
    waitForExpectations(timeout: timeout)
    
    // Then
    XCTAssertNotNil(error, "error should not be nil")
    XCTAssertEqual(error?.isServerTrustEvaluationError, true)
    
    if case let .serverTrustEvaluationFailed(reason)? = error {
        if #available(iOS 12, macOS 10.14, tvOS 12, watchOS 5, *) {
            XCTAssertTrue(reason.isTrustEvaluationFailed, "should be .trustEvaluationFailed")
        } else {
            XCTAssertTrue(reason.isDefaultEvaluationFailed, "should be .defaultEvaluationFailed")
        }
    } else {
        XCTFail("error should be .serverTrustEvaluationFailed")
    }
}
