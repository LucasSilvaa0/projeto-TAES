  func testLoggedOut_NonBacker_LiveProjectSwitchedToCampaignTab_Success() {
    let config = Config.template
    let project = Project.cosmicSurgery
      |> Project.lens.photo.full .~ ""
      |> (Project.lens.creator.avatar .. User.Avatar.lens.small) .~ ""
      |> Project.lens.personalization.isBacking .~ false
      |> Project.lens.state .~ .live
      |> Project.lens.rewardData.rewards .~ []
      |> \.extendedProjectProperties .~ self.extendedProjectProperties
    orthogonalCombos(Language.allLanguages, [Device.phone4inch, Device.pad]).forEach { language, device in
      withEnvironment(
        config: config,
        language: language
      ) {
        let vc = ProjectPageViewController.configuredWith(
          projectOrParam: .left(project), refInfo: nil
        )
        let (parent, _) = traitControllers(device: device, orientation: .portrait, child: vc)
        parent.view.frame.size.height = device == .pad ? 1_200 : parent.view.frame.size.height
        scheduler.advance()
        // INFO: We are not testing that the navigation selector view changed, simply the content of the view controller.
        vc.projectNavigationSelectorViewDidSelect(ProjectNavigationSelectorView(), index: 1)
        scheduler.run()
        assertSnapshot(
          matching: parent.view,
          as: .image(perceptualPrecision: 0.98),
          named: "lang_\(language)_device_\(device)"
        )
      }
    }
  }
