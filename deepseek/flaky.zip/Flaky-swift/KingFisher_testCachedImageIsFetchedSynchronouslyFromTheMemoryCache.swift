func testCachedImageIsFetchedSynchronouslyFromTheMemoryCache() {
        cache.store(testImage, forKey: testKeys[0], toDisk: false)
        let foundImage = ActorBox<KFCrossPlatformImage?>(nil)
        cache.retrieveImage(forKey: testKeys[0]) { result in
            Task {
                await foundImage.setValue(result.value?.image)
            }
        }
        Task {
            let value = await foundImage.value
            XCTAssertEqual(testImage, value)
        }
    }
