func testOpenLinkFromPDF() {
        navigator.openURL(PDF_website["url"]!)
        waitUntilPageLoad()

        // Click on a link on the pdf and check that the website is shown
        app.links.element(boundBy: 0).tapOnApp()
        waitUntilPageLoad()
        mozWaitForValueContains(app.textFields["url"], value: PDF_website["urlValue"]!)
        XCTAssertTrue(app.staticTexts["Education and schools"].exists)

        // Go back to pdf view
        app.buttons[AccessibilityIdentifiers.Toolbar.backButton].tap()
        mozWaitForValueContains(app.textFields["url"], value: PDF_website["pdfValue"]!)
    }
