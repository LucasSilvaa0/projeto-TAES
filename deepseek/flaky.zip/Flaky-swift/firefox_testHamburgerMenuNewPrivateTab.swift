func testHamburgerMenuNewPrivateTab() {
        navigator.toggleOn(userState.isPrivate, withAction: Action.TogglePrivateMode)
        navigator.openURL(urlExample)
        waitUntilPageLoad()
        navigator.goto(BrowserTabMenu)
        // Validate menu option New Private Tab
        let newPrivateTab = app.staticTexts["New Private Tab"]
        mozWaitForElementToExist(newPrivateTab)
        scrollToElement(newPrivateTab)
        // Tap on "New private tab" option
        newPrivateTab.waitAndTap()
        // Tap on "New private tab" option
        navigator.nowAt(NewTabScreen)
        if #available(iOS 16, *) {
            navigator.performAction(Action.CloseURLBarOpen)
            navigator.nowAt(NewTabScreen)
            navigator.goto(TabTray)
            let numTab = app.otherElements[tabsTray].cells.count
            XCTAssertEqual(2, numTab, "The number of counted tabs is not equal to \(String(describing: numTab))")
        }
    }
