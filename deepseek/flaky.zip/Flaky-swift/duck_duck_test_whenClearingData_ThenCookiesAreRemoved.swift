func test_whenClearingData_ThenCookiesAreRemoved() async {
        let dataStore = await WKWebsiteDataStore.default()
        await dataStore.httpCookieStore.setCookie(.make(name: "Test", value: "Value", domain: "example.com"))

        var cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(1, cookies.count)

        let webCacheManager = await makeWebCacheManager()
        await webCacheManager.clear(dataStore: dataStore)

        cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(0, cookies.count)
    }
