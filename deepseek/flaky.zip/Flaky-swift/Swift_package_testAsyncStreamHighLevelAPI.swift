func testAsyncStreamHighLevelAPI() async throws {
        let result = try await AsyncProcess.popen(
            scriptName: "echo",
            stdout: { stdin, stdout in
                var counter = 0
                stdin.write("Hello \(counter)\n")
                stdin.flush()

                for await output in stdout {
                    XCTAssertEqual(output, .init("Hello \(counter)\n".utf8))
                    counter += 1

                    stdin.write(.init("Hello \(counter)\n".utf8))
                    stdin.flush()
                }

                XCTAssertEqual(counter, 5)

                try stdin.close()
            },
            stderr: { stderr in
                var counter = 0
                for await output in stderr {
                    counter += 1
                }

                XCTAssertEqual(counter, 0)
            }
        )

        XCTAssertEqual(result.exitStatus, .terminated(code: 0))
    }
