func testBuildParametersWithInvalidDevice() {
        let pniKeyPair = Curve25519.generateKeyPair()
        let localSignedPreKey = pniSignedPreKeyStoreMock.generateSignedPreKey(signedBy: pniKeyPair)
        let localRegistrationId = tsAccountManagerMock.generateRegistrationId()

        messageSenderMock.deviceMessageMocks = [
            .valid(registrationId: 456),
            .invalidDevice
        ]

        let parameters = build(
            localDeviceId: 1,
            localUserAllDeviceIds: [1, 123, 1234],
            localPniIdentityKeyPair: pniKeyPair,
            localDevicePniSignedPreKey: localSignedPreKey,
            localDevicePniRegistrationId: localRegistrationId
        ).value!.unwrapSuccess

        XCTAssertEqual(parameters.pniIdentityKey, pniKeyPair.publicKey)

        // We should have generated a pre-key we threw away, for the invalid
        // device.
        XCTAssertTrue(
            Set(parameters.devicePniSignedPreKeys.values)
                .isStrictSubset(of: pniSignedPreKeyStoreMock.generatedSignedPreKeys)
        )

        // We should have generated a registration ID we threw away, for the
        // invalid device.
        XCTAssertTrue(
            Set(parameters.pniRegistrationIds.values)
                .isStrictSubset(of: tsAccountManagerMock.generatedRegistrationIds)
        )

        XCTAssertEqual(parameters.deviceMessages.count, 1)
        XCTAssertEqual(parameters.deviceMessages.first?.destinationDeviceId, 123)
        XCTAssertEqual(parameters.deviceMessages.first?.destinationRegistrationId, 456)

        XCTAssert(messageSenderMock.deviceMessageMocks.isEmpty)
    }
