func testTasksScheduledDuringShutdownAreAutomaticallyCancelled() async throws {
        let eventLoop = NIOAsyncTestingEventLoop()
        let tasksRun = ManagedAtomic(0)

        @Sendable
        func scheduleRecursiveTask(
            at taskStartTime: NIODeadline,
            andChildTaskAfter childTaskStartDelay: TimeAmount
        ) -> Scheduled<Void> {
            eventLoop.scheduleTask(deadline: taskStartTime) {
                tasksRun.wrappingIncrement(ordering: .releasing)
                _ = scheduleRecursiveTask(
                    at: eventLoop.now + childTaskStartDelay,
                    andChildTaskAfter: childTaskStartDelay
                )
            }
        }

        _ = scheduleRecursiveTask(at: .uptimeNanoseconds(1), andChildTaskAfter: .zero)

        try await withThrowingTaskGroup(of: Void.self) { group in
            group.addTask {
                try await Task.sleep(nanoseconds: 10_000_000)
                await eventLoop.shutdownGracefully()
            }

            await eventLoop.advanceTime(to: .uptimeNanoseconds(1))
            try await group.waitForAll()
        }

        try await eventLoop.executeInContext {
            XCTAssertGreaterThan(tasksRun.load(ordering: .acquiring), 1)
        }
    }
