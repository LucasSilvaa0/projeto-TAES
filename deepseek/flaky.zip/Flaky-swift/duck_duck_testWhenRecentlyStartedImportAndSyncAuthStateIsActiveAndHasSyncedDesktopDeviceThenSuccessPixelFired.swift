func testWhenRecentlyStartedImportAndSyncAuthStateIsActiveAndHasSyncedDesktopDeviceThenSuccessPixelFired() async {

        appSettings.autofillImportViaSyncStart = Date()
        syncService.authState = .active
        syncService.registeredDevices = [RegisteredDevice(id: "1", name: "Device 1", type: "desktop")]

        let importPasswordsStatusHandler = TestImportPasswordsStatusHandler.init(appSettings: appSettings, syncService: syncService)
        let expectation = XCTestExpectation(description: "CheckSyncSuccessStatus completes")

        importPasswordsStatusHandler.checkSyncSuccessStatus()

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
              expectation.fulfill()
        }

        await fulfillment(of: [expectation], timeout: 2.0)

        XCTAssertEqual(importPasswordsStatusHandler.lastFiredPixel, .autofillLoginsImportSuccess)
        XCTAssertNil(appSettings.autofillImportViaSyncStart)
    }
