func testCustomDelegate() {
        // GIVEN
        sut.delegate = delegate

        // WHEN
        let expectation = self.expectation(description: "DataLoaded")
        _ = sut.loadData(with: URLRequest(url: url), didReceiveData: { _, _ in }, completion: { _ in
            DispatchQueue.main.async {
                expectation.fulfill()
            }
        })
        wait(for: [expectation], timeout: 5)

        // THEN
        XCTAssertEqual(delegate.recordedMetrics.count, 1)
    }
