func testPriorityUpdated() {
        let queue = pipeline.configuration.dataCachingQueue
        queue.isSuspended = true
        let observer = self.expect(queue).toEnqueueOperationsWithCount(1)

        image.priority = .high
        image.load(Test.request)
        wait() // Wait till the operation is created.

        guard let operation = observer.operations.first else {
            return XCTFail("No operations gor registered")
        }
        XCTAssertEqual(operation.queuePriority, .high)
    }
