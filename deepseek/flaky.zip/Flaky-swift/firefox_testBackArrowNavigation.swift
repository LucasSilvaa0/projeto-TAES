func testBackArrowNavigation() {
        mozWaitForElementToExist(app.buttons[AccessibilityIdentifiers.Toolbar.settingsMenuButton])
        navigator.nowAt(NewTabScreen)
        closeFromAppSwitcherAndRelaunch()
        navigator.openURL(path(forTestPage: "test-example.html"))
        waitUntilPageLoad()
        app.links[website_2["link"]!].tap()
        waitUntilPageLoad()
        let backButton = app.buttons[AccessibilityIdentifiers.Toolbar.backButton]
        mozWaitForElementToExist(backButton)
        XCTAssertTrue(backButton.isHittable, "Back button is not hittable")
        XCTAssertTrue(backButton.isEnabled, "Back button is disabled")
        backButton.tap()
        waitUntilPageLoad()
        if #available(iOS 16, *) {
            let url = app.textFields[AccessibilityIdentifiers.Browser.AddressToolbar.searchTextField]
            mozWaitForValueContains(url, value: "localhost")
            XCTAssertTrue(backButton.isHittable, "Back button is not hittable")
            XCTAssertTrue(backButton.isEnabled, "Back button is disabled")
            backButton.tap()
            waitUntilPageLoad()
            mozWaitForElementToExist(app.links[AccessibilityIdentifiers.FirefoxHomepage.TopSites.itemCell])
        }
    }
