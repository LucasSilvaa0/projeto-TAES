func testPrecision() {
    #if os(iOS) || os(macOS) || os(tvOS)
      #if os(iOS) || os(tvOS)
        let label = UILabel()
        #if os(iOS)
          label.frame = CGRect(origin: .zero, size: CGSize(width: 43.5, height: 20.5))
        #elseif os(tvOS)
          label.frame = CGRect(origin: .zero, size: CGSize(width: 98, height: 46))
        #endif
        label.backgroundColor = .white
      #elseif os(macOS)
        let label = NSTextField()
        label.frame = CGRect(origin: .zero, size: CGSize(width: 37, height: 16))
        label.backgroundColor = .white
        label.isBezeled = false
        label.isEditable = false
      #endif
      if !ProcessInfo.processInfo.environment.keys.contains("GITHUB_WORKFLOW") {
        label.text = "Hello."
        assertSnapshot(of: label, as: .image(precision: 0.9), named: platform)
        label.text = "Hello"
        assertSnapshot(of: label, as: .image(precision: 0.9), named: platform)
      }
    #endif
  }
