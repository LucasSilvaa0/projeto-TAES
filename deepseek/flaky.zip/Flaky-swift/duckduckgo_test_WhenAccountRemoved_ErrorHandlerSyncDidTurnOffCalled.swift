@MainActor
    func test_WhenAccountRemoved_ErrorHandlerSyncDidTurnOffCalled() async {
        let expectation = XCTestExpectation(description: "Sync Turned off")

        Task {
            _ = await vc.confirmAndDeleteAllData()
        }
        Task {
            vc.onConfirmAndDeleteAllData?()
            expectation.fulfill()
        }
        await fulfillment(of: [expectation], timeout: 5.0)
        XCTAssertTrue(errorHandler.syncDidTurnOffCalled)
    }
