private func testEcnAndPacketInfoReceive(address: String, vectorRead: Bool, vectorSend: Bool, receivePacketInfo: Bool = false) {
        XCTAssertNoThrow(try {
            // Fake sending packet to self on the loopback interface if requested
            let expectedPacketInfo = receivePacketInfo ? try constructNIOPacketInfo(address: address) : nil
            let receiveBootstrap: DatagramBootstrap
            if vectorRead {
                receiveBootstrap = DatagramBootstrap(group: group)
                    .channelOption(ChannelOptions.datagramVectorReadMessageCount, value: 4)
            } else {
                receiveBootstrap = DatagramBootstrap(group: group)
            }
                
            let receiveChannel = try receiveBootstrap
                .channelOption(ChannelOptions.explicitCongestionNotification, value: true)
                .channelOption(ChannelOptions.receivePacketInfo, value: receivePacketInfo)
                .channelInitializer { channel in
                    channel.pipeline.addHandler(DatagramReadRecorder<ByteBuffer>(), name: "ByteReadRecorder")
                }
                .bind(host: address, port: 0)
                .wait()
            defer {
                XCTAssertNoThrow(try receiveChannel.close().wait())
            }
            let sendChannel = try DatagramBootstrap(group: group)
                .bind(host: address, port: 0)
                .wait()
            defer {
                XCTAssertNoThrow(try sendChannel.close().wait())
            }
            
            var buffer = sendChannel.allocator.buffer(capacity: 1)
            buffer.writeRepeatingByte(0, count: 1)
            let ecnStates: [NIOExplicitCongestionNotificationState] = [.transportNotCapable,
                                                                       .congestionExperienced,
                                                                       .transportCapableFlag0,
                                                                       .transportCapableFlag1]
            for ecnState in ecnStates {
                let writeData = AddressedEnvelope(remoteAddress: receiveChannel.localAddress!,
                                                  data: buffer,
                                                  metadata: .init(ecnState: ecnState, packetInfo: expectedPacketInfo))
                // Sending extra data without flushing should trigger a vector send.
                if (vectorSend) {
                    sendChannel.write(writeData, promise: nil)
                }
                try sendChannel.writeAndFlush(writeData).wait()
            }

            let expectedReads = ecnStates.count * (vectorSend ? 2 : 1)
            let reads = try receiveChannel.waitForDatagrams(count: expectedReads)
            XCTAssertEqual(reads.count, expectedReads)
            for readNumber in 0..<reads.count {
                let read = reads[readNumber]
                XCTAssertEqual(read.metadata?.ecnState, ecnStates[readNumber / (vectorSend ? 2 : 1)])
                XCTAssertEqual(read.metadata?.packetInfo, expectedPacketInfo)
            }
        } ())
    }
