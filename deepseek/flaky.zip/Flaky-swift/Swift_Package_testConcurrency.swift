func testConcurrency() throws {
        let fs = localFileSystem
        let observability = ObservabilitySystem.makeForTesting()

        try testWithTemporaryDirectory { path in
            let provider = DummyRepositoryProvider(fileSystem: fs)
            let delegate = DummyRepositoryManagerDelegate()
            let manager = RepositoryManager(
                fileSystem: fs,
                path: path,
                provider: provider,
                delegate: delegate
            )
            let dummyRepo = RepositorySpecifier(path: .init("/dummy"))

            let group = DispatchGroup()
            let results = ThreadSafeKeyValueStore<Int, Result<RepositoryManager.RepositoryHandle, Error>>()
            let concurrency = 10000
            for index in 0 ..< concurrency {
                group.enter()
                delegate.prepare(fetchExpected: index == 0, updateExpected: index > 0)
                manager.lookup(
                    package: .init(url: dummyRepo.url),
                    repository: dummyRepo,
                    skipUpdate: false,
                    observabilityScope: observability.topScope,
                    delegateQueue: .sharedConcurrent,
                    callbackQueue: .sharedConcurrent
                ) { result in
                    group.leave()
                    results[index] = result
                }
            }

            if case .timedOut = group.wait(timeout: .now() + 10) {
                return XCTFail("timeout")
            }

            XCTAssertNoDiagnostics(observability.diagnostics)

            try delegate.wait(timeout: .now() + 2)
            XCTAssertEqual(delegate.willFetch.count, 1)
            XCTAssertEqual(delegate.didFetch.count, 1)
            XCTAssertEqual(delegate.willUpdate.count, concurrency - 1)
            XCTAssertEqual(delegate.didUpdate.count, concurrency - 1)

            XCTAssertEqual(results.count, concurrency)
            for index in 0 ..< concurrency {
                XCTAssertEqual(try results[index]?.get().repository, dummyRepo)
            }
        }
    }
