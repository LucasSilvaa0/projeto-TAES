func testCorrectResponseOrder() async throws {
        app.get("sleep", ":ms") { req -> String in
            let ms = try req.parameters.require("ms", as: Int64.self)
            try await Task.sleep(for: .milliseconds(ms))
            return "slept \(ms)ms"
        }

        let channel = NIOAsyncTestingChannel()
        let app = self.app!
        _ = try await (channel.eventLoop as! NIOAsyncTestingEventLoop).executeInContext {
            channel.pipeline.addVaporHTTP1Handlers(
                application: app,
                responder: app.responder,
                configuration: app.http.server.configuration
            )
        }

        try await channel.writeInbound(ByteBuffer(string: "GET /sleep/100 HTTP/1.1\r\n\r\nGET /sleep/0 HTTP/1.1\r\n\r\n"))

        // We expect 6 writes to be there - three parts (the head, body and separator for each request). However, if there are less
        // we need to have a timeout to avoid hanging the test
        let deadline = NIODeadline.now() + .milliseconds(200)
        var responses: [String] = []
        for _ in 0..<6 {
            guard NIODeadline.now() < deadline else {
                XCTFail("Timed out waiting for responses")
                return
            }
            let res = try await channel.waitForOutboundWrite(as: ByteBuffer.self).string
            if res.contains("slept") {
                responses.append(res)
            }
        }

        XCTAssertEqual(responses.count, 2)
        XCTAssertEqual(responses[0], "slept 100ms")
        XCTA
