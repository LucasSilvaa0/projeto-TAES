func test_WhenClearingDefaultPersistence_ThenLeaveFireproofedCookies() async {
        fireproofing = MockFireproofing(domains: ["example.com"])

        let dataStore = await WKWebsiteDataStore.default()
        await dataStore.httpCookieStore.setCookie(.make(name: "Test1", value: "Value", domain: "example.com"))
        await dataStore.httpCookieStore.setCookie(.make(name: "Test2", value: "Value", domain: ".example.com"))
        await dataStore.httpCookieStore.setCookie(.make(name: "Test3", value: "Value", domain: "facebook.com"))

        var cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(3, cookies.count)

        let webCacheManager = await makeWebCacheManager()
        await webCacheManager.clear(dataStore: dataStore)

        cookies = await dataStore.httpCookieStore.allCookies()
        XCTAssertEqual(2, cookies.count)
        XCTAssertTrue(cookies.contains(where: { $0.domain == "example.com" }))
        XCTAssertTrue(cookies.contains(where: { $0.domain == ".example.com" }))
    }
