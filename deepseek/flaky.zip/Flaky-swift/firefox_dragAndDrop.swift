func dragAndDrop(dragElement: XCUIElement, dropOnElement: XCUIElement) {
        var nrOfAttempts = 0
        mozWaitForElementToExist(dropOnElement)
        dragElement.press(forDuration: 1.5, thenDragTo: dropOnElement)
        mozWaitForElementToExist(dragElement)
        // Repeat the action in case the first drag and drop attempt was not successful
        while dragElement.isLeftOf(rightElement: dropOnElement) && nrOfAttempts < 4 {
            dragElement.press(forDuration: 1.5, thenDragTo: dropOnElement)
            nrOfAttempts = nrOfAttempts + 1
            mozWaitForElementToExist(dragElement)
        }
    }
