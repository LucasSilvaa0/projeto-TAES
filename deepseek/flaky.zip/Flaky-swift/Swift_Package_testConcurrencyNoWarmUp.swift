func testConcurrencyNoWarmUp() throws {
#if os(Windows)
        // FIXME: does this actually trigger only on Windows or are other
        // platforms just getting lucky?  I'm feeling lucky.
        throw XCTSkip("Foundation Process.terminationStatus race condition (apple/swift-corelibs-foundation#4589")
#else
        try testWithTemporaryDirectory { path in
            let total = 100
            let observability = ObservabilitySystem.makeForTesting()
            let delegate = ManifestTestDelegate()
            let manifestLoader = ManifestLoader(toolchain: UserToolchain.default, cacheDir: path, delegate: delegate)
            let identityResolver = DefaultIdentityResolver()

            let sync = DispatchGroup()
            for _ in 0 ..< total {
                let random = Int.random(in: 0 ... total / 4)
                let manifestPath = path.appending(components: "pkg-\(random)", "Package.swift")
                if !localFileSystem.exists(manifestPath) {
                    try localFileSystem.createDirectory(manifestPath.parentDirectory)
                    try localFileSystem.writeFileContents(manifestPath) {
                        """
                        import PackageDescription
                        let package = Package(
                            name: "Trivial-\(random)",
                            targets: [
                                .target(
                                    name: "foo-\(random)",
                                    dependencies: []),
                            ]
                        )
                        """
                    }
                }

                sync.enter()
                delegate.prepare()
                manifestLoader.load(
                    manifestPath: manifestPath,
                    manifestToolsVersion: .v4_2,
                    packageIdentity: .plain("Trivial-\(random)"),
                    packageKind: .fileSystem(manifestPath.parentDirectory),
                    packageLocation: manifestPath.pathString,
                    packageVersion: nil,
                    identityResolver: identityResolver,
                    fileSystem: localFileSystem,
                    observabilityScope: observability.topScope,
                    delegateQueue: .sharedConcurrent,
                    callbackQueue: .sharedConcurrent
                ) { result in
                    defer {
                        sync.leave()
                    }

                    switch result {
                    case .failure(let error):
                        XCTFail("\(error)")
                    case .success(let manifest):
                        XCTAssertEqual(manifest.displayName, "Trivial-\(random)")
                        XCTAssertEqual(manifest.targets[0].name, "foo-\(random)")
                    }
                }
            }

            if case .timedOut = sync.wait(timeout: .now() + 60) {
                XCTFail("timeout")
            }

            XCTAssertEqual(try delegate.loaded(timeout: .now() + 1).count, total)
            XCTAssertFalse(observability.hasWarningDiagnostics, observability.diagnostics.description)
            XCTAssertFalse(observability.hasErrorDiagnostics, observability.diagnostics.description)
        }
#endif
    }
