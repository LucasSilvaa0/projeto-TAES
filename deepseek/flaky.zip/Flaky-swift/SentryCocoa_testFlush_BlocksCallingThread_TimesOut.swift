func testFlush_BlocksCallingThread_TimesOut() {
        givenCachedEvents(amount: 30)
        fixture.requestManager.responseDelay = fixture.flushTimeout + 0.2

        let beforeFlush = SentryDefaultCurrentDateProvider.getAbsoluteTime()
        let result = sut.flush(fixture.flushTimeout)
        let blockingDuration = getDurationNs(beforeFlush, SentryDefaultCurrentDateProvider.getAbsoluteTime()).toTimeInterval()

        XCTAssertGreaterThan(blockingDuration, fixture.flushTimeout)
        XCTAssertLessThan(blockingDuration, fixture.flushTimeout + 0.1)

        XCTAssertEqual(.timedOut, result)
    }
