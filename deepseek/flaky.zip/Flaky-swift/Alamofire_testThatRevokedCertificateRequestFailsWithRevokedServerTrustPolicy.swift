func testThatRevokedCertificateRequestFailsWithRevokedServerTrustPolicy() {
        // Given
        let policy = RevocationTrustEvaluator()

        let evaluators = [revokedHost: policy]

        let manager = Session(configuration: configuration,
                              serverTrustManager: ServerTrustManager(evaluators: evaluators))

        let expectation = self.expectation(description: "\(revokedURLString)")
        var error: AFError?

        // When
        manager.request(revokedURLString)
            .response { resp in
                error = resp.error
                expectation.fulfill()
            }

        waitForExpectations(timeout: timeout, handler: nil)

        // Then
        XCTAssertNotNil(error, "error should not be nil")
        XCTAssertEqual(error?.isServerTrustEvaluationError, true)

        if case let .serverTrustEvaluationFailed(reason)? = error {
            XCTAssertTrue(reason.isDefaultEvaluationFailed, "should be .defaultEvaluationFailed")
        } else {
            XCTFail("error should be .serverTrustEvaluationFailed")
        }
    }
