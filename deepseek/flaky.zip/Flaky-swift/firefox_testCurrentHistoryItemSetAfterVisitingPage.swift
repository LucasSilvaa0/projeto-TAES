@MainActor
    func testCurrentHistoryItemSetAfterVisitingPage() {
        let subject = createSubject()
        let testURL = URL(string: "https://www.example.com/")!

        let expectation = expectation(description: "Wait for the decision handler to be called")

        XCTAssertNil(subject.currentBackForwardListItem())
        delegate.webViewPropertyChangedCallback = { webEngineViewProperty in
            guard webEngineViewProperty == .loading(false) else {return}
            XCTAssertNotNil(subject.currentBackForwardListItem())
            self.delegate.webViewPropertyChangedCallback = nil
            expectation.fulfill()
        }

        subject.load(URLRequest(url: testURL))

        wait(for: [expectation], timeout: 10)
    }
