func test_WhenCookiesAreFromPreviousAppWithContainers_ThenTheyAreConsumed() async {

        MigratableCookieStorage.addCookies([
            .make(name: "Test1", value: "Value", domain: "example.com"),
            .make(name: "Test2", value: "Value", domain: ".example.com"),
            .make(name: "Test3", value: "Value", domain: "facebook.com"),
        ], keyValueStore)

        keyValueStore.set(false, forKey: MigratableCookieStorage.Keys.consumed)

        cookieStorage = MigratableCookieStorage(store: keyValueStore)

        let dataStore = await WKWebsiteDataStore.default()
        let httpCookieStore = await dataStore.httpCookieStore
        await makeWebCacheManager().consumeCookies(into: httpCookieStore)

        XCTAssertTrue(self.cookieStorage.isConsumed)
        XCTAssertTrue(self.cookieStorage.cookies.isEmpty)

        let cookies = await httpCookieStore.allCookies()
        XCTAssertEqual(3, cookies.count)
    }
