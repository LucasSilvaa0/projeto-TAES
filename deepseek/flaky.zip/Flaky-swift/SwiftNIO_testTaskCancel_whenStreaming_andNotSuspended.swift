func testTaskCancel_whenStreaming_andNotSuspended() async throws {
        // We are registering our demand and sleeping a bit to make
        // sure our task runs when the demand is registered
        let sequence = try XCTUnwrap(self.sequence)
        let task: Task<Int?, Never> = Task {
            let iterator = sequence.makeAsyncIterator()
            return await iterator.next()
        }
        try await Task.sleep(nanoseconds: 1_000_000)

        _ = self.source.yield(contentsOf: [1])

        XCTAssertEqual(self.delegate.didTerminateCallCount, 0)
        task.cancel()
        let value = await task.value
        XCTAssertEqual(self.delegate.didTerminateCallCount, 1)
        XCTAssertEqual(value, 1)
    }
