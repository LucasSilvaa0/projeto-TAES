func testBarStateHiddenWhenScrollDownKeepsHiddenState() {
        let (sut, delegate) = makeSUT()
        let scrollView = mockScrollView()

        scrollView.contentOffset.y = 100
        sut.didStartScrolling(in: scrollView)
        XCTAssertEqual(sut.barsState, .revealed)

        scrollView.contentOffset.y = 200
        sut.didScroll(in: scrollView)
        XCTAssertEqual(sut.barsState, .transitioning)

        scrollView.contentOffset.y = 300
        sut.didScroll(in: scrollView)

        // Add delay before checking hidden state
        let expectation1 = XCTestExpectation(description: "Wait for bars state to update to hidden")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            XCTAssertEqual(sut.barsState, .hidden)
            expectation1.fulfill()
        }

        wait(for: [expectation1], timeout: 0.2)

        scrollView.contentOffset.y = 100
        sut.didScroll(in: scrollView)

        // Add another delay before checking that barsState remains hidden
        let expectation2 = XCTestExpectation(description: "Wait to confirm bars state remains hidden")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            XCTAssertEqual(sut.barsState, .hidden)
            XCTAssertEqual(delegate.receivedMessages, [.setBarsVisibility(0.0), .setBarsVisibility(0.0)])
            expectation2.fulfill()
        }

        wait(for: [expectation2], timeout: 0.2)
    }
