@MainActor
    func testHandleURLChange_MultipleCallsWithinOneSecond_ReturnsDuplicateNavigation() async {
        // Arrange
        let youtubeURL = URL(string: "https://www.youtube.com/watch?v=abc123")!
        mockWebView.setCurrentURL(youtubeURL)
        playerSettings.mode = .enabled
        featureFlagger.enabledFeatures = [.duckPlayer, .duckPlayerOpenInNewTab]

        // Act
        let result1 = handler.handleURLChange(webView: mockWebView)
        
        // Wait less than one second before calling again
        try? await Task.sleep(nanoseconds: 500_000_000)
        
        let result2 = handler.handleURLChange(webView: mockWebView)

        // Assert
        if case .handled(.duckPlayerEnabled) = result1 {
            // Success
        } else {
            XCTFail("Expected first call to return .handled")
        }

        if case .notHandled(.duplicateNavigation) = result2 {
            // Success
        } else {
            XCTFail("Expected second call to return .duplicateNavigation")
        }
    }
