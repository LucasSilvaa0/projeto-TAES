func testImagePreviewsAreDeliveredFromMemoryCacheSynchronously() {
        // GIVEN
        pipeline.cache[Test.url] = ImageContainer(image: Test.image, isPreview: true)

        let imagesProduced = self.expectation(description: "ImagesProduced")
        // 1 partial from cache, 2 partials, 1 final
        // we also expect resumable data to kick in for real downloads
        imagesProduced.expectedFulfillmentCount = 4
        var previewsCount = 0
        var isFirstPreviewProduced = false
        let completed = self.expectation(description: "Completed")

        // WHEN
        let publisher = pipeline.imagePublisher(with: Test.url)
        cancellable =  publisher.sink(receiveCompletion: { completion in
            switch completion {
            case .failure:
                XCTFail()
                break
            case .finished:
                completed.fulfill()
            }

        }, receiveValue: { response in
            imagesProduced.fulfill()
            if previewsCount == 3 {
                XCTAssertFalse(response.container.isPreview)
            } else {
                XCTAssertTrue(response.container.isPreview)
                previewsCount += 1
                if isFirstPreviewProduced {
                    self.dataLoader.resume()
                } else {
                    isFirstPreviewProduced = true
                }
            }
        })
        XCTAssertTrue(isFirstPreviewProduced)
        wait()
    }
