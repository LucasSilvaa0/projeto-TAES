@MainActor
  func testRunEscapeFailure() async throws {
    XCTExpectFailure {
      $0.compactDescription == """
        failed - An action was sent from a completed effect:

          Action:
            EffectRunTests.Action.response

          Effect returned from:
            EffectRunTests.Action.tap

        Avoid sending actions using the 'send' argument from 'Effect.run' after the effect has \
        completed. This can happen if you escape the 'send' argument in an unstructured context.

        To fix this, make sure that your 'run' closure does not return until you're done \
        calling 'send'.
        """
    }

    enum Action { case tap, response }

    let queue = DispatchQueue.test

    let store = Store(initialState: 0) {
      Reduce<Int, Action> { _, action in
        switch action {
        case .tap:
          return .run { send in
            Task(priority: .userInitiated) {
              try await queue.sleep(for: .seconds(1))
              await send(.response)
            }
          }
        case .response:
          return .none
        }
      }
    }

    await store.send(.tap).finish()
    await queue.advance(by: .seconds(1))

    try await Task.sleep(nanoseconds: 100_000_000)
  }
