func testSetLastAccessAndLastDataModificationTimesToNil() async throws {
        try await self.withTemporaryFile { handle in
            // Set some random value for both times, only to be overwritten by the current time
            // right after.
            try await handle.setTimes(
                lastAccess: FileInfo.Timespec(seconds: 1, nanoseconds: 0),
                lastDataModification: FileInfo.Timespec(seconds: 1, nanoseconds: 0)
            )

            var actualLastAccessTime = try await handle.info().lastAccessTime
            XCTAssertEqual(actualLastAccessTime, FileInfo.Timespec(seconds: 1, nanoseconds: 0))

            var actualLastDataModificationTime = try await handle.info().lastDataModificationTime
            XCTAssertEqual(actualLastDataModificationTime, FileInfo.Timespec(seconds: 1, nanoseconds: 0))

            try await handle.setTimes(
                lastAccess: nil,
                lastDataModification: nil
            )
            let estimatedCurrentTime = Date.now.timeIntervalSince1970

            // Assert that the times are equal to the current time, with up to a second difference (to avoid timing flakiness).
            actualLastAccessTime = try await handle.info().lastAccessTime
            XCTAssertEqual(Float(actualLastAccessTime.seconds), Float(estimatedCurrentTime), accuracy: 1)

            actualLastDataModificationTime = try await handle.info().lastDataModificationTime
            XCTAssertEqual(Float(actualLastDataModificationTime.seconds), Float(estimatedCurrentTime), accuracy: 1)
        }
    }
