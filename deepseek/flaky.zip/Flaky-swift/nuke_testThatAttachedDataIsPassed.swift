func testThatAttachedDataIsPassed() throws {
        // GIVEN
        pipeline = pipeline.reconfigured {
            $0.makeImageDecoder = { _ in
                ImageDecoders.Empty()
            }
        }

        let imageView = MockView()

        var options = ImageLoadingOptions()
        options.pipeline = pipeline
        options.isPrepareForReuseEnabled = false

        // WHEN
        let expectation = self.expectation(description: "Image loaded")
        Nuke.loadImage(with: Test.url, options: options, into: imageView) { result in
            XCTAssertNotNil(result.value)
            XCTAssertNotNil(result.value?.container.data)
            expectation.fulfill()
        }
        wait()

        // THEN
        let data = try XCTUnwrap(imageView.recordedData.first)
        XCTAssertNotNil(data)
    }

