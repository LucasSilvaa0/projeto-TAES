func test_respectsQueueOrder() {
        let message1: TSOutgoingMessage = OutgoingMessageFactory().create()
        let message2: TSOutgoingMessage = OutgoingMessageFactory().create()
        let message3: TSOutgoingMessage = OutgoingMessageFactory().create()

        let jobQueue = MessageSenderJobQueue()
        self.write { transaction in
            jobQueue.add(message: message1.asPreparer, transaction: transaction)
            jobQueue.add(message: message2.asPreparer, transaction: transaction)
            jobQueue.add(message: message3.asPreparer, transaction: transaction)
        }

        let sendGroup = DispatchGroup()
        sendGroup.enter()
        sendGroup.enter()
        sendGroup.enter()

        var sentMessages: [TSOutgoingMessage] = []
        fakeMessageSender.sendMessageWasCalledBlock = { sentMessage in
            sentMessages.append(sentMessage)
            sendGroup.leave()
        }

        jobQueue.setup()

        let expectation = self.expectation(description: "sent messages")
        // Block on self.wait(), use sendGroup.wait() off the main thread.
        // self.wait() will process the main run loop.
        DispatchQueue.global().async {
            switch sendGroup.wait(timeout: .now() + 1.0) {
            case .timedOut:
                XCTFail("timed out waiting for sends")
            case .success:
                expectation.fulfill()
            }
        }
        self.wait(for: [expectation], timeout: 1.0)

        XCTAssertEqual([message1, message2, message3].map { $0.uniqueId }, sentMessages.map { $0.uniqueId })
    }
