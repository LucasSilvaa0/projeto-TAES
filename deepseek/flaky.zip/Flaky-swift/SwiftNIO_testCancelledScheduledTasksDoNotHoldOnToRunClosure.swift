func testCancelledScheduledTasksDoNotHoldOnToRunClosure() throws {
        #if compiler(>=5.5.2) && canImport(_Concurrency)
        guard #available(macOS 10.15, iOS 13.0, watchOS 6.0, tvOS 13.0, *) else { throw XCTSkip() }
        XCTAsyncTest {
            let eventLoop = NIOAsyncEmbeddedEventLoop()
            defer {
                XCTAssertNoThrow(try eventLoop.syncShutdownGracefully())
            }

            class Thing {}

            weak var weakThing: Thing? = nil

            func make() -> Scheduled<Never> {
                let aThing = Thing()
                weakThing = aThing
                return eventLoop.scheduleTask(in: .hours(1)) {
                    preconditionFailure("this should definitely not run: \(aThing)")
                }
            }

            let scheduled = make()
            scheduled.cancel()

            XCTAssertNotNil(weakThing)
            await eventLoop.run()
            XCTAssertNil(weakThing)
            await XCTAssertThrowsError(try await eventLoop.awaitFuture(scheduled.futureResult, timeout: .seconds(1))) { error in
                XCTAssertEqual(EventLoopError.cancelled, error as? EventLoopError)
            }
        }
        #else
        throw XCTSkip()
        #endif
    }
