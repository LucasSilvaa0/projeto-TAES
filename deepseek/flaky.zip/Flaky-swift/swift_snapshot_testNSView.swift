func testNSView() {
    #if os(macOS)
      let button = NSButton()
      button.bezelStyle = .rounded
      button.title = "Push Me"
      button.sizeToFit()
      if !ProcessInfo.processInfo.environment.keys.contains("GITHUB_WORKFLOW") {
        assertSnapshot(of: button, as: .image)
        assertSnapshot(of: button, as: .recursiveDescription)
      }
    #endif
  }
