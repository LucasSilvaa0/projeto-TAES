func testAsyncStream() async throws {
        let (stdoutStream, stdoutContinuation) = AsyncProcess.ReadableStream.makeStream()
        let (stderrStream, stderrContinuation) = AsyncProcess.ReadableStream.makeStream()

        let process = AsyncProcess(
            scriptName: "echo",
            outputRedirection: .stream {
                stdoutContinuation.yield($0)
            } stderr: {
                stderrContinuation.yield($0)
            }
        )

        let result = try await withThrowingTaskGroup(of: Void.self) { group in
            let stdin = try process.launch()

            group.addTask {
                var counter = 0
                stdin.write("Hello \(counter)\n")
                stdin.flush()

                for await output in stdoutStream {
                    XCTAssertEqual(output, .init("Hello \(counter)\n".utf8))
                    counter += 1

                    stdin.write(.init("Hello \(counter)\n".utf8))
                    stdin.flush()
                }

                XCTAssertEqual(counter, 5)

                try stdin.close()
            }

            group.addTask {
                var counter = 0
                for await output in stderrStream {
                    counter += 1
                }

                XCTAssertEqual(counter, 0)
            }

            defer {
                stdoutContinuation.finish()
                stderrContinuation.finish()
            }

            return try await process.waitUntilExit()
        }

        XCTAssertEqual(result.exitStatus, .terminated(code: 0))
    }
