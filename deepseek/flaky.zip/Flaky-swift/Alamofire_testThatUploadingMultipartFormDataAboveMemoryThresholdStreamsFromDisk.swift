@MainActor
func testThatUploadingMultipartFormDataAboveMemoryThresholdStreamsFromDisk() {
    // Given
    let frenchData = Data("français".utf8)
    let japaneseData = Data("日本語".utf8)

    let expectation = expectation(description: "multipart form data upload should succeed")
    var response: DataResponse<Data?, AFError>?

    // When
    let request = AF.upload(multipartFormData: { multipartFormData in
                                multipartFormData.append(frenchData, withName: "french")
                                multipartFormData.append(japaneseData, withName: "japanese")
                            },
                            to: Endpoint.method(.post),
                            usingThreshold: 0).response { resp in
        response = resp
        expectation.fulfill()
    }

    waitForExpectations(timeout: timeout)

    // Then
    guard let uploadable = request.uploadable, case let .file(url, _) = uploadable else {
        XCTFail("Uploadable is not .file")
        return
    }

    XCTAssertTrue(response?.result.isSuccess == true)
    XCTAssertFalse(FileManager.default.fileExists(atPath: url.path))
}
