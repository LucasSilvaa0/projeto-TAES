func testShouldDownloadAndCacheProcessedImage() {
        let exp = expectation(description: #function)
        let url = testURLs[0]
        stub(url, data: testImageData)

        let size = CGSize(width: 1, height: 1)
        let processor = ResizingImageProcessor(referenceSize: size)

        manager.retrieveImage(with: url, options: [.processor(processor)]) { result in
            // Can download and cache normally
            XCTAssertNotNil(result.value?.image)
            XCTAssertEqual(result.value!.image.size, size)
            XCTAssertEqual(result.value!.cacheType, .none)

            self.manager.cache.clearMemoryCache()
            let cached = self.manager.cache.imageCachedType(
                forKey: url.cacheKey, processorIdentifier: processor.identifier)
            XCTAssertEqual(cached, .disk)

            self.manager.retrieveImage(with: url, options: [.processor(processor)]) { result in
                XCTAssertNotNil(result.value?.image)
                XCTAssertEqual(result.value!.image.size, size)
                XCTAssertEqual(result.value!.cacheType, .disk)

                exp.fulfill()
            }
        }
        waitForExpectations(timeout: 3, handler: nil)
    }


Tokens: ['testShouldDownloadAndCacheProcessedImage', 'exp', 'expectation', 'description', 'function', 'url', 'testURLs', 'NUM', 'stub', 'url', 'data', 'testImageData', 'size', 'CGSize', 'width', 'NUM', 'height', 'NUM', 'processor', 'ResizingImageProcessor', 'referenceSize', 'size', 'manager', 'retrieveImage', 'with', 'url', 'options', 'processor', 'processor', 'result', 'XCTAssertNotNil', 'result', 'value', 'image', 'XCTAssertEqual', 'result', 'value', 'image', 'size', 'size', 'XCTAssertEqual', 'result', 'value', 'cacheType', 'none', 'self', 'manager', 'cache', 'clearMemoryCache', 'cached', 'self', 'manager', 'cache', 'imageCachedType', 'forKey', 'url', 'cacheKey', 'processorIdentifier', 'processor', 'identifier', 'XCTAssertEqual', 'cached', 'disk', 'self', 'manager', 'retrieveImage', 'with', 'url', 'options', 'processor', 'processor', 'result', 'XCTAssertNotNil', 'result', 'value', 'image', 'XCTAssertEqual', 'result', 'value', 'image', 'size', 'size', 'XCTAssertEqual', 'result', 'value', 'cacheType', 'disk', 'exp', 'fulfill', 'waitForExpectations', 'timeout', 'NUM', 'handler', 'nil']
