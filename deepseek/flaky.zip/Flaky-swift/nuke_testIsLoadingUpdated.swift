func testIsLoadingUpdated() {
        // RECORD
        expect(image.$result.dropFirst()).toPublishSingleValue()
        let isLoading = record(image.$isLoading)

        // WHEN
        image.load(Test.request)
        wait()

        // THEN
        XCTAssertEqual(isLoading.values, [false, true, false])
    }
