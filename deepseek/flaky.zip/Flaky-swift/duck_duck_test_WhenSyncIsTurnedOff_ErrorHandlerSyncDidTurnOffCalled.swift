@MainActor
    func test_WhenSyncIsTurnedOff_ErrorHandlerSyncDidTurnOffCalled() async {
        let expectation = XCTestExpectation(description: "Sync Turned off")
        Task {
            _ = await vc.confirmAndDisableSync()
        }
        Task {
            vc.onConfirmSyncDisable?()
            expectation.fulfill()
        }

        await fulfillment(of: [expectation], timeout: 5.0)
        XCTAssertTrue(errorHandler.syncDidTurnOffCalled)
    }

