func testConcatenateOneEffect() async {
    let values = LockIsolated<[Int]>([])

    let effect = Effect<Int>.concatenate(
      .publisher { Just(1).delay(for: 1, scheduler: self.mainQueue) }
    )

    let task = Task {
      for await n in effect.actions {
        values.withValue { $0.append(n) }
      }
    }

    XCTAssertEqual(values.value, [])

    await self.mainQueue.advance(by: 1)
    XCTAssertEqual(values.value, [1])

    await self.mainQueue.run()
    XCTAssertEqual(values.value, [1])

    await task.value
  }

