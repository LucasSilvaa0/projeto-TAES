func testAutofillCreditCardsToggleOnOoff() {
        navigator.nowAt(NewTabScreen)
        navigator.goto(CreditCardsSettings)
        unlockLoginsView()
        mozWaitForElementToExist(app.staticTexts[creditCardsStaticTexts.AutoFillCreditCard.autoFillCreditCards])
        let saveAndFillPaymentMethodsSwitch =
            app.switches[creditCardsStaticTexts.AutoFillCreditCard.saveAutofillCards].switches.firstMatch
        if saveAndFillPaymentMethodsSwitch.value! as! String == "1" {
            saveAndFillPaymentMethodsSwitch.tap()
        }
        XCTAssertEqual(saveAndFillPaymentMethodsSwitch.value! as! String, "0")
        app.buttons[creditCardsStaticTexts.AutoFillCreditCard.addCard].tap()
        addCreditCard(name: "Test", cardNumber: cards[0], expirationDate: "0540")
        if #available(iOS 16, *) {
            navigator.goto(NewTabScreen) // Not working on iOS 15
            navigator.openURL("https://checkout.stripe.dev/preview")
            waitUntilPageLoad()
            // The autofill option (Use saved card prompt) is not displayed
            let cardNumber = app.webViews["contentView"].webViews.textFields["Card number"]
            app.swipeUp()
            app.swipeUp()
            mozWaitForElementToExist(cardNumber)
            cardNumber.tapOnApp()
            mozWaitForElementToNotExist(app.buttons[useSavedCard])
            dismissSavedCardsPrompt()
            navigator.goto(CreditCardsSettings)
            unlockLoginsView()
            mozWaitForElementToExist(app.staticTexts[creditCardsStaticTexts.AutoFillCreditCard.autoFillCreditCards])
            // Enable the "Save and Fill Payment Methods" toggle
            app.switches.element(boundBy: 1).tap()
            XCTAssertEqual(saveAndFillPaymentMethodsSwitch.value! as! String, "1")
            app.buttons["Settings"].tap()
            navigator.nowAt(SettingsScreen)
            waitForExistence(app.buttons["Done"])
            app.buttons["Done"].tap()
            app.swipeUp()
            mozWaitForElementToExist(app.webViews["contentView"].webViews.staticTexts["Explore Checkout"])
            mozWaitForElementToExist(cardNumber)
            cardNumber.tapOnApp()
            // The autofill option (Use saved card prompt) is displayed
            if !app.buttons[useSavedCard].exists {
                app.webViews["contentView"].webViews.textFields["Full name on card"].tapOnApp()
            }
            mozWaitForElementToExist(app.buttons[useSavedCard])
        }
    }
