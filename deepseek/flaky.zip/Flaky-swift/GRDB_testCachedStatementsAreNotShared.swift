func testCachedStatementsAreNotShared() throws {
        // This is a regression test.
        //
        // If cached statements were shared between reader connections, this
        // test would crash with fatal error: Database was not used on the
        // correct thread.
        let dbPool = try makeDatabasePool()
        try dbPool.write { db in
            try db.execute(sql: "CREATE TABLE items (id INTEGER PRIMARY KEY)")
            try db.execute(sql: "INSERT INTO items (id) VALUES (1)")
        }
        
        // Block 1                              Block 2
        // SELECT 1 FROM items WHERE id = 1
        // >
        let s1 = DispatchSemaphore(value: 0)
        //                                      SELECT 1 FROM items WHERE id = 1
        
        let block1 = { () in
            try! dbPool.read { db in
                let stmt = try! db.cachedSelectStatement(sql: "SELECT * FROM items")
                XCTAssertEqual(try Int.fetchOne(stmt)!, 1)
                s1.signal()
            }
        }
        let block2 = { () in
            try! dbPool.read { db in
                _ = s1.wait(timeout: .distantFuture)
                let stmt = try! db.cachedSelectStatement(sql: "SELECT * FROM items")
                XCTAssertEqual(try Int.fetchOne(stmt)!, 1)
            }
        }
        let blocks = [block1, block2]
        DispatchQueue.concurrentPerform(iterations: blocks.count) { index in
            blocks[index]()
        }
    }
