func testCache() throws {
        if #available(macOS 11, *) {
            // No need to skip the test.
        }
        else {
            // Avoid a crasher that seems to happen only on macOS 10.15, but leave an environment variable for testing.
            try XCTSkipUnless(ProcessEnv.vars["SWIFTPM_ENABLE_FLAKY_REPOSITORYMANAGERTESTS"] == "1", "skipping test that sometimes crashes in CI (rdar://70540298)")
        }
        
        fixture(name: "DependencyResolution/External/Simple") { prefix in
            let cachePath = prefix.appending(component: "cache")
            let repositoriesPath = prefix.appending(component: "repositories")
            let repo = RepositorySpecifier(url: prefix.appending(component: "Foo").pathString)

            let provider = GitRepositoryProvider()
            let delegate = DummyRepositoryManagerDelegate()
            delegate.willFetchGroup = DispatchGroup()
            delegate.didFetchGroup = DispatchGroup()

            let manager = RepositoryManager(
                fileSystem: localFileSystem,
                path: repositoriesPath,
                provider: provider,
                delegate: delegate,
                cachePath: cachePath,
                cacheLocalPackages: true
            )

            // fetch packages and populate cache
            delegate.willFetchGroup?.enter()
            delegate.didFetchGroup?.enter()
            _ = try manager.lookup(repository: repo)
            XCTAssertDirectoryExists(cachePath.appending(component: repo.fileSystemIdentifier))
            XCTAssertDirectoryExists(repositoriesPath.appending(component: repo.fileSystemIdentifier))
            XCTAssertEqual(delegate.willFetch[0].fetchDetails,
                           RepositoryManager.FetchDetails(fromCache: false, updatedCache: false))
            XCTAssertEqual(delegate.didFetch[0].fetchDetails,
                           RepositoryManager.FetchDetails(fromCache: false, updatedCache: true))

            try localFileSystem.removeFileTree(repositoriesPath)

            // fetch packages from the cache
            delegate.willFetchGroup?.enter()
            delegate.didFetchGroup?.enter()
            _ = try manager.lookup(repository: repo)
            XCTAssertDirectoryExists(repositoriesPath.appending(component: repo.fileSystemIdentifier))
            XCTAssertEqual(delegate.willFetch[1].fetchDetails,
                           RepositoryManager.FetchDetails(fromCache: true, updatedCache: false))
            XCTAssertEqual(delegate.didFetch[1].fetchDetails,
                           RepositoryManager.FetchDetails(fromCache: false, updatedCache: true))

            try localFileSystem.removeFileTree(repositoriesPath)
            try localFileSystem.removeFileTree(cachePath)

            // fetch packages and populate cache
            delegate.willFetchGroup?.enter()
            delegate.didFetchGroup?.enter()
            _ = try manager.lookup(repository: repo)
            XCTAssertDirectoryExists(cachePath.appending(component: repo.fileSystemIdentifier))
            XCTAssertDirectoryExists(repositoriesPath.appending(component: repo.fileSystemIdentifier))
            XCTAssertEqual(delegate.willFetch[2].fetchDetails,
                           RepositoryManager.FetchDetails(fromCache: false, updatedCache: false))
            XCTAssertEqual(delegate.didFetch[2].fetchDetails,
                           RepositoryManager.FetchDetails(fromCache: false, updatedCache: true))
        }
    }
