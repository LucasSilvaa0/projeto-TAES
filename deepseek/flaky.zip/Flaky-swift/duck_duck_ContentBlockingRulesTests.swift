func test() throws {
        let url = URL.trackerDataSet
        let data = try Data(contentsOf: url)
        let trackerData = try JSONDecoder().decode(TrackerData.self, from: data)
        
        let rules = ContentBlockerRulesBuilder(trackerData: trackerData).buildRules(withExceptions: ["duckduckgo.com"],
        andTemporaryUnprotectedDomains: [])
         
        // Test tracker is set up to be blocked
        if let rule = rules.findExactFilter(filter: "^(https?)?(wss?)?://([a-z0-9-]+\\.)*bad\\.third-party\\.site(:?[0-9]+)?/.*") {
            XCTAssert(rule.action == .block())
        } else {
            XCTFail("Missing tracking rule")
        }
        
        // Test exceptiions are set to ignore previous rules
        if let rule = rules.findInIfDomain(domain: "duckduckgo.com") {
            XCTAssert(rule.action == .ignorePreviousRules())
        } else {
            XCTFail("Missing domain exception")
        }
    }
