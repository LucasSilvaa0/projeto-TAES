func testThingsThatLookLikeGroupIdNotScrubbed() {
        let forbiddenBase64Lengths = Set([
            kGroupIdLengthV1.base64Length,
            kGroupIdLengthV2.base64Length
        ])

        for _ in 1...100 {
            let fakeGroupIdCount: Int32 = {
                while true {
                    let result = Int32.random(in: 1...(kGroupIdLengthV2 * 2))
                    if !forbiddenBase64Lengths.contains(result.base64Length) {
                        return result
                    }
                }
            }()
            let fakeGroupId = Randomness.generateRandomBytes(fakeGroupIdCount)
            let fakeGroupIdString = TSGroupThread.defaultThreadId(forGroupId: fakeGroupId)
            // Unfortunately, a portion of the fake groupID can look like a base64-encoded
            // uuid. For example:
            // "SAFsdfdsafSDGHJ/SggGREgAFhGEWRGCDSFfds=="
            // Is that a long group id, or a segment of a url with one path segment being
            // "SAFsdfdsafSDGHJ" and another path segment being the 22 char length + 2 char
            // padding of a base64 encoded uuid? We can't know with a simple regex.
            // Just stop that case here.
            if fakeGroupIdString.hasSuffix("=="), fakeGroupIdString.suffix(25).starts(with: "/") {
                continue
            }
            let input = "Hello \(fakeGroupIdString)!"

            let result = format(input)
            XCTAssertEqual(result, input)
        }
