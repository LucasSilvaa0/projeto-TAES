  func test_weakCompareExchange_sequentiallyConsistent_relaxed() {
    let v: UnsafeAtomic<UnsafeMutablePointer<Foo>?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeMutablePointer<Foo>?)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: nil,
        desired: _mfoo2,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo2)

    (exchanged, original) = v.weakCompareExchange(
      expected: nil,
      desired: _mfoo2,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mfoo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _mfoo2,
        desired: nil,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, _mfoo2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.weakCompareExchange(
      expected: _mfoo2,
      desired: nil,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
