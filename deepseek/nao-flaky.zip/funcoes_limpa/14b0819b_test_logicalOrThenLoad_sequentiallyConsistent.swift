  func test_logicalOrThenLoad_sequentiallyConsistent() {
    let v = UnsafeAtomic<Bool>.create(false)
    defer { v.destroy() }

    // The truth tables are super tiny, so just check every value
    for a in [false, true] {
      for b in [false, true] {
        v.store(a, ordering: .relaxed)
        let r = v.logicalOrThenLoad(
          with: b,
          ordering: .sequentiallyConsistent)
        XCTAssertEqual(r, a || b, "a = \(a), b = \(b)")
        XCTAssertEqual(
          v.load(ordering: .relaxed),
          a || b,
          "a = \(a), b =\(b)")
      }
    }
  }
