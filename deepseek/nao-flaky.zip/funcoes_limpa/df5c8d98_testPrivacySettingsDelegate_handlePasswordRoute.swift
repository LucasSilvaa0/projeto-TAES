    func testPrivacySettingsDelegate_handlePasswordRoute() {
        let subject = createSubject()
        subject.settingsViewController = mockSettingsVC

        subject.pressedPasswords()

        XCTAssertEqual(mockSettingsVC.handleRouteCalled, 1)
        XCTAssertEqual(mockSettingsVC.savedRoute, .password)
    }
