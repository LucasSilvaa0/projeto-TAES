    func testHandleNewAttachments_ExistingSection() {
        let store = standardFakeStore
        var wrapper = SectionsWrapper(sections: Sections(loader: store))
        // Load all months
        XCTAssertEqual(3, wrapper.mutate { sections in sections.loadLaterSections(batchSize: 20) })
        XCTAssertTrue(wrapper.sections.hasFetchedMostRecent)
        XCTAssertEqual(3, wrapper.sections.itemsBySection.count)

        let expected = Sections.NewAttachmentHandlingResult(update: IndexSet(integer: 1),
                                                            didAddAtEnd: false,
                                                            didReset: false)
        let actual = wrapper.mutate { sections in sections.handleNewAttachments([GalleryDate(2021_04_01)]) }
        XCTAssertEqual(expected, actual)
    }
