    func testByteCountBytes() {
        let byteCount = ByteCount.bytes(10)
        XCTAssertEqual(byteCount.bytes, 10)
    }
