  func test_compareExchange_sequentiallyConsistent_sequentiallyConsistent() {
    let v: UnsafeAtomic<Unmanaged<Bar>> = .create(_bar1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Unmanaged<Bar>) = v.compareExchange(
      expected: _bar1,
      desired: _bar2,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _bar1)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    (exchanged, original) = v.compareExchange(
      expected: _bar1,
      desired: _bar2,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    (exchanged, original) = v.compareExchange(
      expected: _bar2,
      desired: _bar1,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar1)

    (exchanged, original) = v.compareExchange(
      expected: _bar2,
      desired: _bar1,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _bar1)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar1)
  }
