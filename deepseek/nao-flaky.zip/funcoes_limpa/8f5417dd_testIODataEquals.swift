    func testIODataEquals() {
        let handle = NIOFileHandle(_deprecatedTakingOwnershipOfDescriptor: -1)
        var bb1 = ByteBufferAllocator().buffer(capacity: 1024)
        let bb2 = ByteBufferAllocator().buffer(capacity: 1024)
        bb1.writeString("hello")
        let fr = FileRegion(fileHandle: handle, readerIndex: 1, endIndex: 2)
        defer {
            // fake descriptor, so shouldn't be closed.
            XCTAssertNoThrow(try handle.takeDescriptorOwnership())
        }
        XCTAssertEqual(IOData.byteBuffer(bb1), IOData.byteBuffer(bb1))
        XCTAssertNotEqual(IOData.byteBuffer(bb1), IOData.byteBuffer(bb2))
        XCTAssertNotEqual(IOData.byteBuffer(bb1), IOData.fileRegion(fr))
    }
