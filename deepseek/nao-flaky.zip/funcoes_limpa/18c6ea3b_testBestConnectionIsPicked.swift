    func testBestConnectionIsPicked() {
        let elg = MultiThreadedEventLoopGroup(numberOfThreads: 64)
        defer { XCTAssertNoThrow(try elg.syncShutdownGracefully()) }

        guard var (connections, state) = try? MockConnectionPool.http1(elg: elg, numberOfConnections: 8) else {
            return XCTFail("Test setup failed")
        }

        for index in 1...300 {
            // Every iteration we start with eight parked connections
            XCTAssertEqual(connections.parked, 8)

            var reqEventLoop: EventLoop = elg.next()
            for _ in 0..<((0..<63).randomElement()!) {
                // pick a random eventLoop for the next request
                reqEventLoop = elg.next()
            }

            // 10% of the cases enforce the eventLoop
            let elRequired = (0..<10).randomElement().flatMap { $0 == 0 ? true : false }!
            let mockRequest = MockHTTPScheduableRequest(
                eventLoop: reqEventLoop,
                requiresEventLoopForChannel: elRequired
            )
            let request = HTTPConnectionPool.Request(mockRequest)

            let action = state.executeRequest(request)

            switch action.connection {
            case .createConnection(let connectionID, on: let connEventLoop):
                XCTAssertTrue(elRequired)
                XCTAssertNil(connections.newestParkedConnection(for: reqEventLoop))
                XCTAssert(connEventLoop === reqEventLoop)
                XCTAssertEqual(action.request, .scheduleRequestTimeout(for: request, on: reqEventLoop))

                let connection: HTTPConnectionPool.Connection = .__testOnly_connection(
                    id: connectionID,
                    eventLoop: connEventLoop
                )
                let createdAction = state.newHTTP1ConnectionCreated(connection)
                XCTAssertEqual(createdAction.request, .executeRequest(request, connection, cancelTimeout: true))
                XCTAssertEqual(createdAction.connection, .none)

                let doneAction = state.http1ConnectionReleased(connectionID)
                XCTAssertEqual(doneAction.request, .none)
                XCTAssertEqual(doneAction.connection, .closeConnection(connection, isShutdown: .no))
                XCTAssertEqual(state.http1ConnectionClosed(connectionID), .none)

            case .cancelTimeoutTimer(let connectionID):
                guard
                    let expectedConnection = connections.newestParkedConnection(for: reqEventLoop)
                        ?? connections.newestParkedConnection
                else {
                    return XCTFail("Expected to have connections available")
                }

                if elRequired {
                    XCTAssert(expectedConnection.eventLoop === reqEventLoop)
                }

                XCTAssertEqual(
                    connectionID,
                    expectedConnection.id,
                    "Request is scheduled on the connection we expected"
                )
                XCTAssertNoThrow(try connections.activateConnection(connectionID))

                guard case .executeRequest(let request, let connection, cancelTimeout: false) = action.request else {
                    return XCTFail("Expected to execute a request, but got: \(action.request)")
                }
                XCTAssertEqual(connection, expectedConnection)
                XCTAssertNoThrow(try connections.execute(request.__testOnly_wrapped_request(), on: connection))
                XCTAssertNoThrow(try connections.finishExecution(connection.id))

                XCTAssertEqual(
                    state.http1ConnectionReleased(connection.id),
                    .init(request: .none, connection: .scheduleTimeoutTimer(connection.id, on: connection.eventLoop))
                )
                XCTAssertNoThrow(try connections.parkConnection(connectionID))

            default:
                XCTFail("Unexpected connection action in iteration \(index): \(action.connection)")
            }
        }

        XCTAssertEqual(connections.parked, 8)
    }
