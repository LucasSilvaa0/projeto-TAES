    func testEditSendWindowString() {
        let errorMessage = EditSendValidationError.editWindowClosed.localizedDescription
        let editMilliseconds = EditManagerImpl.Constants.editSendWindowMilliseconds
        XCTAssertEqual(editMilliseconds % UInt64.hourInMs, 0)
        XCTAssert(errorMessage.range(of: " \(editMilliseconds / UInt64.hourInMs) ") != nil)
    }
