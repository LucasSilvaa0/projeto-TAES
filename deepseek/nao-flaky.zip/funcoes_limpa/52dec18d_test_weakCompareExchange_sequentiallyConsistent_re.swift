  func test_weakCompareExchange_sequentiallyConsistent_relaxed() {
    let v: UnsafeAtomic<Hyacinth?> = .create(Hyacinth.bucket)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Hyacinth?)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: Hyacinth.bucket,
        desired: nil,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, Hyacinth.bucket)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.weakCompareExchange(
      expected: Hyacinth.bucket,
      desired: nil,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: nil,
        desired: Hyacinth.bucket,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), Hyacinth.bucket)

    (exchanged, original) = v.weakCompareExchange(
      expected: nil,
      desired: Hyacinth.bucket,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, Hyacinth.bucket)
    XCTAssertEqual(v.load(ordering: .relaxed), Hyacinth.bucket)
  }
