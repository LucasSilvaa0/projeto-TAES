    func testReadSliceWithBigEndianInteger() {
        buffer.writeInteger(UInt16(256), endianness: .big)
        buffer.writeString(String(repeating: "A", count: 256))
        XCTAssertEqual(
            buffer.readLengthPrefixedSlice(endianness: .big, as: UInt16.self),
            ByteBuffer(string: String(repeating: "A", count: 256))
        )
        XCTAssertTrue(buffer.readableBytes == 0)
    }
