    func testGetToolbarButton_CreatesAndReturnsTheCachedButton() {
        // First call to getToolbarButton should create a new button
        guard let toolbarElement else { return }
        let button1 = sut?.getToolbarButton(for: toolbarElement)
        XCTAssertNotNil(button1, "Button should not be nil.")

        // Second call to getToolbarButton should return the cached button
        let button2 = sut?.getToolbarButton(for: toolbarElement)
        XCTAssertNotNil(button2, "Button should not be nil.")

        // Verify that the same button instance is returned
        XCTAssertEqual(button1, button2, "The button should be cached and reused.")

        // Verify the cache count
        XCTAssertEqual(sut?.cachedButtonReferences.count, 1, "Cache should contain one button.")
    }
