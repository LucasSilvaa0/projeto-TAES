    func testSetUUIDBytesBlatsExistingBytes() {
        var buffer = ByteBuffer()
        buffer.writeRepeatingByte(.max, count: 32)

        let uuid = UUID(
            uuid: (
                0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7,
                0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf
            )
        )
        buffer.setUUIDBytes(uuid, at: buffer.readerIndex + 4)

        XCTAssertEqual(buffer.readBytes(length: 4), Array(repeating: .max, count: 4))
        XCTAssertEqual(buffer.readBytes(length: 16), Array(0..<16))
        XCTAssertEqual(buffer.readBytes(length: 12), Array(repeating: .max, count: 12))
        XCTAssertEqual(buffer.readableBytes, 0)
    }
