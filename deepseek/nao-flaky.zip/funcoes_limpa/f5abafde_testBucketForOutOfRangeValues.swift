    func testBucketForOutOfRangeValues() {
        // Given
        let bucketer = PaywallViewBucketer()

        // When & Then
        XCTAssertEqual(bucketer.bucket(for: 0), "Unknown", "Given 0 views (out of range), Then it should map to 'Unknown'")
        XCTAssertEqual(bucketer.bucket(for: -10), "Unknown", "Given -10 views (negative value), Then it should map to 'Unknown'")
    }
