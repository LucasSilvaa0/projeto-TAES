    func testInferIndentedIfdefOutdent() {
        let input = "{\n    {\n#if foo\n        //foo\n#endif\n    }\n}"
        let output = IndentMode.outdent
        let options = inferFormatOptions(from: tokenize(input))
        XCTAssertEqual(options.ifdefIndent, output)
    }
