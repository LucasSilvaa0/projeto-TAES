    func testDecodingMultipleFirstInvalid() {
        let headers: HTTPHeaders = [markerHeader : "other", markerHeader : "enable"]
        XCTAssertEqual(headers.responseCompression, .enable)
    }
