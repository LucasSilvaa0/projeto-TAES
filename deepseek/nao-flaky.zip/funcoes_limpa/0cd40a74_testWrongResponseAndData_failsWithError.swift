    func testWrongResponseAndData_failsWithError() {
        networking.data = getData(from: emptyWrongResponse)
        networking.response = getResponse(from: 200)
        let subject = createSubject()

        subject.fetchContiles { result in
            switch result {
            case let .failure(error as ContileProvider.Error):
                XCTAssertEqual(error, ContileProvider.Error.noDataAvailable)
            default:
                XCTFail("Expected failure, got \(result) instead")
            }
        }
    }
