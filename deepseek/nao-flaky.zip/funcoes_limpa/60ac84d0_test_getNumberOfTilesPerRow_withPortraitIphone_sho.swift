    func test_getNumberOfTilesPerRow_withPortraitIphone_showsExpectedRowNumber() {
        let trait = MockTraitCollection().getTraitCollection()
        let leadingInset = HomepageSectionLayoutProvider.UX.leadingInset(traitCollection: trait, interfaceIdiom: .phone)

        let numberOfTilesPerRow = HomepageDimensionCalculator.numberOfTopSitesPerRow(
            availableWidth: UX.DeviceSize.iPhone14.width,
            leadingInset: leadingInset
        )

        XCTAssertEqual(numberOfTilesPerRow, 4)
    }
