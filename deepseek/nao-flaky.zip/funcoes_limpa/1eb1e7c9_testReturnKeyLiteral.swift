    func testReturnKeyLiteral() {
        let node = LayoutNode(
            view: UITextField(),
            expressions: [
                "returnKeyType": "go",
            ]
        )
        let expected = UIReturnKeyType.go
        XCTAssertEqual(try node.value(forSymbol: "returnKeyType") as? UIReturnKeyType, expected)
    }
