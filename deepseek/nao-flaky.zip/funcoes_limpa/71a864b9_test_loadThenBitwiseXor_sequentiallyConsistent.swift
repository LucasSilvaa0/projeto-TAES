  func test_loadThenBitwiseXor_sequentiallyConsistent() {
    let a: Int16 = 3
    let b: Int16 = 8
    let c: Int16 = 12
    let result1: Int16 = a ^ b
    let result2: Int16 = result1 ^ c

    let v: UnsafeAtomic<Int16> = .create(a)
    defer { v.destroy() }

    let old1: Int16 = v.loadThenBitwiseXor(with: b, ordering: .sequentiallyConsistent)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: Int16 = v.loadThenBitwiseXor(with: c, ordering: .sequentiallyConsistent)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
