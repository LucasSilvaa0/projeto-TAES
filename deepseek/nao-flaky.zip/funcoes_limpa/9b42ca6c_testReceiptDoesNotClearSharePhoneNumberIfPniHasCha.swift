    func testReceiptDoesNotClearSharePhoneNumberIfPniHasChanged() {
        let otherAci = Aci.randomForTesting()
        let otherAddress = SignalServiceAddress(serviceId: otherAci, phoneNumber: "+12223334444")
        var message: TSOutgoingMessage!

        write { transaction in
            identityManager.setShouldSharePhoneNumber(with: otherAci, tx: transaction)

            let thread = TSContactThread.getOrCreateThread(withContactAddress: otherAddress, transaction: transaction)
            let messageBuilder = TSOutgoingMessageBuilder.outgoingMessageBuilder(thread: thread, messageBody: nil)
            messageBuilder.timestamp = Date.ows_millisecondTimestamp()
            message = messageBuilder.build(transaction: transaction)
            message.anyInsert(transaction: transaction)
            let messageData = message.buildPlainTextData(thread, transaction: transaction)!

            message.updateWithSentRecipients([otherAci], wasSentByUD: true, transaction: transaction)

            let messageSendLog = SSKEnvironment.shared.messageSendLogRef
            let payloadId = messageSendLog.recordPayload(messageData, for: message, tx: transaction)!
            messageSendLog.recordPendingDelivery(
                payloadId: payloadId,
                recipientAci: otherAci,
                recipientDeviceId: DeviceId(validating: 1)!,
                message: message,
                tx: transaction
            )
        }

        // Change our PNI, using registerForTests(...) instead of updateLocalPhoneNumber(...) because the latter kicks
        // off a request to check with the server.
        let aci = DependenciesBridge.shared.tsAccountManager.localIdentifiersWithMaybeSneakyTransaction!.aci
        SSKEnvironment.shared.databaseStorageRef.write { tx in
            (DependenciesBridge.shared.registrationStateChangeManager as! RegistrationStateChangeManagerImpl).registerForTests(
                localIdentifiers: .init(
                    aci: aci,
                    pni: Pni.randomForTesting(),
                    e164: .init("+17775550199")!
                ),
                tx: tx
            )
        }

        write { transaction in
            // Changing your number resets this setting.
            XCTAssertFalse(identityManager.shouldSharePhoneNumber(with: otherAci, tx: transaction))
            identityManager.setShouldSharePhoneNumber(with: otherAci, tx: transaction)

            message.update(
                withDeliveredRecipient: otherAddress,
                deviceId: DeviceId(validating: 1)!,
                deliveryTimestamp: NSDate.ows_millisecondTimeStamp(),
                context: PassthroughDeliveryReceiptContext(),
                tx: transaction
            )

            // Still on, because our PNI changed!
            XCTAssert(identityManager.shouldSharePhoneNumber(with: otherAci, tx: transaction))
        }
    }
