  func test_loadThenBitwiseOr_releasing() {
    let a: UInt8 = 3
    let b: UInt8 = 8
    let c: UInt8 = 12
    let result1: UInt8 = a | b
    let result2: UInt8 = result1 | c

    let v: UnsafeAtomic<UInt8> = .create(a)
    defer { v.destroy() }

    let old1: UInt8 = v.loadThenBitwiseOr(with: b, ordering: .releasing)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: UInt8 = v.loadThenBitwiseOr(with: c, ordering: .releasing)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
