    func testWriteLengthPrefixedNeedsMoreThanReservedCapacity() {
        struct TestStrategy: NIOBinaryIntegerEncodingStrategy {
            func readInteger<IntegerType: FixedWidthInteger>(
                as: IntegerType.Type,
                from buffer: inout ByteBuffer
            ) -> IntegerType? {
                XCTFail("This should not be called")
                return 1
            }

            func writeInteger<IntegerType: FixedWidthInteger>(
                _ integer: IntegerType,
                to buffer: inout ByteBuffer
            ) -> Int {
                XCTFail("This should not be called")
                return 1
            }

            func writeInteger(
                _ integer: Int,
                reservedCapacity: Int,
                to buffer: inout ByteBuffer
            ) -> Int {
                XCTAssertEqual(Int(integer), 4)
                XCTAssertEqual(reservedCapacity, 1)
                // We use 8 bytes, but only one was reserved
                return buffer.writeInteger(UInt64(integer))
            }

            var requiredBytesHint: Int { 1 }
        }

        var buffer = ByteBuffer()
        buffer.writeLengthPrefixed(strategy: TestStrategy()) { writer in
            writer.writeString("test")
        }

        // The strategy above uses 8 bytes for encoding the length. The data is 4, making a total of 12 bytes written
        XCTAssertEqual(buffer.readableBytes, 12)
        XCTAssertEqual(buffer.readBytes(length: 12), [0, 0, 0, 0, 0, 0, 0, 4] + "test".utf8)
        XCTAssertTrue(buffer.readableBytesView.isEmpty)
    }
