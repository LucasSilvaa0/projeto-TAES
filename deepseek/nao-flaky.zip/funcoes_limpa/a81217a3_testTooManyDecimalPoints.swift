    func testTooManyDecimalPoints() {
        let input = "0.5.6"
        XCTAssertThrowsError(try tokenize(input)) { error in
            XCTAssertEqual(error as? LexerError, .unrecognizedInput("0.5.6"))
        }
    }
