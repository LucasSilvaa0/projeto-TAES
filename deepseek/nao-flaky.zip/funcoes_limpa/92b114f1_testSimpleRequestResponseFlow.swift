    func testSimpleRequestResponseFlow() {
        let streamOne = HTTP2StreamID(1)

        self.exchangePreamble()

        assertSucceeds(
            self.client.sendHeaders(
                streamID: streamOne,
                headers: ConnectionStateMachineTests.requestHeaders,
                isEndStreamSet: true
            )
        )
        assertSucceeds(
            self.server.receiveHeaders(
                streamID: streamOne,
                headers: ConnectionStateMachineTests.requestHeaders,
                isEndStreamSet: true
            )
        )

        assertSucceeds(
            self.server.sendHeaders(
                streamID: streamOne,
                headers: ConnectionStateMachineTests.responseHeaders,
                isEndStreamSet: true
            )
        )
        assertSucceeds(
            self.client.receiveHeaders(
                streamID: streamOne,
                headers: ConnectionStateMachineTests.responseHeaders,
                isEndStreamSet: true
            )
        )

        assertSucceeds(self.client.sendGoaway(lastStreamID: .rootStream))
        assertSucceeds(self.server.receiveGoaway(lastStreamID: .rootStream))
        assertSucceeds(self.server.sendGoaway(lastStreamID: streamOne))
        assertSucceeds(self.client.receiveGoaway(lastStreamID: streamOne))

        XCTAssertTrue(self.client.fullyQuiesced)
        XCTAssertTrue(self.server.fullyQuiesced)
    }
