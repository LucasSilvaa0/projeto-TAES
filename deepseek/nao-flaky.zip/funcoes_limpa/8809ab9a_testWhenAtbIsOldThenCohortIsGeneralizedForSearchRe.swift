    func testWhenAtbIsOldThenCohortIsGeneralizedForSearchRetention() {

        store.atb = "v117-2"
        store.searchRetentionAtb = "v117-2"

        let waitForCompletion = expectation(description: "wait for completion")
        loader.refreshSearchRetentionAtb {
            waitForCompletion.fulfill()
        }

        wait(for: [waitForCompletion], timeout: 5.0)

        XCTAssertNotNil(store.searchRetentionAtb)
        XCTAssertEqual(store.atb, "v117-1")
    }
