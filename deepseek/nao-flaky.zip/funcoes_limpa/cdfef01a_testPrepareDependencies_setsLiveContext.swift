  func testPrepareDependencies_setsLiveContext() {
    prepareDependencies {
      $0.context = .live
    }
    @Dependency(\.context) var context
    XCTAssertEqual(context, .live)
    @Dependency(FullDependency.self) var client
    XCTAssertEqual(client.value, FullDependency.liveValue.value)
  }
