  func test_loadThenBitwiseXor_sequentiallyConsistent() {
    let a: UInt = 3
    let b: UInt = 8
    let c: UInt = 12
    let result1: UInt = a ^ b
    let result2: UInt = result1 ^ c

    let v: UnsafeAtomic<UInt> = .create(a)
    defer { v.destroy() }

    let old1: UInt = v.loadThenBitwiseXor(with: b, ordering: .sequentiallyConsistent)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: UInt = v.loadThenBitwiseXor(with: c, ordering: .sequentiallyConsistent)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
