    func test_fileType_forHFile() {
        let file: File = "bridging-header.h"
        let unknownFile: File = "bridging-header.hm"

        let expectedType: FileType = .h

        XCTAssertEqual(file.fileType, expectedType)
        XCTAssertNil(unknownFile.fileType)
    }
