    func testNextPowerOfTwoOfFive() {
        XCTAssertEqual(8, (5 as UInt).nextPowerOf2())
        XCTAssertEqual(8, (5 as UInt16).nextPowerOf2())
        XCTAssertEqual(8, (5 as UInt32).nextPowerOf2())
        XCTAssertEqual(8, (5 as UInt64).nextPowerOf2())
        XCTAssertEqual(8, (5 as Int).nextPowerOf2())
        XCTAssertEqual(8, (5 as Int16).nextPowerOf2())
        XCTAssertEqual(8, (5 as Int32).nextPowerOf2())
        XCTAssertEqual(8, (5 as Int64).nextPowerOf2())
    }
