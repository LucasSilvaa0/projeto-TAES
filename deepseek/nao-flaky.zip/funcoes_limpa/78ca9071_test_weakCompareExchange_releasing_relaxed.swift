  func test_weakCompareExchange_releasing_relaxed() {
    let v: UnsafeAtomic<UnsafeRawPointer?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeRawPointer?)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: nil,
        desired: _raw2,
        successOrdering: .releasing,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    (exchanged, original) = v.weakCompareExchange(
      expected: nil,
      desired: _raw2,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _raw2,
        desired: nil,
        successOrdering: .releasing,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.weakCompareExchange(
      expected: _raw2,
      desired: nil,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
