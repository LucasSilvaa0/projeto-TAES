  func testReverse() {
    var numbers = [10, 20, 30, 40, 50, 60, 70, 80]
    numbers.reverse(subrange: 0..<4)
    XCTAssertEqual(numbers, [40, 30, 20, 10, 50, 60, 70, 80])
  }
