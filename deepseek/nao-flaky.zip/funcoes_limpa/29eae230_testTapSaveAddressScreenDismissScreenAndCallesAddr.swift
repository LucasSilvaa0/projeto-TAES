    func testTapSaveAddressScreenDismissScreenAndCallesAddressFetching() {
        let address = dummyAddresses[0]
        mockAutofill.mockSaveAddressResult = .success(address)
        viewModel.saveAction = { completion in
            completion(UpdatableAddressFields(
                name: "John Doe",
                organization: "Acme Corp",
                streetAddress: "123 Main St",
                addressLevel3: "Suite 100",
                addressLevel2: "San Francisco",
                addressLevel1: "CA",
                postalCode: "94101",
                country: "USA",
                tel: "+1-555-1234",
                email: "john.doe@example.com"
            ))
        }
        let dismissSectionAddExpectation = XCTestExpectation(description: "Dimiss add section")
        let newAddressesSectionExpectation = XCTestExpectation(description: "New address loaded")

        viewModel.addAddressButtonTap()
        viewModel.saveAddressButtonTap()

        viewModel
            .$destination
            .dropFirst()
            .sink { value in
                XCTAssertNil(value)
                dismissSectionAddExpectation.fulfill()
            }
            .store(in: &cancellables)

        viewModel
            .$addresses
            .dropFirst()
            .sink { _ in
                XCTAssertEqual(self.mockAutofill.listAllAddressesCalled, true)
                newAddressesSectionExpectation.fulfill()
            }
            .store(in: &cancellables)
    }
