  func test_exchange_releasing() {
    let v: UnsafeAtomic<DoubleWord> = .create(DoubleWord(first: 100, second: 64))
    defer { v.destroy() }

    XCTAssertEqual(v.exchange(DoubleWord(first: 100, second: 64), ordering: .releasing), DoubleWord(first: 100, second: 64))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 100, second: 64))

    XCTAssertEqual(v.exchange(DoubleWord(first: 50, second: 32), ordering: .releasing), DoubleWord(first: 100, second: 64))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 50, second: 32))

    XCTAssertEqual(v.exchange(DoubleWord(first: 50, second: 32), ordering: .releasing), DoubleWord(first: 50, second: 32))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 50, second: 32))
  }
