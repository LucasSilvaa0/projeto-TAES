    func testEnvironment_setToNil() {
        let sut = fixture.sut
        sut.setEnvironment(fixture.environment)
        sut.setEnvironment(nil)

        XCTAssertNil(getScopeJson { $0.environment })
    }
