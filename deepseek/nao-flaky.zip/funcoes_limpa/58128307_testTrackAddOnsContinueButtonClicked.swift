  func testTrackAddOnsContinueButtonClicked() {
    let segmentClient = MockTrackingClient()
    let ksrAnalytics = KSRAnalytics(
      segmentClient: segmentClient,
      appTrackingTransparency: self.appTrackingTransparency
    )

    let project = Project.template
    let reward = Reward.template
      |> Reward.lens.shipping.preference .~ .restricted
      |> Reward.lens.endsAt .~ MockDate().addingTimeInterval(5).timeIntervalSince1970

    ksrAnalytics
      .trackAddOnsContinueButtonClicked(
        project: project,
        reward: reward,
        checkoutData: .template,
        refTag: nil
      )

    XCTAssertEqual(["CTA Clicked"], segmentClient.events)

    let segmentClientProps = segmentClient.properties.last

    XCTAssertEqual("add_ons_continue", segmentClientProps?["context_cta"] as? String)

    XCTAssertEqual("add_ons", segmentClientProps?["context_page"] as? String)

    self.assertProjectProperties(segmentClientProps)

    self.assertCheckoutProperties(segmentClientProps)
  }
