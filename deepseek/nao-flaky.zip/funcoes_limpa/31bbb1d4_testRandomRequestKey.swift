    func testRandomRequestKey() {
        var generator = TestRandomNumberGenerator(numbers: [10, 11])
        let requestKey = NIOWebSocketClientUpgrader.randomRequestKey(using: &generator)
        XCTAssertEqual(requestKey, "AAAAAAAAAAoAAAAAAAAACw==")
    }
