    func testInferLowercaseExponent() {
        let input = "[1.34E-5, 1.34e-5]"
        let options = inferFormatOptions(from: tokenize(input))
        XCTAssertFalse(options.uppercaseExponent)
    }
