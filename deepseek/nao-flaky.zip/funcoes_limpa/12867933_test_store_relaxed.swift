  func test_store_relaxed() {
    let v: UnsafeAtomic<Int> = .create(12)
    defer { v.destroy() }
    v.store(23, ordering: .relaxed)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    let w: UnsafeAtomic<Int> = .create(23)
    defer { w.destroy() }
    w.store(12, ordering: .relaxed)
    XCTAssertEqual(w.load(ordering: .relaxed), 12)
  }
