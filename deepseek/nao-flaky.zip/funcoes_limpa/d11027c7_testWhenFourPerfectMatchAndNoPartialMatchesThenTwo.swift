    func testWhenFourPerfectMatchAndNoPartialMatchesThenTwoPerfectMatchesAndMoreOptionsShown() {
        let accountMatches = AccountMatches(perfectMatches: [websiteAccountFor(domain: "example.com", username: "dax@duck.com"),
                                                             websiteAccountFor(domain: "example.com", username: "dax2@duck.com"),
                                                             websiteAccountFor(domain: "example.com", username: "dax3@duck.com"),
                                                             websiteAccountFor(domain: "example.com", username: "dax4@duck.com")],
                                            partialMatches: [:])
        let autofillLoginPromptViewModel = AutofillLoginPromptViewModel(accounts: accountMatches,
                                                                        domain: "example.com",
                                                                        isExpanded: false)
        XCTAssertEqual(autofillLoginPromptViewModel.accountMatchesViewModels.count, 1)
        XCTAssertTrue(autofillLoginPromptViewModel.accountMatchesViewModels[0].isPerfectMatch)
        XCTAssertEqual(autofillLoginPromptViewModel.accountMatchesViewModels[0].accounts.count, 2)
        XCTAssertTrue(autofillLoginPromptViewModel.showMoreOptions)
    }
