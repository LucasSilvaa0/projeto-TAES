    func testShowBookmarkDetail_forFolderCreation() {
        let subject = createSubject(isBookmarkRefactorEnabled: true)

        subject.showBookmarkDetail(bookmarkType: .folder, parentBookmarkFolder: LocalDesktopFolder())

        XCTAssertTrue(router.pushedViewController is EditFolderViewController)
        XCTAssertEqual(router.pushCalled, 1)
    }
