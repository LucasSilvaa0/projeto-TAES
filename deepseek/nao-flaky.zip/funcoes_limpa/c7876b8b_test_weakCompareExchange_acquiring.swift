  func test_weakCompareExchange_acquiring() {
    let v: UnsafeAtomic<Baz> = .create(_baz1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Baz)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _baz1,
        desired: _baz2,
        ordering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, _baz1)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    (exchanged, original) = v.weakCompareExchange(
      expected: _baz1,
      desired: _baz2,
      ordering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _baz2,
        desired: _baz1,
        ordering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz1)

    (exchanged, original) = v.weakCompareExchange(
      expected: _baz2,
      desired: _baz1,
      ordering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _baz1)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz1)
  }
