    func testRemoteDevicesChanged() {
        let initialState = createSubject()
        let reducer = remoteTabsPanelReducer()
        let deviceId = "AAAAAA"
        let device = Device(id: deviceId,
                            displayName: "test device",
                            deviceType: .mobile,
                            capabilities: [.closeTabs, .sendTab],
                            pushSubscription: nil,
                            pushEndpointExpired: false,
                            isCurrentDevice: true,
                            lastAccessTime: nil)

        let action = RemoteTabsPanelAction(clientAndTabs: nil,
                                           devices: [device],
                                           windowUUID: WindowUUID.XCTestDefaultUUID,
                                           actionType: RemoteTabsPanelActionType.remoteDevicesChanged)
        let newState = reducer(initialState, action)

        XCTAssertEqual(newState.devices.count, 1)
        XCTAssertEqual(newState.devices[0].id, deviceId)
    }
