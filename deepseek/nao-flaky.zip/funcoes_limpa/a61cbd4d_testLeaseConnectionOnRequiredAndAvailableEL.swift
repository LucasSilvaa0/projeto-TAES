    func testLeaseConnectionOnRequiredAndAvailableEL() {
        let elg = EmbeddedEventLoopGroup(loops: 2)
        let el1 = elg.next()
        let el2 = elg.next()

        var connections = HTTPConnectionPool.HTTP1Connections(
            maximumConcurrentConnections: 8,
            generator: .init(),
            maximumConnectionUses: nil
        )

        for el in [el1, el1, el1, el1, el2] {
            let connID = connections.createNewConnection(on: el)
            let conn: HTTPConnectionPool.Connection = .__testOnly_connection(id: connID, eventLoop: el)
            _ = connections.newHTTP1ConnectionEstablished(conn)
        }

        // 1. get el from general pool, even though el is required!
        guard let lease1 = connections.leaseConnection(onRequired: el1) else {
            return XCTFail("Expected to get a connection at this point.")
        }
        // the last created connection on the correct el is the shortest amount idle. we should use this
        XCTAssertEqual(lease1, .__testOnly_connection(id: 3, eventLoop: el1))
        _ = connections.releaseConnection(lease1.id)

        // 2. create specialized el connection
        let connID5 = connections.createNewOverflowConnection(on: el1)
        XCTAssertEqual(connections.startingEventLoopConnections(on: el1), 1)
        let conn5: HTTPConnectionPool.Connection = .__testOnly_connection(id: connID5, eventLoop: el1)
        _ = connections.newHTTP1ConnectionEstablished(conn5)
        XCTAssertEqual(connections.startingEventLoopConnections(on: el1), 0)

        // 3. get el from specialized pool, since it is the newest!
        guard let lease2 = connections.leaseConnection(onRequired: el1) else {
            return XCTFail("Expected to get a connection at this point.")
        }
        XCTAssertEqual(lease2, conn5)
        _ = connections.releaseConnection(lease2.id)

        // 4. create another general purpose connection on the correct el
        let connID6 = connections.createNewConnection(on: el1)
        let conn6: HTTPConnectionPool.Connection = .__testOnly_connection(id: connID6, eventLoop: el1)
        _ = connections.newHTTP1ConnectionEstablished(conn6)

        // 5. get el from general pool, since it is the newest!
        guard let lease3 = connections.leaseConnection(onRequired: el1) else {
            return XCTFail("Expected to get a connection at this point.")
        }
        // the last created connection is the shortest amount idle. we should use this
        XCTAssertEqual(lease3, conn6)

        _ = connections.releaseConnection(lease3.id)
    }
