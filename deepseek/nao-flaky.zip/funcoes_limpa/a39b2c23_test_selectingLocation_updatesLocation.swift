  func test_selectingLocation_updatesLocation() {
    self.initialObserver.send(value: ())

    self.assert_selectedLocation_isDefault()

    let location = threeLocations[1]

    self.useCase.inputs.selectedFilter(.location(location))

    guard let newSelectedLocation = self.selectedLocation.lastValue else {
      XCTFail("There should be a new selected location")
      return
    }

    XCTAssertEqual(
      newSelectedLocation,
      location,
      "Selected location value should change when location is selected"
    )
  }
