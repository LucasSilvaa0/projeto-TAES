    func testDecodeLoopGetsInterruptedWhenRemovalIsTriggered() {
        struct Decoder: ByteToMessageDecoder {
            typealias InboundOut = String

            var callsToDecode = 0
            var callsToDecodeLast = 0

            mutating func decode(context: ChannelHandlerContext, buffer: inout ByteBuffer) throws -> DecodingState {
                XCTAssertEqual(9, buffer.readableBytes)
                self.callsToDecode += 1
                XCTAssertEqual(1, self.callsToDecode)
                context.fireChannelRead(
                    Self.wrapInboundOut(
                        String(
                            decoding: buffer.readBytes(length: 1)!,
                            as: Unicode.UTF8.self
                        )
                    )
                )
                context.pipeline.syncOperations.removeHandler(context: context).whenFailure { error in
                    XCTFail("unexpected error: \(error)")
                }
                return .continue
            }

            mutating func decodeLast(
                context: ChannelHandlerContext,
                buffer: inout ByteBuffer,
                seenEOF: Bool
            ) throws -> DecodingState {
                XCTAssertFalse(seenEOF)
                self.callsToDecodeLast += 1
                XCTAssertLessThanOrEqual(self.callsToDecodeLast, 2)
                context.fireChannelRead(
                    Self.wrapInboundOut(
                        String(
                            decoding: buffer.readBytes(length: 4) ?? [  // "no bytes"
                                0x6e, 0x6f, 0x20,
                                0x62, 0x79, 0x74, 0x65, 0x73,
                            ],
                            as: Unicode.UTF8.self
                        ) + "#\(self.callsToDecodeLast)"
                    )
                )
                return .continue
            }
        }

        let handler = ByteToMessageHandler(Decoder())
        let channel = EmbeddedChannel(handler: handler)
        defer {
            XCTAssertNoThrow(XCTAssertTrue(try channel.finish().isClean))
        }

        var buffer = channel.allocator.buffer(capacity: 9)
        buffer.writeStaticString("012345678")
        XCTAssertNoThrow(try channel.writeInbound(buffer))
        channel.embeddedEventLoop.run()
        XCTAssertEqual(1, handler.decoder?.callsToDecode)
        XCTAssertEqual(2, handler.decoder?.callsToDecodeLast)
        for expected in ["0", "1234#1", "5678#2"] {
            func workaroundSR9815() {
                XCTAssertNoThrow(XCTAssertEqual(expected, try channel.readInbound()))
            }
            workaroundSR9815()
        }
    }
