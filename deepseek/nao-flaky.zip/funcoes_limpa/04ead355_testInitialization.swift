    func testInitialization() {
        XCTAssertEqual(initializing.loadState, .initializing)
    }
