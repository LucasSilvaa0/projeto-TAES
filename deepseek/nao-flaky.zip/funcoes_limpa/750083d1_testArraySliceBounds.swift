    func testArraySliceBounds() {
        let expression = AnyExpression("array[2]", constants: [
            "array": ArraySlice(["hello", "world"]),
        ])
        XCTAssertThrowsError(try expression.evaluate() as Any) { error in
            XCTAssertEqual(error as? Expression.Error, .arrayBounds(.array("array"), 2))
        }
    }
