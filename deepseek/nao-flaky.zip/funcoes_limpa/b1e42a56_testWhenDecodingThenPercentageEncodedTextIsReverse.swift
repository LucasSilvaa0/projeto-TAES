    func testWhenDecodingThenPercentageEncodedTextIsReversed() {
        let input = "test%20%22%25-.%3C%3E%5C%5E_%60%7B%7C~"
        let expected = "test \"%-.<>\\^_`{|~"
        let actual = URL.decode(query: input)
        XCTAssertEqual(expected, actual)
    }

    func testWhenUrlProtocolIsHttpThenIsHttpsIsFalse() {
        let url = URL(string: "http://test.com")!
        XCTAssertFalse(url.isHttps)
    }

    func testWhenUrlProtocolIsHttpsThenIsHttpsIsTrue() {
        let url = URL(string: "https://test.com")!
        XCTAssertTrue(url.isHttps)
    }

    func testWhenUrlProtocolIsNonHttpThenIsHttpsIsFalse() {
        let url = URL(string: "mailto://test.com")!
        XCTAssertFalse(url.isHttps)
    }
    
    func testWhenHostMatchesDomainThenIsPartOfDomainIsTrue() {
        let url = URL(string: "http://example.com/index.html")!
        XCTAssertTrue(url.isPart(ofDomain: "example.com"))
    }
    
    func testWhenHostIsSubdomainThenIsPartOfDomainIsTrue() {
        let url = URL(string: "http://subdomain.example.com/index.html")!
        XCTAssertTrue(url.isPart(ofDomain: "example.com"))
    }
    
    func testWhenHostDoesNotMatchThenIsPartOfDomainIsFalse() {
        let url = URL(string: "http://notexample.com/index.html")!
        XCTAssertFalse(url.isPart(ofDomain: "example.com"))
    }

    func testWhenBookmarkletIsValid() {
        let alert = "javascript:(function() { alert(1) })()".toEncodedBookmarklet()!
        let allowReferenceError = "javascript:document".toEncodedBookmarklet()!
        XCTAssertTrue(URL.isValidBookmarklet(url: alert))
        XCTAssertTrue(URL.isValidBookmarklet(url: allowReferenceError))
    }

    func testWhenBookmarkletIsNotValid() {
        let invalidSyntax = "javascript:(fun() { alert(1) })()".toEncodedBookmarklet()!
        let invalidSyntax2 = "javascript:/".toEncodedBookmarklet()!
        XCTAssertFalse(URL.isValidBookmarklet(url: invalidSyntax))
        XCTAssertFalse(URL.isValidBookmarklet(url: invalidSyntax2))
    }

    func testWhenNormalizingURLWithNoParametersThenURLIsUnchanged() {
        let url = URL(string: "http://example.com/index.html")!
        let normalized = url.normalized()

        XCTAssertEqual(url, normalized)
    }

    func testWhenNormalizingURLWithParametersThenParametersAreRemoved() {
        let url = URL(string: "https://example.com/Path?abc=xyz")!
        let expected = URL(string: "https://example.com/Path")!
        let normalized = url.normalized()

        XCTAssertEqual(normalized, expected)
    }

    func testWhenNormalizingURLWithNoFragmentThenURLIsUnchanged() {
        let url = URL(string: "http://example.com/index.html")!
        let normalized = url.normalized()

        XCTAssertEqual(url, normalized)
    }

    func testWhenNormalizingURLWithFragmentThenFragmentIsRemoved() {
        let url = URL(string: "https://example.com/Path#fragment")!
        let expected = URL(string: "https://example.com/Path")!
        let normalized = url.normalized()

        XCTAssertEqual(normalized, expected)
    }

    func testWhenNormalizingURLWithParametersAndFragmentThenBothAreRemoved() {
        let url = URL(string: "https://example.com/Path#fragment&firstParam=1&secondParam=2")!
        let expected = URL(string: "https://example.com/Path")!
        let normalized = url.normalized()

        XCTAssertEqual(normalized, expected)
    }

}
