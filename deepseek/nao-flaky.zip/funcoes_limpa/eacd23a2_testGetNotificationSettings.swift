    func testGetNotificationSettings() {
        let expectation = self.expectation(description: "notification manager")
        notificationManager.getNotificationSettings { settings in
            XCTAssertTrue(self.center.getSettingsWasCalled)
            expectation.fulfill()
        }
        waitForExpectations(timeout: 5)
    }
