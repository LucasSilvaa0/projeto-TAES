    func testDownloadQueueIsNotEmpty() {
        queue.downloads = [download]
        XCTAssertTrue(!queue.isEmpty)
    }
