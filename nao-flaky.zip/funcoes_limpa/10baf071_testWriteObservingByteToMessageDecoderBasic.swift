    func testWriteObservingByteToMessageDecoderBasic() {
        class Decoder: WriteObservingByteToMessageDecoder {
            typealias OutboundIn = Int
            typealias InboundOut = String

            var allObservedWrites: [Int] = []

            func write(data: Int) {
                self.allObservedWrites.append(data)
            }

            func decode(context: ChannelHandlerContext, buffer: inout ByteBuffer) throws -> DecodingState {
                if let string = buffer.readString(length: 1) {
                    context.fireChannelRead(Self.wrapInboundOut(string))
                    return .continue
                } else {
                    return .needMoreData
                }
            }

            func decodeLast(
                context: ChannelHandlerContext,
                buffer: inout ByteBuffer,
                seenEOF: Bool
            ) throws -> DecodingState {
                while case .continue = try self.decode(context: context, buffer: &buffer) {}
                return .needMoreData
            }
        }

        let decoder = Decoder()
        let channel = EmbeddedChannel(handler: ByteToMessageHandler(decoder))
        XCTAssertNoThrow(try channel.connect(to: SocketAddress(ipAddress: "1.2.3.4", port: 5678)).wait())
        var buffer = channel.allocator.buffer(capacity: 3)
        buffer.writeStaticString("abc")
        XCTAssertNoThrow(try channel.writeInbound(buffer))
        XCTAssertNoThrow(try channel.writeOutbound(1))
        XCTAssertNoThrow(try channel.writeOutbound(2))
        XCTAssertNoThrow(try channel.writeOutbound(3))
        XCTAssertEqual([1, 2, 3], decoder.allObservedWrites)
        XCTAssertNoThrow(XCTAssertEqual("a", try channel.readInbound()))
        XCTAssertNoThrow(XCTAssertEqual("b", try channel.readInbound()))
        XCTAssertNoThrow(XCTAssertEqual("c", try channel.readInbound()))
        XCTAssertNoThrow(XCTAssertEqual(1, try channel.readOutbound()))
        XCTAssertNoThrow(XCTAssertEqual(2, try channel.readOutbound()))
        XCTAssertNoThrow(XCTAssertEqual(3, try channel.readOutbound()))
        XCTAssertNoThrow(XCTAssertTrue(try channel.finish().isClean))
    }
