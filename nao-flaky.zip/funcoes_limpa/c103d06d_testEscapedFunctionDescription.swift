    func testEscapedFunctionDescription() {
        let expression = Expression.parse("`hello\\tworld`(x)")
        XCTAssertEqual(expression.description, "`hello\\tworld`(x)")
    }
