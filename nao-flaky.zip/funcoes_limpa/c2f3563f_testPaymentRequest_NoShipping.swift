  func testPaymentRequest_NoShipping() {
    var project = Project.template
    project.country = .us
    project.isInPostCampaignPledgingPhase = false

    let reward = Reward.noReward
    let merchantId = "merchant_id"

    let paymentRequest = PKPaymentRequest.paymentRequest(
      for: project,
      reward: reward,
      allRewardsTotal: 100,
      additionalPledgeAmount: 50,
      allRewardsShippingTotal: 0,
      merchantIdentifier: merchantId
    )

    XCTAssertEqual(paymentRequest.merchantIdentifier, merchantId)
    XCTAssertEqual(paymentRequest.merchantCapabilities, .capability3DS)
    XCTAssertEqual(paymentRequest.countryCode, "US")
    XCTAssertEqual(paymentRequest.currencyCode, "USD")
    XCTAssertEqual(paymentRequest.shippingType, .shipping)
    XCTAssertEqual(paymentRequest.paymentSummaryItems.count, 2)
    XCTAssertEqual(paymentRequest.paymentSummaryItems.first?.label, "Total")
    XCTAssertEqual(paymentRequest.paymentSummaryItems.first?.amount.doubleValue, 50)
    XCTAssertEqual(paymentRequest.paymentSummaryItems.first?.type, .final)
    XCTAssertEqual(paymentRequest.paymentSummaryItems.last?.label, "Kickstarter (if funded)")
    XCTAssertEqual(paymentRequest.paymentSummaryItems.last?.amount.doubleValue, 50)
    XCTAssertEqual(paymentRequest.paymentSummaryItems.last?.type, .final)
  }
