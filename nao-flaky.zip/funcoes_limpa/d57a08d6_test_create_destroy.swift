  func test_create_destroy() {
    let v: UnsafeAtomic<Int8> = .create(12)
    defer { v.destroy() }
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    let w: UnsafeAtomic<Int8> = .create(23)
    defer { w.destroy() }
    XCTAssertEqual(w.load(ordering: .relaxed), 23)
  }
