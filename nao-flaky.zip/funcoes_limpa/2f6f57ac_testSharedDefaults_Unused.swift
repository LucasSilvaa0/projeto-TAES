  func testSharedDefaults_Unused() {
    let didAccess = LockIsolated(false)
    let logDefault: () -> Bool = {
      didAccess.setValue(true)
      return true
    }
    @Shared(.isActive(default: logDefault)) var isActive = false
    XCTAssertEqual(isActive, false)
    XCTAssertEqual(didAccess.value, false)
  }
