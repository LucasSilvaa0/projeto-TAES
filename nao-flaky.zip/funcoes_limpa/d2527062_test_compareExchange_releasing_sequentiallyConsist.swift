  func test_compareExchange_releasing_sequentiallyConsistent() {
    let v: UnsafeAtomic<UInt> = .create(12)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UInt) = v.compareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .releasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .releasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .releasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .releasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)
  }
