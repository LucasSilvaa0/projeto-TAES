  func testPartitionedWithEmptyInput() {
    let input: [Int] = []
    
    let s0 = input.partitioned(by: { _ in return true })
    
    XCTAssertTrue(s0.0.isEmpty)
    XCTAssertTrue(s0.1.isEmpty)
  }
