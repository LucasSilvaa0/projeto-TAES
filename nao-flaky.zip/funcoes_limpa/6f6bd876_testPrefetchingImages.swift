    func testPrefetchingImages() {
        let exp = expectation(description: #function)
        
        testURLs.forEach { stub($0, data: testImageData) }
        var progressCalledCount = 0
        let prefetcher = ImagePrefetcher(
            urls: testURLs,
            options: [.waitForCache],
            progressBlock: { _, _, _ in progressCalledCount += 1 }) {
                skippedResources, failedResources, completedResources in

                XCTAssertEqual(skippedResources.count, 0)
                XCTAssertEqual(failedResources.count, 0)
                XCTAssertEqual(completedResources.count, testURLs.count)
                XCTAssertEqual(progressCalledCount, testURLs.count)
                for url in testURLs {
                    XCTAssertTrue(KingfisherManager.shared.cache.imageCachedType(forKey: url.absoluteString).cached)
                }
                exp.fulfill()
            }
        prefetcher.start()
        waitForExpectations(timeout: 3, handler: nil)
    }
