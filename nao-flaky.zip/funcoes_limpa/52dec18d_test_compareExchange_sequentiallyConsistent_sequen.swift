  func test_compareExchange_sequentiallyConsistent_sequentiallyConsistent() {
    let v: UnsafeAtomic<Hyacinth?> = .create(Hyacinth.bucket)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Hyacinth?) = v.compareExchange(
      expected: Hyacinth.bucket,
      desired: nil,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, Hyacinth.bucket)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.compareExchange(
      expected: Hyacinth.bucket,
      desired: nil,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.compareExchange(
      expected: nil,
      desired: Hyacinth.bucket,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), Hyacinth.bucket)

    (exchanged, original) = v.compareExchange(
      expected: nil,
      desired: Hyacinth.bucket,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, Hyacinth.bucket)
    XCTAssertEqual(v.load(ordering: .relaxed), Hyacinth.bucket)
  }
