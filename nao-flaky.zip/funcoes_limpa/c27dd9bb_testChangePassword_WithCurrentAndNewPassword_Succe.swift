  func testChangePassword_WithCurrentAndNewPassword_Success() {
    let input = ChangePasswordInput(
      currentPassword: "pass0",
      newPassword: "pass1",
      newPasswordConfirmation: "pass1"
    )

    let graphInput = GraphAPI.UpdateUserAccountInput.from(input)

    XCTAssertEqual(graphInput.currentPassword.unwrapped, input.currentPassword)
    XCTAssertEqual(graphInput.password.unwrapped, input.newPassword)
    XCTAssertEqual(graphInput.passwordConfirmation.unwrapped, input.newPasswordConfirmation)
  }
