  func testEquality() {
    struct State {
      @BindingState var count = 0
    }
    XCTAssertEqual(
      BindingAction<State>.set(\.$count, 1),
      BindingAction<State>.set(\.$count, 1)
    )
    XCTAssertNotEqual(
      BindingAction<State>.set(\.$count, 1),
      BindingAction<State>.set(\.$count, 2)
    )
  }
