    func testValidRegionDE() {
        let locale = Locale(identifier: "de_DE")
        XCTAssertTrue(
            AddressLocaleFeatureValidator.isValidRegion(locale: locale),
            "Valid region for DE"
        )
    }
