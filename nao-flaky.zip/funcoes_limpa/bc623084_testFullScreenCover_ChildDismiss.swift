  func testFullScreenCover_ChildDismiss() {
    self.app.buttons["Open full screen cover"].tap()
    XCTAssertEqual(self.app.staticTexts["Count: 0"].exists, true)

    self.app.buttons["Increment"].tap()
    XCTAssertEqual(self.app.staticTexts["Count: 1"].exists, true)
    self.app.buttons["Increment"].tap()
    XCTAssertEqual(self.app.staticTexts["Count: 2"].exists, true)

    self.app.buttons["Child dismiss"].tap()
    XCTAssertEqual(
      self.app.staticTexts["Count: 2"].waitForExistence(timeout: 1),
      false
    )
  }
