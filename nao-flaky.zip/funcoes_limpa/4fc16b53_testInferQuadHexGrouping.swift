    func testInferQuadHexGrouping() {
        let input = "[0x123_FF23, 0x1_4523, 0x5, 0x23, 0x14]"
        let options = inferFormatOptions(from: tokenize(input))
        XCTAssertEqual(options.hexGrouping, .group(4, 5))
    }
