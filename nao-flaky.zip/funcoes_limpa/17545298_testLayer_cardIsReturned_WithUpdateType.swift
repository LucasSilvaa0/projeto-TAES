    func testLayer_cardIsReturned_WithUpdateType() {
        configUtility.setupNimbusWith(onboardingType: .upgrade)
        let layer = NimbusOnboardingFeatureLayer(with: MockNimbusMessagingHelperUtility())

        guard let subject = layer.getOnboardingModel(for: .upgrade).cards.first else {
            XCTFail("Expected a card, and got none.")
            return
        }

        XCTAssertEqual(subject.onboardingType, OnboardingType.upgrade)
    }
