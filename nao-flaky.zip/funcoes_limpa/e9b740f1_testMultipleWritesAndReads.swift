    func testMultipleWritesAndReads() {
        let errorCodes: [WebSocketErrorCode] = [.goingAway, .unacceptableData, .protocolError]
        for errorCode in errorCodes {
            buffer.write(webSocketErrorCode: errorCode)
        }

        // Peek each one before reading to verify
        for (index, expected) in errorCodes.enumerated() {
            let offset = index * 2
            let peeked = buffer.getWebSocketErrorCode(at: buffer.readerIndex + offset)
            XCTAssertEqual(peeked, expected)
        }

        for expected in errorCodes {
            let read = buffer.readWebSocketErrorCode()
            XCTAssertEqual(read, expected)
        }

        XCTAssertEqual(buffer.readableBytes, 0, "Buffer should be fully consumed")
    }
