  func testChangePaymentMethod() {
    let context = PledgeViewContext.changePaymentMethod

    XCTAssertTrue(context.confirmationLabelHidden)
    XCTAssertTrue(context.continueViewHidden)
    XCTAssertTrue(context.descriptionViewHidden)
    XCTAssertTrue(context.expandableRewardViewHidden)
    XCTAssertTrue(context.isUpdating)
    XCTAssertFalse(context.isCreating)
    XCTAssertFalse(context.paymentMethodsViewHidden)
    XCTAssertTrue(context.pledgeAmountViewHidden)
    XCTAssertFalse(context.pledgeAmountSummaryViewHidden)
    XCTAssertTrue(context.sectionSeparatorsHidden)
    XCTAssertEqual(context.submitButtonTitle, "Confirm")
    XCTAssertEqual(context.title, "Change payment method")
  }
