    func testMigrationFromHTTP2() {
        let elg = EmbeddedEventLoopGroup(loops: 4)
        let generator = HTTPConnectionPool.Connection.ID.Generator()
        var connections = HTTPConnectionPool.HTTP1Connections(
            maximumConcurrentConnections: 8,
            generator: generator,
            maximumConnectionUses: nil
        )

        let el1 = elg.next()
        let el2 = elg.next()

        let conn1ID = generator.next()
        let conn2ID = generator.next()

        connections.migrateFromHTTP2(
            starting: [(conn1ID, el1)],
            backingOff: [(conn2ID, el2)]
        )
        let newConnections = connections.createConnectionsAfterMigrationIfNeeded(
            requiredEventLoopOfPendingRequests: [],
            generalPurposeRequestCountGroupedByPreferredEventLoop: [(el1, 1), (el2, 1)]
        )

        XCTAssertTrue(newConnections.isEmpty)

        let stats = connections.stats
        XCTAssertEqual(stats.idle, 0)
        XCTAssertEqual(stats.leased, 0)
        XCTAssertEqual(stats.connecting, 1)
        XCTAssertEqual(stats.backingOff, 1)
    }
