  func testAnyHashable() {
    XCTAssertNoDifference(
      diff(
        AnyHashable(42),
        AnyHashable(43)
      ),
      """
      - 42
      + 43
      """
    )

    XCTAssertNoDifference(
      diff(
        [
          AnyHashable(1): User(id: 1, name: "Blob"),
          AnyHashable("Blob, Jr."): User(id: 2, name: "Blob, Jr."),
        ],
        [
          AnyHashable(1): User(id: 1, name: "Blob, Sr."),
          AnyHashable("Blob, Jr."): User(id: 2, name: "Blob, Jr., Esq."),
        ]
      ),
      """
        [
          "Blob, Jr.": User(
            id: 2,
      -     name: "Blob, Jr."
      +     name: "Blob, Jr., Esq."
          ),
          1: User(
            id: 1,
      -     name: "Blob"
      +     name: "Blob, Sr."
          )
        ]
      """
    )
  }
