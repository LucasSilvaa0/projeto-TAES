    func testParameterizedStringConstant() {
        let node = LayoutNode(constants: ["strings.hello": "Hello %s"])
        let expression = LayoutExpression(expression: "{strings.hello('World')}", type: .string, for: node)
        XCTAssertEqual(try expression?.evaluate() as? String, "Hello World")
    }
