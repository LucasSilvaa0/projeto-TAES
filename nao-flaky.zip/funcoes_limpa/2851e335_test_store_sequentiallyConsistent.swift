  func test_store_sequentiallyConsistent() {
    let v: UnsafeAtomic<UInt8> = .create(12)
    defer { v.destroy() }
    v.store(23, ordering: .sequentiallyConsistent)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    let w: UnsafeAtomic<UInt8> = .create(23)
    defer { w.destroy() }
    w.store(12, ordering: .sequentiallyConsistent)
    XCTAssertEqual(w.load(ordering: .relaxed), 12)
  }
