  func testAnyObjectPayload() {
    class Class {}
    enum Enum { case anyObject(AnyObject) }
    let object = Class()
    let nsObject = NSObject()
    let path = /Enum.anyObject
    for _ in 1...2 {
      XCTAssert(try unwrap(path.extract(from: .anyObject(object))) === object)
      XCTAssert(try unwrap(path.extract(from: .anyObject(nsObject))) === nsObject)
    }
    XCTAssert(try unwrap(AnyCasePath(Enum.anyObject).extract(from: .anyObject(object))) === object)
    XCTAssert(
      try unwrap(AnyCasePath(Enum.anyObject).extract(from: .anyObject(nsObject))) === nsObject)
  }
