    func testGetChannelOptionAutoReadIsSupported() {
        let channel = EmbeddedChannel()
        let options = channel.syncOptions
        XCTAssertNotNil(options)
        // Unconditionally returns true.
        XCTAssertEqual(try options?.getOption(.autoRead), true)
    }
