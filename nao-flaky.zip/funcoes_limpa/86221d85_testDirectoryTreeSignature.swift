  func testDirectoryTreeSignature() {
    let directoryTreeSignature = BuildKey.DirectoryTreeSignature(path: "/foo/bar", filters: ["jpg", "png"])
    XCTAssertEqual(directoryTreeSignature.kind, .directoryTreeSignature)
    XCTAssertEqual(directoryTreeSignature.path, "/foo/bar")
    XCTAssertEqual(directoryTreeSignature.filters, ["jpg", "png"])
    XCTAssertFalse(directoryTreeSignature.keyData.isEmpty)
    XCTAssertEqual(directoryTreeSignature, directoryTreeSignature)
    XCTAssertNotEqual(directoryTreeSignature, BuildKey.DirectoryTreeSignature(path: "/foo/bar2", filters: ["jpg"]))
  }
