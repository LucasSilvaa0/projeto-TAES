  func test_compareExchange_relaxed() {
    let v: UnsafeAtomic<Baz?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Baz?) = v.compareExchange(
      expected: nil,
      desired: _baz2,
      ordering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    (exchanged, original) = v.compareExchange(
      expected: nil,
      desired: _baz2,
      ordering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    (exchanged, original) = v.compareExchange(
      expected: _baz2,
      desired: nil,
      ordering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.compareExchange(
      expected: _baz2,
      desired: nil,
      ordering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
