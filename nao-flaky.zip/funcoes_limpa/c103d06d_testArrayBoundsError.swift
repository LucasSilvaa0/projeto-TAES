    func testArrayBoundsError() {
        let expression = Expression("foo[3]", arrays: ["foo": [1, 2, 3]])
        XCTAssertThrowsError(try expression.evaluate()) { error in
            XCTAssertEqual(error as? Expression.Error, .arrayBounds(.array("foo"), 3))
        }
    }
