    func testGetURLGivenLocalHostHtmlThenValidURL() {
        let initialUrl = "localhost:4242/test-fixture/test-example.html"
        let subject = DefaultURLFormatter()

        let result = subject.getURL(entry: initialUrl)

        XCTAssertEqual(result?.absoluteString, "http://\(initialUrl)")
    }
