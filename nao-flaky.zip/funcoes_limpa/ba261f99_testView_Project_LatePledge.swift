  func testView_Project_LatePledge() {
    let validProjectFragment = createMockProjectNode(
      id: 1,
      name: "Project 1",
      state: "live",
      isInPostCampaignPledgingPhase: true,
      isPostCampaignPledgingEnabled: true
    )
    self.similarProject = ProjectCardProperties(validProjectFragment.fragments.projectCardFragment)

    XCTAssertNotNil(self.similarProject, "ProjectCardProperties should not be nil")

    orthogonalCombos([Language.en, Language.es], [Device.phone4_7inch]).forEach { language, device in
      withEnvironment(language: language) {
        let view = ProjectCardView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false

        view.configureWith(value: self.similarProject!)

        let (parent, _) = traitControllers(
          device: device,
          orientation: .portrait,
          child: wrappedViewController(subview: view, device: device)
        )
        parent.view.frame.size.height = 300

        self.scheduler.advance(by: .seconds(1))

        assertSnapshot(matching: parent.view, as: .image, named: "lang_\(language)_device_\(device)")
      }
    }
  }
