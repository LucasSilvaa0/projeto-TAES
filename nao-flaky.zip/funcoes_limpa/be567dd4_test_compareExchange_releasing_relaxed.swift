  func test_compareExchange_releasing_relaxed() {
    let v: UnsafeAtomic<UnsafeMutableRawPointer> = .create(_mraw1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeMutableRawPointer) = v.compareExchange(
      expected: _mraw1,
      desired: _mraw2,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _mraw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    (exchanged, original) = v.compareExchange(
      expected: _mraw1,
      desired: _mraw2,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    (exchanged, original) = v.compareExchange(
      expected: _mraw2,
      desired: _mraw1,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw1)

    (exchanged, original) = v.compareExchange(
      expected: _mraw2,
      desired: _mraw1,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mraw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw1)
  }
