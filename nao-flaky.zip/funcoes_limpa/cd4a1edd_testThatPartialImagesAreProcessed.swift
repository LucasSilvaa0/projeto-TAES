    func testThatPartialImagesAreProcessed() {
        let expectPartialImageProduced = self.expectation(description: "Partial Image Is Produced")
        // We expect two partial images (at 5 scans, and 9 scans marks).
        expectPartialImageProduced.expectedFulfillmentCount = 2

        let expectFinalImageProduced = self.expectation(description: "Final Image Is Produced")

        let request = ImageRequest(url: Test.url).processed(with: MockImageProcessor(id: "_image_processor"))

        pipeline.loadImage(
            with: request,
            progress: { response, _, _ in
                if let image = response?.image {
                    XCTAssertEqual(image.nk_test_processorIDs.count, 1)
                    XCTAssertEqual(image.nk_test_processorIDs.first, "_image_processor")
                    expectPartialImageProduced.fulfill()
                    self.dataLoader.resume()
                }
        },
            completion: { response, _ in
                XCTAssertNotNil(response)
                let image = response?.image
                XCTAssertEqual(image?.nk_test_processorIDs.count, 1)
                XCTAssertEqual(image?.nk_test_processorIDs.first, "_image_processor")
                expectFinalImageProduced.fulfill()
        })

        wait()
    }
