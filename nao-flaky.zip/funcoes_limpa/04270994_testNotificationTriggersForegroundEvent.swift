    func testNotificationTriggersForegroundEvent() {
        gleanLifecycleObserver.startObserving()
        notificationCenter.post(name: UIApplication.willEnterForegroundNotification, object: nil)
        XCTAssertTrue(
            mockGleanUsageReportingApi.startTrackingDurationCalled,
            "Foreground notification should trigger startTrackingDuration."
        )
    }
