  func testExtractFromOptionalRoot() {
    enum Foo {
      case foo(String)
      case bar(String)
      case baz
    }

    var opt: Foo? = .foo("blob1")
    XCTAssertEqual("blob1", (/Foo.foo).extract(from: opt))
    XCTAssertNil((/Foo.bar).extract(from: opt))
    XCTAssertNil((/Foo.baz).extract(from: opt))

    opt = .bar("blob2")
    XCTAssertNil((/Foo.foo).extract(from: opt))
    XCTAssertEqual("blob2", (/Foo.bar).extract(from: opt))
    XCTAssertNil((/Foo.baz).extract(from: opt))

    opt = .baz
    XCTAssertNil((/Foo.foo).extract(from: opt))
    XCTAssertNil((/Foo.bar).extract(from: opt))
    XCTAssertNotNil((/Foo.baz).extract(from: opt))

    opt = nil
    XCTAssertNil((/Foo.foo).extract(from: opt))
    XCTAssertNil((/Foo.bar).extract(from: opt))
    XCTAssertNil((/Foo.baz).extract(from: opt))

    let extractExpression: (Foo?) -> String? = /Foo.foo
    XCTAssertNotNil(extractExpression(.some(.foo("blob1"))))
    XCTAssertNil(extractExpression(.some(.bar("blob2"))))
    XCTAssertNil(extractExpression(.some(.baz)))
    XCTAssertNil(extractExpression(nil))

    let voidExtractExpression: (Foo?) -> Void? = /Foo.baz
    XCTAssertNil(voidExtractExpression(.some(.foo("blob1"))))
    XCTAssertNil(voidExtractExpression(.some(.bar("blob2"))))
    XCTAssertNotNil(voidExtractExpression(.some(.baz)))
    XCTAssertNil(voidExtractExpression(nil))
  }
