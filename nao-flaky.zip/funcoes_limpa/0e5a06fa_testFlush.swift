    func testFlush() {
        channel.flush()
        XCTAssertEqual(lastEvent, .flush)
    }
