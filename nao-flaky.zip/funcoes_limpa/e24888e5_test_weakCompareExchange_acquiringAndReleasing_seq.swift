  func test_weakCompareExchange_acquiringAndReleasing_sequentiallyConsistent() {
    let v: UnsafeAtomic<UnsafeRawPointer> = .create(_raw1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeRawPointer)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _raw1,
        desired: _raw2,
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, _raw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    (exchanged, original) = v.weakCompareExchange(
      expected: _raw1,
      desired: _raw2,
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _raw2,
        desired: _raw1,
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw1)

    (exchanged, original) = v.weakCompareExchange(
      expected: _raw2,
      desired: _raw1,
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _raw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw1)
  }
