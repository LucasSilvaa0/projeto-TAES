    func testMapPreservesConfiguration() {
        var observation = ValueObservation.trackingConstantRegion { _ in }
        observation.requiresWriteAccess = true
        
        let mappedObservation = observation.map { _ in }
        XCTAssertEqual(mappedObservation.requiresWriteAccess, observation.requiresWriteAccess)
    }
