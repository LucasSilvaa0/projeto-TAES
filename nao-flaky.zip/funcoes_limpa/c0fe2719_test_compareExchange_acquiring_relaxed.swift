  func test_compareExchange_acquiring_relaxed() {
    let v: UnsafeAtomic<UnsafeRawPointer> = .create(_raw1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeRawPointer) = v.compareExchange(
      expected: _raw1,
      desired: _raw2,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _raw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    (exchanged, original) = v.compareExchange(
      expected: _raw1,
      desired: _raw2,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    (exchanged, original) = v.compareExchange(
      expected: _raw2,
      desired: _raw1,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw1)

    (exchanged, original) = v.compareExchange(
      expected: _raw2,
      desired: _raw1,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _raw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw1)
  }
