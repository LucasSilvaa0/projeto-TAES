  public func testName() {
    let basicToken = TokenSyntax(stringLiteral: "basicToken")
    XCTAssertEqual(Identifier(basicToken)?.name, "basicToken")

    let backtickedToken = TokenSyntax(stringLiteral: "`backtickedToken`")
    XCTAssertEqual(Identifier(backtickedToken)?.name, "backtickedToken")

    let multiBacktickedToken = TokenSyntax(stringLiteral: "```multiBacktickedToken```")
    XCTAssertEqual(Identifier(multiBacktickedToken)?.name, "``multiBacktickedToken``")

    let unicodeNormalizedToken = TokenSyntax(stringLiteral: "\u{e0}")  // "a`"
    XCTAssertEqual(Identifier(unicodeNormalizedToken)?.name, "\u{61}\u{300}")  // "à"
  }
