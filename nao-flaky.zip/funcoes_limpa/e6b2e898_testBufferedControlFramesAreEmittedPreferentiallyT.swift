    func testBufferedControlFramesAreEmittedPreferentiallyToOtherFrames() {
        // We're going to buffera DATA frame and a control frame, then attempt to emit them and confirm they
        // come out in the right order.
        var buffer = CompoundOutboundBuffer(mode: .client, initialMaxOutboundStreams: 1, maxBufferedControlFrames: 1000)

        // Send a HEADERS frame through to open up a space in the flow control buffer.
        let startFrame = HTTP2Frame(streamID: 1, payload: .headers(.init(headers: HPACKHeaders())))
        XCTAssertNoThrow(
            try buffer.processOutboundFrame(startFrame, promise: nil, channelWritable: true).assertForward()
        )
        buffer.streamCreated(1, initialWindowSize: 65535)

        // Send a DATA frame. This is buffered.
        let dataFrame = self.createDataFrame(1, byteBufferSize: 50)
        XCTAssertNoThrow(
            try buffer.processOutboundFrame(dataFrame, promise: nil, channelWritable: true).assertNothing()
        )

        // Send in a PING frame which will be buffered.
        let pingFrame = HTTP2Frame(streamID: .rootStream, payload: .ping(.init(withInteger: 9), ack: false))
        XCTAssertNoThrow(
            try buffer.processOutboundFrame(pingFrame, promise: nil, channelWritable: false).assertNothing()
        )

        buffer.flushReceived()

        // Now attempt to unbuffer the frames.
        guard case .frame(let firstFrame, _) = buffer.nextFlushedWritableFrame(channelWritable: true) else {
            XCTFail("Didn't get expected frame")
            return
        }
        firstFrame.assertFrameMatches(this: pingFrame)

        guard case .frame(let secondFrame, _) = buffer.nextFlushedWritableFrame(channelWritable: true) else {
            XCTFail("Didn't get expected frame")
            return
        }
        secondFrame.assertFrameMatches(this: dataFrame)
    }
