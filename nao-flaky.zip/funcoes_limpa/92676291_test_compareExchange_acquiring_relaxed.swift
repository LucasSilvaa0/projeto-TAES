  func test_compareExchange_acquiring_relaxed() {
    let v: UnsafeAtomic<Baz> = .create(_baz1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Baz) = v.compareExchange(
      expected: _baz1,
      desired: _baz2,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _baz1)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    (exchanged, original) = v.compareExchange(
      expected: _baz1,
      desired: _baz2,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    (exchanged, original) = v.compareExchange(
      expected: _baz2,
      desired: _baz1,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz1)

    (exchanged, original) = v.compareExchange(
      expected: _baz2,
      desired: _baz1,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _baz1)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz1)
  }
