    func testGetContentSizeWidth() {
        let scrollView = UIScrollView()
        let node = LayoutNode(view: scrollView)
        XCTAssertEqual(try node.doubleValue(forSymbol: "contentSize.width"), Double(scrollView.contentSize.width))
    }
