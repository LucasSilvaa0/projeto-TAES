    func testOutletConstantExpressionBinding() {
        let node = LayoutNode(
            view: UILabel(),
            constants: [
                "label.outlet": "label",
            ],
            expressions: [
                "text": "{label.outlet}",
            ],
            children: [
                LayoutNode(
                    view: UILabel(),
                    outlet: "{parent.text}"
                ),
            ]
        )
        let viewController = TestViewController()
        XCTAssertNoThrow(try node.mount(in: viewController))
        XCTAssertTrue(viewController.labelWasSet)
    }
