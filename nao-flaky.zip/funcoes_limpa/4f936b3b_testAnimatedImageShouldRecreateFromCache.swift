func testAnimatedImageShouldRecreateFromCache() {
        let exp = expectation(description: #function)
        let url = testURLs[0]
        let data = testImageGIFData
        stub(url, data: data)
        let p = SimpleProcessor()
        manager.retrieveImage(with: url, options: [.processor(p), .onlyLoadFirstFrame]) { result in
            XCTAssertTrue(p.processed)
            XCTAssertTrue(result.value!.image.creatingOptions!.onlyFirstFrame)
            p.processed = false
            self.manager.retrieveImage(with: url, options: [.processor(p)]) { result in
                XCTAssertTrue(p.processed)
                XCTAssertFalse(result.value!.image.creatingOptions!.onlyFirstFrame)
                exp.fulfill()
            }
        }
        waitForExpectations(timeout: 3, handler: nil)
    }
