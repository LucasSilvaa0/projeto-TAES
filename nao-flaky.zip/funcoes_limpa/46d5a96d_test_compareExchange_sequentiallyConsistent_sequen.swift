  func test_compareExchange_sequentiallyConsistent_sequentiallyConsistent() {
    let v: UnsafeAtomic<UnsafeRawPointer?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeRawPointer?) = v.compareExchange(
      expected: nil,
      desired: _raw2,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    (exchanged, original) = v.compareExchange(
      expected: nil,
      desired: _raw2,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    (exchanged, original) = v.compareExchange(
      expected: _raw2,
      desired: nil,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.compareExchange(
      expected: _raw2,
      desired: nil,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
