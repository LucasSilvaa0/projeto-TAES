  func testSuffix() {
    let a = 0...10
    XCTAssertEqualSequences(a.suffix(while: { $0 > 5 }), (6...10))
    XCTAssertEqualSequences(a.suffix(while: { $0 > 10 }), [])
    XCTAssertEqualSequences(a.suffix(while: { $0 > 9 }), [10])
    XCTAssertEqualSequences(a.suffix(while: { $0 > -1 }), (0...10))
    
    let empty: [Int] = []
    XCTAssertEqualSequences(empty.suffix(while: { $0 > 10 }), [])
  }
