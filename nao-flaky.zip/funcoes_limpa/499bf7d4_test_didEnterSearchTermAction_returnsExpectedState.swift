    func test_didEnterSearchTermAction_returnsExpectedState() {
        let initialState = createSubject()
        let reducer = addressBarReducer()

        let newState = reducer(
            initialState,
            ToolbarAction(
                windowUUID: windowUUID,
                actionType: ToolbarActionType.didEnterSearchTerm
            )
        )

        XCTAssertEqual(newState.windowUUID, windowUUID)
        XCTAssertEqual(newState.trailingPageActions.count, 0)
        XCTAssertTrue(newState.isEditing)
        XCTAssertTrue(newState.didStartTyping)
        XCTAssertFalse(newState.isEmptySearch)
        XCTAssertFalse(newState.shouldSelectSearchTerm)
    }
