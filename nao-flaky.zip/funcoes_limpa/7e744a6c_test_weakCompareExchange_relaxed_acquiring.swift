  func test_weakCompareExchange_relaxed_acquiring() {
    let v: UnsafeAtomic<DoubleWord> = .create(DoubleWord(first: 100, second: 64))
    defer { v.destroy() }

    var (exchanged, original): (Bool, DoubleWord)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: DoubleWord(first: 100, second: 64),
        desired: DoubleWord(first: 50, second: 32),
        successOrdering: .relaxed,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, DoubleWord(first: 100, second: 64))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 50, second: 32))

    (exchanged, original) = v.weakCompareExchange(
      expected: DoubleWord(first: 100, second: 64),
      desired: DoubleWord(first: 50, second: 32),
      successOrdering: .relaxed,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, DoubleWord(first: 50, second: 32))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 50, second: 32))

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: DoubleWord(first: 50, second: 32),
        desired: DoubleWord(first: 100, second: 64),
        successOrdering: .relaxed,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, DoubleWord(first: 50, second: 32))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 100, second: 64))

    (exchanged, original) = v.weakCompareExchange(
      expected: DoubleWord(first: 50, second: 32),
      desired: DoubleWord(first: 100, second: 64),
      successOrdering: .relaxed,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, DoubleWord(first: 100, second: 64))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 100, second: 64))
  }
