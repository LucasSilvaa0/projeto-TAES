    func testCreatingConnectionAndFailing() {
        let elg = EmbeddedEventLoopGroup(loops: 4)
        var connections = HTTPConnectionPool.HTTP1Connections(
            maximumConcurrentConnections: 8,
            generator: .init(),
            maximumConnectionUses: nil
        )

        let el1 = elg.next()
        let el2 = elg.next()

        // general purpose connection
        XCTAssertEqual(connections.startingGeneralPurposeConnections, 0)
        XCTAssertEqual(connections.startingEventLoopConnections(on: el1), 0)
        let conn1ID = connections.createNewConnection(on: el1)
        XCTAssertEqual(conn1ID, 0)
        XCTAssertEqual(connections.startingGeneralPurposeConnections, 1)
        XCTAssertEqual(connections.startingEventLoopConnections(on: el1), 0)
        // connection failed to start. 1. backoff
        let backoff1EL = connections.backoffNextConnectionAttempt(conn1ID)
        XCTAssert(backoff1EL === el1)
        // backoff done. 2. decide what's next
        guard let (conn1FailIndex, conn1FailContext) = connections.failConnection(conn1ID) else {
            return XCTFail("Expected that the connection is remembered")
        }
        XCTAssert(conn1FailContext.eventLoop === el1)
        XCTAssertEqual(conn1FailContext.use, .generalPurpose)
        XCTAssertEqual(conn1FailContext.connectionsStartingForUseCase, 0)
        let (replaceConn1ID, replaceConn1EL) = connections.replaceConnection(at: conn1FailIndex)
        XCTAssert(replaceConn1EL === el1)
        XCTAssertEqual(replaceConn1ID, 1)

        // eventLoop connection
        let conn2ID = connections.createNewOverflowConnection(on: el2)
        // the replacement connection is starting
        XCTAssertEqual(connections.startingGeneralPurposeConnections, 1)
        XCTAssertEqual(connections.startingEventLoopConnections(on: el2), 1)
        let backoff2EL = connections.backoffNextConnectionAttempt(conn2ID)
        XCTAssert(backoff2EL === el2)
        guard let (conn2FailIndex, conn2FailContext) = connections.failConnection(conn2ID) else {
            return XCTFail("Expected that the connection is remembered")
        }
        XCTAssert(conn2FailContext.eventLoop === el2)
        XCTAssertEqual(conn2FailContext.use, .eventLoop(el2))
        XCTAssertEqual(conn2FailContext.connectionsStartingForUseCase, 0)
        connections.removeConnection(at: conn2FailIndex)
        // the replacement connection is still starting
        XCTAssertEqual(connections.startingGeneralPurposeConnections, 1)
    }
