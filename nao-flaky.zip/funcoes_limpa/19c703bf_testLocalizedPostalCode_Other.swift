  func testLocalizedPostalCode_Other() {
    withEnvironment(locale: Locale(identifier: "de_AU")) {
      XCTAssertEqual("Postcode", localizedPostalCode())
    }

    withEnvironment(locale: Locale(identifier: "en_GB")) {
      XCTAssertEqual("Postcode", localizedPostalCode())
    }

    withEnvironment(locale: Locale(identifier: "es_FR")) {
      XCTAssertEqual("Postcode", localizedPostalCode())
    }

    withEnvironment(locale: Locale(identifier: "fr_AT")) {
      XCTAssertEqual("Postcode", localizedPostalCode())
    }

    withEnvironment(locale: Locale(identifier: "ja_CH")) {
      XCTAssertEqual("Postcode", localizedPostalCode())
    }
  }
