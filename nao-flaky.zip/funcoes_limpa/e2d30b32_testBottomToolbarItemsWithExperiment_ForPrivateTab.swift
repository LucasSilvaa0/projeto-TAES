    func testBottomToolbarItemsWithExperiment_ForPrivateTabsInCompact() {
        setupNimbusTabTrayUIExperimentTesting(isEnabled: true)
        let viewController = createSubject(selectedSegment: .privateTabs)

        viewController.layout = .compact
        viewController.viewWillAppear(false)

        XCTAssertEqual(viewController.toolbarItems?.count, 5)
    }
