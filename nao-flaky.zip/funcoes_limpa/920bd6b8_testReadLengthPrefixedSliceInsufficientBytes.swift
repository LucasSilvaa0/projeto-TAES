    func testReadLengthPrefixedSliceInsufficientBytes() {
        var buffer = ByteBuffer()
        buffer.writeBytes([5, 1, 2, 3])  // We put a length of 5, followed by only 3 bytes
        let slice = buffer.readLengthPrefixedSlice(strategy: UInt8ReadingTestStrategy(expectedRead: 5))
        XCTAssertNil(slice)
        // The original buffer reader index should NOT move
        XCTAssertEqual(buffer.readableBytesView, [5, 1, 2, 3])
    }
