  func test_weakCompareExchange_acquiringAndReleasing() {
    let v: UnsafeAtomic<UnsafeMutableRawPointer?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeMutableRawPointer?)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: nil,
        desired: _mraw2,
        ordering: .acquiringAndReleasing)
    } while !exchanged
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    (exchanged, original) = v.weakCompareExchange(
      expected: nil,
      desired: _mraw2,
      ordering: .acquiringAndReleasing)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _mraw2,
        desired: nil,
        ordering: .acquiringAndReleasing)
    } while !exchanged
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.weakCompareExchange(
      expected: _mraw2,
      desired: nil,
      ordering: .acquiringAndReleasing)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
