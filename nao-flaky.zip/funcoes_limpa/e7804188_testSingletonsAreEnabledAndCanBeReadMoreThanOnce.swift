    func testSingletonsAreEnabledAndCanBeReadMoreThanOnce() {
        XCTAssertTrue(NIOSingletons.singletonsEnabledSuggestion)
        XCTAssertTrue(NIOSingletons.singletonsEnabledSuggestion)
        XCTAssertTrue(NIOSingletons.singletonsEnabledSuggestion)
    }
