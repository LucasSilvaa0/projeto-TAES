    func testPeekWebSocketErrorCode_Repeated() {
        var buffer = ByteBuffer()
        let errorCode = WebSocketErrorCode(codeNumber: 1011)
        buffer.write(webSocketErrorCode: errorCode)

        let firstPeek = buffer.peekWebSocketErrorCode()
        let secondPeek = buffer.peekWebSocketErrorCode()
        XCTAssertEqual(firstPeek, secondPeek, "Repeated peeks should yield the same code.")
        XCTAssertEqual(buffer.readerIndex, 0, "peekWebSocketErrorCode() should not advance reader index.")
    }
