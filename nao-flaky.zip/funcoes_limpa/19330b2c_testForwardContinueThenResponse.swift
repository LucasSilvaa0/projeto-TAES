    func testForwardContinueThenResponse() {
        let eventCounter = EventCounterHandler()
        let decoder = HTTPResponseDecoder(leftOverBytesStrategy: .dropBytes, informationalResponseStrategy: .forward)
        let responseDecoder = ByteToMessageHandler(decoder)
        let channel = EmbeddedChannel(handler: responseDecoder)
        XCTAssertNoThrow(try channel.pipeline.addHandler(eventCounter).wait())

        let requestHead: HTTPClientRequestPart = .head(.init(version: .http1_1, method: .POST, uri: "/"))
        XCTAssertNoThrow(try channel.writeOutbound(requestHead))
        var buffer = channel.allocator.buffer(capacity: 128)
        buffer.writeString("HTTP/1.1 100 continue\r\n\r\nHTTP/1.1 200 ok\r\ncontent-length: 0\r\n\r\n")
        XCTAssertNoThrow(try channel.writeInbound(buffer))

        XCTAssertEqual(
            try channel.readInbound(as: HTTPClientResponsePart.self),
            .head(.init(version: .http1_1, status: .continue))
        )
        XCTAssertEqual(
            try channel.readInbound(as: HTTPClientResponsePart.self),
            .head(.init(version: .http1_1, status: .ok, headers: ["content-length": "0"]))
        )
        XCTAssertEqual(.end(nil), try channel.readInbound(as: HTTPClientResponsePart.self))
        XCTAssertNil(try channel.readInbound(as: HTTPClientResponsePart.self))
        XCTAssertNotNil(try channel.readOutbound())

        XCTAssertEqual(1, eventCounter.writeCalls)
        XCTAssertEqual(1, eventCounter.flushCalls)
        XCTAssertEqual(3, eventCounter.channelReadCalls)  // .head, .head & .end
        XCTAssertEqual(1, eventCounter.channelReadCompleteCalls)
        XCTAssertEqual(["channelReadComplete", "channelRead", "write", "flush"], eventCounter.allTriggeredEvents())
        XCTAssertNoThrow(XCTAssertTrue(try channel.finish().isClean))
    }
