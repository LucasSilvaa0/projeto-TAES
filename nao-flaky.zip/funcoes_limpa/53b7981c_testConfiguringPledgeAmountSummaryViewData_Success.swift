  func testConfiguringPledgeAmountSummaryViewData_Success() {
    let data = ManagePledgeSummaryViewData(
      backerId: 1,
      backerName: "Backer McGee",
      backerSequence: 999,
      backingState: Backing.Status.pledged,
      bonusAmount: nil,
      currentUserIsCreatorOfProject: false,
      isNoReward: false,
      locationName: nil,
      needsConversion: false,
      omitUSCurrencyCode: true,
      pledgeAmount: 30,
      pledgedOn: 1_568_666_243.0,
      currencyCode: Project.Country.us.currencyCode,
      projectDeadline: 1_572_626_213.0,
      projectState: Project.State.live,
      rewardMinimum: 30,
      rewardReceivedViewControllerViewIsHidden: false,
      rewardReceivedWithData: .init(
        project: .template,
        backerCompleted: true,
        estimatedDeliveryOn: 1_475_361_315,
        backingState: .collected,
        estimatedShipping: nil,
        pledgeDisclaimerViewHidden: false
      ),
      shippingAmount: nil,
      shippingAmountHidden: true,
      rewardIsLocalPickup: true,
      paymentIncrements: nil,
      project: nil
    )

    self.vm.inputs.configureWith(data)
    self.vm.inputs.viewDidLoad()

    guard let pledgeAmountSummaryValue = self.configurePledgeAmountSummary.lastValue else {
      XCTFail("pledge amount summary view data should exist")
      return
    }

    XCTAssertTrue(pledgeAmountSummaryValue.omitUSCurrencyCode)
    XCTAssertNil(pledgeAmountSummaryValue.bonusAmount)
    XCTAssertFalse(pledgeAmountSummaryValue.bonusAmountHidden)
    XCTAssertFalse(pledgeAmountSummaryValue.isNoReward)
    XCTAssertNil(pledgeAmountSummaryValue.locationName)
    XCTAssertNil(pledgeAmountSummaryValue.shippingAmount)
    XCTAssertEqual(pledgeAmountSummaryValue.currencyCode, Project.Country.us.currencyCode)
    XCTAssertEqual(pledgeAmountSummaryValue.pledgedOn, 1_568_666_243.0)
    XCTAssertEqual(pledgeAmountSummaryValue.rewardMinimum, 30)
    XCTAssertTrue(pledgeAmountSummaryValue.shippingAmountHidden)
    XCTAssertTrue(pledgeAmountSummaryValue.rewardIsLocalPickup)
  }
