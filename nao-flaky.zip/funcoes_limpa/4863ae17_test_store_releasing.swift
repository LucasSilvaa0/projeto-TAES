  func test_store_releasing() {
    let v: UnsafeAtomic<Int> = .create(12)
    defer { v.destroy() }
    v.store(23, ordering: .releasing)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    let w: UnsafeAtomic<Int> = .create(23)
    defer { w.destroy() }
    w.store(12, ordering: .releasing)
    XCTAssertEqual(w.load(ordering: .relaxed), 12)
  }
