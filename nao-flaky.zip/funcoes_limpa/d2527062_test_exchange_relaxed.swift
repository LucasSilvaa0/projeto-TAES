  func test_exchange_relaxed() {
    let v: UnsafeAtomic<UInt> = .create(12)
    defer { v.destroy() }

    XCTAssertEqual(v.exchange(12, ordering: .relaxed), 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    XCTAssertEqual(v.exchange(23, ordering: .relaxed), 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    XCTAssertEqual(v.exchange(23, ordering: .relaxed), 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)
  }
