    func testFastmailIntegration_basicMetadata() {
        let provider = FastmailIntegration()
        let mailURL = provider.newEmailURLFromMetadata(buildBasicMetadata())
        XCTAssertEqual(mailURL?.absoluteString, "fastmail:mail/compose?to=\(toEmail)")
    }
