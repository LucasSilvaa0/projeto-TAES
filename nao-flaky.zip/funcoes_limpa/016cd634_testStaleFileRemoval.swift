  func testStaleFileRemoval() {
    let buildValue = BuildValue.StaleFileRemoval(fileList: ["/foo/bar.txt", "/bar/foo.swift"])
    XCTAssertEqual(buildValue.kind, .staleFileRemoval)
    XCTAssertEqual(buildValue.fileList, ["/foo/bar.txt", "/bar/foo.swift"])
    XCTAssertEqual(buildValue.description, "<BuildValue.StaleFileRemoval fileList=[/foo/bar.txt, /bar/foo.swift]>")
    XCTAssertEqual(buildValue, BuildValue.StaleFileRemoval(fileList: ["/foo/bar.txt", "/bar/foo.swift"]))
    XCTAssertNotEqual(buildValue, BuildValue.StaleFileRemoval(fileList: ["/foo/bar.txt"]))
  }
