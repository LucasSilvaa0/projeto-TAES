    func testLoadMachinesMultilineComments() {
        let content = """
                    ## This is a comment
                    # This is another comment
                    machine example.com # This is an inline comment
                    login anonymous
                    password qwerty # and # another #one
                    """
        
        let machines = try? Netrc.from(content).get().machines
        XCTAssertEqual(machines?.count, 1)
        
        let machine = machines?.first
        XCTAssertEqual(machine?.name, "example.com")
        XCTAssertEqual(machine?.login, "anonymous")
        XCTAssertEqual(machine?.password, "qwerty")
    }
