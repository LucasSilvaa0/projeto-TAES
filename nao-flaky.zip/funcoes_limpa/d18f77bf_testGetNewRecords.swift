    func testGetNewRecords() {
        _ = createRecordWithURL("http://localhost/article1", title: "Test 1", addedBy: "Stefan's iPhone")
        _ = createRecordWithURL("http://localhost/article2", title: "Test 2", addedBy: "Stefan's iPhone")
        _ = createRecordWithURL("http://localhost/article3", title: "Test 3", addedBy: "Stefan's iPhone")
        let getAllResult = getAllRecords()
        if let records = getAllResult.successValue {
            XCTAssertEqual(3, records.count)
        }
        // TODO When we are able to create records coming from the server, we can extend this test
        // to see if we query correctly
    }
