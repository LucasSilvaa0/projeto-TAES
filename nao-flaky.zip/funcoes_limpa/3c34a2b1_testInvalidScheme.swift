    func testInvalidScheme() {
        let subject = createSubject()
        let url = URL(string: "focus://deep-link?url=/settings/newTab")!

        let route = subject.makeRoute(url: url)

        XCTAssertNil(route)
    }
