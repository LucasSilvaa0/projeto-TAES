    func testUnicodeLiteralContainsJunk() {
        let expression = Expression("'foo\\u{bar}'")
        XCTAssertThrowsError(try expression.evaluate()) { error in
            XCTAssertEqual(error as? Expression.Error, .unexpectedToken("r}'"))
        }
