    func testOversizedRequestWithContentLength() {
        resetSmallHandler(maxContentLength: 4)

        // HTTP/1.1 uses Keep-Alive unless told otherwise
        let requestHead: HTTPRequestHead = HTTPRequestHead(
            version: .http1_1,
            method: .PUT,
            uri: "/path",
            headers: HTTPHeaders(
                [("Host", "example.com"), ("X-Test", "True"), ("content-length", "8")])
        )

        resetSmallHandler(maxContentLength: 4)

        XCTAssertThrowsError(try self.channel.writeInbound(HTTPServerRequestPart.head(requestHead)))

        let response = asHTTPResponseHead(self.writeRecorder.writes.first!)!
        XCTAssertEqual(response.status, .payloadTooLarge)
        XCTAssertEqual(response.headers[canonicalForm: "content-length"], ["0"])
        XCTAssertEqual(response.version, requestHead.version)

        // Connection should be kept open
        XCTAssertTrue(channel.isActive)

        // An ill-behaved client may continue writing the request
        let requestParts = [
            HTTPServerRequestPart.body(channel.allocator.buffer(bytes: [1, 2, 3, 4])),
            HTTPServerRequestPart.body(channel.allocator.buffer(bytes: [5, 6])),
            HTTPServerRequestPart.body(channel.allocator.buffer(bytes: [7, 8])),
        ]

        for requestPart in requestParts {
            XCTAssertThrowsError(try self.channel.writeInbound(requestPart))
        }

        // The aggregated message should not get passed up as it is too large.
        // There should only be one "frame too long" event despite multiple writes
        XCTAssertEqual(self.readRecorder.reads, [.httpFrameTooLongEvent])
        XCTAssertThrowsError(try self.channel.writeInbound(HTTPServerRequestPart.end(nil)))
        XCTAssertEqual(self.readRecorder.reads, [.httpFrameTooLongEvent])

        // Write another request that is small enough
        var secondReqWithContentLength: HTTPRequestHead = self.requestHead
        secondReqWithContentLength.headers.replaceOrAdd(name: "content-length", value: "2")

        XCTAssertNoThrow(try self.channel.writeInbound(HTTPServerRequestPart.head(secondReqWithContentLength)))

        XCTAssertNoThrow(
            try self.channel.writeInbound(
                HTTPServerRequestPart.body(
                    channel.allocator.buffer(bytes: [1])
                )
            )
        )
        XCTAssertEqual(self.readRecorder.reads, [.httpFrameTooLongEvent])
        XCTAssertNoThrow(
            try self.channel.writeInbound(
                HTTPServerRequestPart.body(
                    channel.allocator.buffer(bytes: [2])
                )
            )
        )
        XCTAssertNoThrow(try self.channel.writeInbound(HTTPServerRequestPart.end(nil)))

        XCTAssertEqual(
            self.readRecorder.reads,
            [
                .httpFrameTooLongEvent,
                .channelRead(
                    NIOHTTPServerRequestFull(
                        head: secondReqWithContentLength,
                        body: channel.allocator.buffer(bytes: [1, 2])
                    )
                ),
            ]
        )
    }
