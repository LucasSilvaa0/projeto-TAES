  func testParseErrors() {
    let sources =
      """
      infix operator +
      infix operator +

      precedencegroup A {
        associativity: none
        higherThan: B
      }

      precedencegroup A {
        associativity: none
        higherThan: B
      }
      """

    let parsedOperatorPrecedence = Parser.parse(source: sources)

    var opPrecedence = OperatorTable()
    var errors: [OperatorError] = []
    opPrecedence.addSourceFile(parsedOperatorPrecedence) { error in
      errors.append(error)
    }

    XCTAssertEqual(errors.count, 2)
    guard case let .operatorAlreadyExists(existing, new) = errors[0] else {
      XCTFail("expected an 'operator already exists' error")
      return
    }

    XCTAssertEqual(errors[0].message, "redefinition of infix operator '+'")
    _ = existing
    _ = new

    guard case let .groupAlreadyExists(existingGroup, newGroup) = errors[1] else {
      XCTFail("expected a 'group already exists' error")
      return
    }
    XCTAssertEqual(errors[1].message, "redefinition of precedence group 'A'")
    _ = newGroup
    _ = existingGroup
  }
