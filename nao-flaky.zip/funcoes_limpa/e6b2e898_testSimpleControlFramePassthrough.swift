    func testSimpleControlFramePassthrough() {
        var buffer = CompoundOutboundBuffer(
            mode: .client,
            initialMaxOutboundStreams: 100,
            maxBufferedControlFrames: 1000
        )

        let frames: [HTTP2Frame] = [
            HTTP2Frame(streamID: .rootStream, payload: .ping(.init(withInteger: 0), ack: true)),
            HTTP2Frame(
                streamID: .rootStream,
                payload: .goAway(lastStreamID: 0, errorCode: .protocolError, opaqueData: nil)
            ),
            HTTP2Frame(streamID: .rootStream, payload: .settings(.settings([]))),
            HTTP2Frame(streamID: .rootStream, payload: .alternativeService(origin: nil, field: nil)),
            HTTP2Frame(streamID: .rootStream, payload: .origin([])),
            HTTP2Frame(streamID: 1, payload: .priority(.init(exclusive: true, dependency: 0, weight: 200))),
            HTTP2Frame(streamID: 1, payload: .rstStream(.protocolError)),
        ]

        for frame in frames {
            XCTAssertNoThrow(
                try buffer.processOutboundFrame(frame, promise: nil, channelWritable: true).assertForward(),
                "Threw on \(frame)"
            )
        }
    }
