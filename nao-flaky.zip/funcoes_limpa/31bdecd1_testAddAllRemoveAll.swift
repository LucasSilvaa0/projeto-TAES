    func testAddAllRemoveAll() {
        var ring = CircularBuffer<Int>(initialCapacity: 8)
        XCTAssertTrue(ring.isEmpty)
        XCTAssertEqual(0, ring.count)

        for f in 1..<100 {
            ring.append(f)
            XCTAssertEqual(f, ring.count)
            XCTAssertTrue(ring.testOnly_verifyInvariantsForNonSlices())
        }
        for f in 1..<100 {
            XCTAssertEqual(f, ring.removeFirst())
            XCTAssertEqual(99 - f, ring.count)
            XCTAssertTrue(ring.testOnly_verifyInvariantsForNonSlices())
        }
        XCTAssertTrue(ring.isEmpty)
    }
