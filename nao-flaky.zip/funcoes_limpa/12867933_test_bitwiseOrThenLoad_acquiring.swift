  func test_bitwiseOrThenLoad_acquiring() {
    let a: Int = 3
    let b: Int = 8
    let c: Int = 12
    let result1: Int = a | b
    let result2: Int = result1 | c

    let v: UnsafeAtomic<Int> = .create(a)
    defer { v.destroy() }

    let new1: Int = v.bitwiseOrThenLoad(with: b, ordering: .acquiring)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: Int = v.bitwiseOrThenLoad(with: c, ordering: .acquiring)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
