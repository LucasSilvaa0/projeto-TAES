    func testRelativeDates() {
        let dateOrig = Date()
        var date = Date(timeInterval: 0, since: dateOrig)

        XCTAssertEqual(date.toRelativeTimeString(), "just now")

        date = Date(timeInterval: -10, since: dateOrig)
        XCTAssertEqual(date.toRelativeTimeString(), "just now")

        date = Date(timeInterval: -60, since: dateOrig)
        XCTAssertEqual(
            date.toRelativeTimeString(),
            ("today at " + DateFormatter.localizedString(from: date, dateStyle: .none, timeStyle: .short))
        )

        let calendar = Calendar.autoupdatingCurrent
        date = calendar.date(byAdding: .day, value: -1, to: dateOrig)!
        XCTAssertEqual(date.toRelativeTimeString(), "yesterday")

        date = calendar.date(byAdding: .day, value: -2, to: dateOrig)!
        XCTAssertEqual(date.toRelativeTimeString(), "this week")

        date = calendar.date(byAdding: .day, value: -7, to: dateOrig)!
        XCTAssertEqual(date.toRelativeTimeString(), "more than a week ago")

        date = calendar.date(byAdding: .day, value: -7 * 5, to: dateOrig)!
        XCTAssertEqual(date.toRelativeTimeString(), "more than a month ago")

        date = Date(timeInterval: -60 * 60 * 24 * 7 * 5 * 2, since: dateOrig)
        XCTAssertEqual(
            date.toRelativeTimeString(),
            DateFormatter.localizedString(from: date, dateStyle: .short, timeStyle: .short)
        )

        date = Date(timeInterval: -60 * 60 * 24 * 7 * 5 * 12 * 2, since: dateOrig)
        XCTAssertEqual(
            date.toRelativeTimeString(),
            DateFormatter.localizedString(from: date, dateStyle: .short, timeStyle: .short)
        )
    }
