func testObsoleteFormatTwo() {
        let expires = "Sun Nov  6 08:49:37 1994"
        let format = "EEE MMM d HH:mm:s yyyy"
        let required = dateFromFormat(format: format, dateStr: expires)
        let headers = HTTPHeaders(dictionaryLiteral: ("Expires", expires))
        let response = ClientResponse(status: .ok, headers: headers)

        XCTAssertEqual(response.headers.expirationDate(requestSentAt: Date()), required)
    }
