    func testAddPackageDependencyErrors() {
        XCTAssertThrows(
            try AddPackageDependency.addPackageDependency(
                Self.swiftSystemPackageDependency,
                to: """
                // swift-tools-version: 5.5
                let package: Package = .init(
                    name: "packages"
                )
                """
            )
        ) { (error: ManifestEditError) in
            if case .cannotFindPackage = error {
                return true
            } else {
                return false
            }
        }

        XCTAssertThrows(
            try AddPackageDependency.addPackageDependency(
                Self.swiftSystemPackageDependency,
                to: """
                // swift-tools-version: 5.5
                let package = Package(
                    name: "packages",
                    dependencies: blah
                )
                """
            )
        ) { (error: ManifestEditError) in
            if case .cannotFindArrayLiteralArgument(argumentName: "dependencies", node: _) = error {
                return true
            } else {
                return false
            }
        }

        XCTAssertThrows(
            try AddPackageDependency.addPackageDependency(
                Self.swiftSystemPackageDependency,
                to: """
                // swift-tools-version: 5.4
                let package = Package(
                    name: "packages"
                )
                """
            )
        ) { (error: ManifestEditError) in
            if case .oldManifest(.v5_4, .v5_5) = error {
                return true
            } else {
                return false
            }
        }
    }
