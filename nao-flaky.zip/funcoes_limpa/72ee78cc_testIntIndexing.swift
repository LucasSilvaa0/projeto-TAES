    func testIntIndexing() {
        var ring = CircularBuffer<Int>()
        for i in 0..<5 {
            ring.append(i)
            XCTAssertEqual(ring[offset: i], i)
        }

        XCTAssertEqual(ring[ring.startIndex], ring[offset: 0])
        XCTAssertEqual(ring[ring.index(before: ring.endIndex)], ring[offset: 4])

        ring[offset: 1] = 10
        XCTAssertEqual(ring[ring.index(after: ring.startIndex)], 10)
    }
