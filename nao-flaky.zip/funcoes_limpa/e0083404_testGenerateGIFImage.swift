func testGenerateGIFImage() {
        let options = ImageCreatingOptions()
        let image = KingfisherWrapper<KFCrossPlatformImage>.animatedImage(data: testImageGIFData, options: options)
        XCTAssertNotNil(image)
        #if os(iOS) || os(tvOS) || os(visionOS)
        XCTAssertEqual(image!.kf.imageFrameCount!, 8)
        #else
        XCTAssertEqual(image!.kf.images!.count, 8)
        XCTAssertEqual(image!.kf.duration, 0.8, accuracy: 0.001)
        #endif
    }
