    func testUpdateAndContainsNoChangeUAAndPrivate() {
        let testMockData = ChangeUserAgentsMockData(
            urlString: "https://www.yahoo.com",
            isChangedUA: false,
            isPrivate: true,
            expectContainsURL: false
        )
        let url = URL(string: testMockData.urlString)!

        Tab.ChangeUserAgent.updateDomainList(
            forUrl: url,
            isChangedUA: testMockData.isChangedUA,
            isPrivate: testMockData.isPrivate
        )
        XCTAssertEqual(Tab.ChangeUserAgent.contains(url: url, isPrivate: testMockData.isPrivate),
                       testMockData.expectContainsURL)
    }
