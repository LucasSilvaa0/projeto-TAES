  func testAdHocOpen() {
    // Ad-hoc test touching a file system.
    do {
      // TODO: Test this against a virtual in-memory file system
      try withTemporaryFilePath(basename: "testAdhocOpen") { path in
        let fd = try FileDescriptor.open(path.appending("b.txt"), .readWrite, options: [.create, .truncate], permissions: .ownerReadWrite)
        try fd.closeAfter {
          try fd.writeAll("abc".utf8)
          var def = "def"
          try def.withUTF8 {
            _ = try fd.write(UnsafeRawBufferPointer($0))
          }
          try fd.seek(offset: 1, from: .start)

          let readLen = 3
          let readBytes = try Array<UInt8>(unsafeUninitializedCapacity: readLen) { (buf, count) in
            count = try fd.read(into: UnsafeMutableRawBufferPointer(buf))
          }
          let preadBytes = try Array<UInt8>(unsafeUninitializedCapacity: readLen) { (buf, count) in
            count = try fd.read(fromAbsoluteOffset: 1, into: UnsafeMutableRawBufferPointer(buf))
          }

          XCTAssertEqual(readBytes.first!, "b".utf8.first!)
          XCTAssertEqual(readBytes, preadBytes)

          // TODO: seek
        }
      }
    } catch let err as Errno {
      print("caught \(err))")
      // Should we assert? I'd be interested in knowing if this happened
      XCTAssert(false)
    } catch {
      fatalError("FATAL: `testAdHocOpen`")
    }
  }
