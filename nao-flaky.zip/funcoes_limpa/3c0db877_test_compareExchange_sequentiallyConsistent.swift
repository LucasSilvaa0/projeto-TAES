  func test_compareExchange_sequentiallyConsistent() {
    let v: UnsafeAtomic<UnsafeMutablePointer<Foo>?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeMutablePointer<Foo>?) = v.compareExchange(
      expected: nil,
      desired: _mfoo2,
      ordering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo2)

    (exchanged, original) = v.compareExchange(
      expected: nil,
      desired: _mfoo2,
      ordering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mfoo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo2)

    (exchanged, original) = v.compareExchange(
      expected: _mfoo2,
      desired: nil,
      ordering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _mfoo2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.compareExchange(
      expected: _mfoo2,
      desired: nil,
      ordering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
