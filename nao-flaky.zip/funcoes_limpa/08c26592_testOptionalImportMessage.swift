  func testOptionalImportMessage() {
    var msg = SwiftProtoTesting_Proto3_TestAllTypes()
    XCTAssertEqual(msg.optionalImportMessage.d, 0)
    var importedMsg = SwiftProtoTesting_Import_ImportMessage()
    importedMsg.d = 20
    msg.optionalImportMessage = importedMsg
    XCTAssertEqual(msg.optionalImportMessage.d, 20)
    XCTAssertEqual(msg.optionalImportMessage, importedMsg)
  }
