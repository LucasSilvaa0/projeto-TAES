    func testConfigureWithoutDebug_PrintsOnlyAlwaysThreshold() {
        // -- Arrange --
        let logOutput = TestLogOutput()
        SentryLog.setLogOutput(logOutput)

        // -- Act --
        SentryLogSwiftSupport.configure(false, diagnosticLevel: SentryLevel.none)
        SentryLog.log(message: "fatal", andLevel: SentryLevel.fatal)
        SentryLog.log(message: "error", andLevel: SentryLevel.error)
        SentryLog.log(message: "warning", andLevel: SentryLevel.warning)
        SentryLog.log(message: "info", andLevel: SentryLevel.info)
        SentryLog.log(message: "debug", andLevel: SentryLevel.debug)
        SentryLog.log(message: "none", andLevel: SentryLevel.none)

        // -- Assert --
        XCTAssertEqual(1, logOutput.loggedMessages.count)
        XCTAssertEqual("[Sentry] [fatal] [timeIntervalSince1970:\(timeIntervalSince1970)] fatal", logOutput.loggedMessages.first)
    }
