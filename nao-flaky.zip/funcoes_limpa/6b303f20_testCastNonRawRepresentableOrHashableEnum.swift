    func testCastNonRawRepresentableOrHashableEnum() {
        let runtimeType = RuntimeType(NonRawRepresentableOrHashableEnum.self, ["foo": .foo, "bar": .bar(0)])
        XCTAssertNotNil(runtimeType.cast(NonRawRepresentableOrHashableEnum.foo) as? NonRawRepresentableOrHashableEnum)
        XCTAssertNil(runtimeType.cast("foo") as? NonRawRepresentableOrHashableEnum)
    }
