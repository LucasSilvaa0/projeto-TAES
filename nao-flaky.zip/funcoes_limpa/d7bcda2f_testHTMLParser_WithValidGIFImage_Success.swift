  func testHTMLParser_WithValidGIFImage_Success() {
    let viewElements = self.htmlParser.parse(bodyHtml: HTMLParserTemplates.validGIFImage.data)

    guard let viewElement = viewElements.first as? ImageViewElement else {
      XCTFail("image view element should be created.")

      return
    }

    XCTAssertEqual(
      viewElement.src,
      "https://i.kickstarter.com/assets/033/915/794/8dca97fb0636aeb1a4a937025f369e7e_original.gif?fit=contain&origin=ugc-qa&q=92&width=700&sig=mvrGEc9nin%2BeC%2BxQXeGi%2FNdePo9grkVoX5OXEADCH64%3D"
    )
    XCTAssertNil(viewElement.href)

    guard let existingCaption = viewElement.caption else {
      XCTFail("image caption should exist")

      return
    }

    XCTAssertTrue(existingCaption.isEmpty)
  }
