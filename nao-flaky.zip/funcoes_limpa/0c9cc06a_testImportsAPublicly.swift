  func testImportsAPublicly() {
    let imports = ImportsAPublicly.with { $0.a.e = .a }
    XCTAssertEqual(imports.a.e, .a)
  }
