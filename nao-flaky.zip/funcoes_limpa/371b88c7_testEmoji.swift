    func testEmoji() {
        let string = "a👩🏿‍❤️‍💋‍👩🏻b"
        let sanitized = StringSanitizer.sanitize(string)
        XCTAssertEqual(sanitized, string)
    }
