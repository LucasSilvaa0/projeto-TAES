  func testOptionalCord() {
    var msg = SwiftProtoTesting_TestAllTypes()
    XCTAssertEqual(msg.optionalCord, "")
    XCTAssertFalse(msg.hasOptionalCord)
    msg.optionalCord = "25"
    XCTAssertTrue(msg.hasOptionalCord)
    XCTAssertEqual(msg.optionalCord, "25")
    msg.clearOptionalCord()
    XCTAssertEqual(msg.optionalCord, "")
    XCTAssertFalse(msg.hasOptionalCord)
  }
