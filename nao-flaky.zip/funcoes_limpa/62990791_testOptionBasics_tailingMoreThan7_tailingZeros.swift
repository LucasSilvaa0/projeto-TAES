    func testOptionBasics_tailingMoreThan7_tailingZeros() {
        // For the first byte of optionBits, just signal that there is a second, but
        // then set all the expected zero bits to ensure it fails.
        for x: UInt8 in 0x8...UInt8.max {
            let bytes: [UInt8] = [ 0, 0x80, x ]
            bytes.withUnsafeBytes { ptr in
                XCTAssertNil(TestOptions.extractOptions(ptr.baseAddress!, bytes.count))
            }
        }
    }
