    func testExpandPathsWithEitherOr() {
        let path = "Option{s,Descriptor}.swift, SwiftFormat.{h,swift}"
        let directory = URL(fileURLWithPath: #file)
            .deletingLastPathComponent().deletingLastPathComponent().appendingPathComponent("Sources")
        XCTAssertEqual(try matchGlobs(expandGlobs(path, in: directory.path), in: directory.path).count, 4)
    }
