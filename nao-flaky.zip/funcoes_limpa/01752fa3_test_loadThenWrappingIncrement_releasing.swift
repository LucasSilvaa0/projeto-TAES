  func test_loadThenWrappingIncrement_releasing() {
    let a: Int32 = 3
    let b: Int32 = 8
    let c: Int32 = 12
    let result1: Int32 = a &+ b
    let result2: Int32 = result1 &+ c

    let v: UnsafeAtomic<Int32> = .create(a)
    defer { v.destroy() }

    let old1: Int32 = v.loadThenWrappingIncrement(by: b, ordering: .releasing)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: Int32 = v.loadThenWrappingIncrement(by: c, ordering: .releasing)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
