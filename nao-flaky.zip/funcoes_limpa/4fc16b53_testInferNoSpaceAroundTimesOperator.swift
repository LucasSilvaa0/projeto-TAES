    func testInferNoSpaceAroundTimesOperator() {
        let input = "let foo = a*b + c / d + e*f"
        let options = inferFormatOptions(from: tokenize(input))
        XCTAssertEqual(options.noSpaceOperators, ["*"])
    }
