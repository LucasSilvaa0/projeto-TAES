  func test_wrappingDecrementThenLoad_acquiring() {
    let a: UInt64 = 3
    let b: UInt64 = 8
    let c: UInt64 = 12
    let result1: UInt64 = a &- b
    let result2: UInt64 = result1 &- c

    let v: UnsafeAtomic<UInt64> = .create(a)
    defer { v.destroy() }

    let new1: UInt64 = v.wrappingDecrementThenLoad(by: b, ordering: .acquiring)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: UInt64 = v.wrappingDecrementThenLoad(by: c, ordering: .acquiring)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
