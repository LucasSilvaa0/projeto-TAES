  func test_FilePath_initWithStringConversion() {
    let source = "ab\0c"
    var path: FilePath
    path = FilePath(platformString: source)
    source.withPlatformString {
      XCTAssertEqual(path, FilePath(platformString: $0))
    }
    path = FilePath(platformString: "")
    XCTAssertEqual(path.string.isEmpty, true)
  }
