    func testFTPScheme() {
        XCTAssertEqual(
            CanonicalPackageLocation("ftp://example.com/mona/LinkedList").description,
            "example.com/mona/linkedlist"
        )
    }
