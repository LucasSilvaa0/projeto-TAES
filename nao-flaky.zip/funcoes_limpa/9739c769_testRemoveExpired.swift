func testRemoveExpired() {
        let exp = expectation(description: #function)

        XCTAssertFalse(storage.isCached(forKey: "1"))
        storage.store(value: 1, forKey: "1", expiration: .seconds(0.1))
        XCTAssertTrue(storage.isCached(forKey: "1"))

        delay(0.2) {
            XCTAssertFalse(self.storage.isCached(forKey: "1"))

            // But the object is still in underlying cache.
            XCTAssertNotNil(self.storage.storage.object(forKey: "1"))
            self.storage.removeExpired()

            // It should be removed now.
            XCTAssertNil(self.storage.storage.object(forKey: "1"))
            exp.fulfill()
        }
        waitForExpectations(timeout: 3, handler: nil)
    }
