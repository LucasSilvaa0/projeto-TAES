    func testHexDumpDetailedWithOffset() {
        var buf = ByteBuffer(string: "Goodbye, world! It was nice knowing you.\n")
        let _ = buf.readBytes(length: 5)
        let expected = """
            00000000  79 65 2c 20 77 6f 72 6c  64 21 20 49 74 20 77 61  |ye, world! It wa|
            00000010  73 20 6e 69 63 65 20 6b  6e 6f 77 69 6e 67 20 79  |s nice knowing y|
            00000020  6f 75 2e 0a                                       |ou..|
            00000024
            """
        let actual = buf.hexDump(format: .detailed)
        XCTAssertEqual(expected, actual)
    }
