    @MainActor func testCancelImageTask() {
        let exp = expectation(description: #function)
        let url = testURLs[0]
        let stub = delayedStub(url, data: testImageData)

        KF.url(url)
            .onFailure { error in
                XCTAssertTrue(error.isTaskCancelled)
                delay(0.1) { exp.fulfill() }
            }
            .set(to: button, for: .highlighted)
        
        self.button.kf.cancelImageDownloadTask()
        _ = stub.go()

        waitForExpectations(timeout: 3, handler: nil)
    }
