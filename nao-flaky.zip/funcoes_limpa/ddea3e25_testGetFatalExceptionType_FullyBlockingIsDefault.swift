    func testGetFatalExceptionType_FullyBlockingIsDefault() {
        XCTAssertEqual(
            "Fatal App Hang Fully Blocked",
            SentryAppHangTypeMapper.getFatalExceptionType(nonFatalErrorType: "")
        )
    }
