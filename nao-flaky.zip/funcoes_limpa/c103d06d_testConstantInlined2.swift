    func testConstantInlined2() {
        let expression = Expression("5 + foo", constants: ["foo": 5], symbols: [.variable("bar"): { _ in 6 }])
        XCTAssertEqual(expression.symbols, [])
        XCTAssertEqual(expression.description, "10")
    }
