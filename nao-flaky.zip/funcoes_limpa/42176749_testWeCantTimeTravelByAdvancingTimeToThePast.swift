    func testWeCantTimeTravelByAdvancingTimeToThePast() {
        let eventLoop = EmbeddedEventLoop()

        var tasksRun = 0
        eventLoop.scheduleTask(deadline: .uptimeNanoseconds(0) + .seconds(42)) {
            tasksRun += 1
        }

        // t=40s
        eventLoop.advanceTime(to: .uptimeNanoseconds(0) + .seconds(40))
        XCTAssertEqual(tasksRun, 0)

        // t=40s (still)
        eventLoop.advanceTime(to: .distantPast)
        XCTAssertEqual(tasksRun, 0)

        // t=42s
        eventLoop.advanceTime(by: .seconds(2))
        XCTAssertEqual(tasksRun, 1)
    }
