    func testNSDataDatabaseValueRoundTrip() {
        
        func roundTrip(_ value: NSData) -> Bool
        {
            let dbValue = value.databaseValue
            guard let back = NSData.fromDatabaseValue(dbValue) else
            {
                XCTFail("Failed to convert from DatabaseValue to NSData")
                return false
            }
            return back == value
        }
        
        XCTAssertTrue(roundTrip(NSData(data: "bar".data(using: .utf8)!)))
        XCTAssertTrue(roundTrip(NSData()))
    }
