    func testAddExtraSdkPackages() {
        PrivateSentrySDKOnly.addSdkPackage("package1", version: "version1")
        PrivateSentrySDKOnly.addSdkPackage("package2", version: "version2")

        XCTAssertEqual(
            SentrySdkInfo.global().packages,
            [
                ["name": "package1", "version": "version1"],
                ["name": "package2", "version": "version2"]
            ]
        )
    }
