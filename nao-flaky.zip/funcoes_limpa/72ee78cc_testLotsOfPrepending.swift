    func testLotsOfPrepending() {
        var buf = CircularBuffer<Int>(initialCapacity: 8)

        for i in (0..<128).reversed() {
            buf.prepend(i)
        }
        XCTAssertEqual(Array(0..<128), Array(buf))
    }
