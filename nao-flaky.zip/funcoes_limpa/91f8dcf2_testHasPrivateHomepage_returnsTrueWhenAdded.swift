    func testHasPrivateHomepage_returnsTrueWhenAdded() {
        let subject = ContentContainer(frame: .zero)
        let privateHomepage = PrivateHomepageViewController(
            windowUUID: .XCTestDefaultUUID,
            overlayManager: overlayModeManager
        )
        subject.add(content: privateHomepage)

        XCTAssertTrue(subject.hasPrivateHomepage)
    }
