  func test_weakCompareExchange_relaxed() {
    let v: UnsafeAtomic<Hyacinth?> = .create(Hyacinth.bucket)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Hyacinth?)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: Hyacinth.bucket,
        desired: nil,
        ordering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, Hyacinth.bucket)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.weakCompareExchange(
      expected: Hyacinth.bucket,
      desired: nil,
      ordering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: nil,
        desired: Hyacinth.bucket,
        ordering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), Hyacinth.bucket)

    (exchanged, original) = v.weakCompareExchange(
      expected: nil,
      desired: Hyacinth.bucket,
      ordering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, Hyacinth.bucket)
    XCTAssertEqual(v.load(ordering: .relaxed), Hyacinth.bucket)
  }
