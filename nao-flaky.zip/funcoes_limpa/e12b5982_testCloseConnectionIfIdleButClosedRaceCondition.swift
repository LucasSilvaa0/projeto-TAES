    func testCloseConnectionIfIdleButClosedRaceCondition() {
        let elg = EmbeddedEventLoopGroup(loops: 1)
        var connections = HTTPConnectionPool.HTTP1Connections(
            maximumConcurrentConnections: 8,
            generator: .init(),
            maximumConnectionUses: nil
        )

        let el1 = elg.next()

        // connection is idle
        let connID = connections.createNewConnection(on: el1)
        let conn: HTTPConnectionPool.Connection = .__testOnly_connection(id: connID, eventLoop: el1)
        _ = connections.newHTTP1ConnectionEstablished(conn)
        _ = connections.failConnection(connID)

        // timeout arrives minimal to late
        XCTAssertEqual(connections.closeConnectionIfIdle(connID), nil)
    }
