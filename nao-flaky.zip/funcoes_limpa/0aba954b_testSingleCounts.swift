  func testSingleCounts() {
    for (k, expectation) in Self.numbersPermutations.enumerated() {
      XCTAssertEqualSequences(
        expectation,
        Self.numbers.uniquePermutations(ofCount: k))
    }
    
    XCTAssertEqualSequences(
      Self.numbersPermutations[5],
      Self.numbers.uniquePermutations())
  }
