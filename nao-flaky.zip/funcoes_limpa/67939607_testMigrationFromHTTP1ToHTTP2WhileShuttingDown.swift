    func testMigrationFromHTTP1ToHTTP2WhileShuttingDown() {
        let elg = EmbeddedEventLoopGroup(loops: 1)
        let el1 = elg.next()
        var connections = MockConnectionPool()
        var queuer = MockRequestQueuer()
        var state = HTTPConnectionPool.StateMachine(
            idGenerator: .init(),
            maximumConcurrentHTTP1Connections: 8,
            retryConnectionEstablishment: true,
            preferHTTP1: false,
            maximumConnectionUses: nil
        )

        /// create a new connection
        let mockRequest = MockHTTPScheduableRequest(eventLoop: el1)
        let request = HTTPConnectionPool.Request(mockRequest)
        let action = state.executeRequest(request)
        guard case .createConnection(let conn1ID, let eventLoop) = action.connection else {
            return XCTFail("Unexpected connection action \(action.connection)")
        }

        XCTAssertTrue(eventLoop === el1)
        XCTAssertEqual(action.request, .scheduleRequestTimeout(for: request, on: mockRequest.eventLoop))
        XCTAssertNoThrow(try connections.createConnection(conn1ID, on: el1))
        XCTAssertNoThrow(try queuer.queue(mockRequest, id: request.id))

        /// we now no longer want anything of it
        let shutdownAction = state.shutdown()
        guard case .failRequestsAndCancelTimeouts(let requestsToCancel, let error) = shutdownAction.request else {
            return XCTFail("unexpected shutdown action \(shutdownAction)")
        }
        XCTAssertEqualTypeAndValue(error, HTTPClientError.cancelled)

        for request in requestsToCancel {
            XCTAssertNoThrow(try queuer.cancel(request.id))
        }
        XCTAssertTrue(queuer.isEmpty)

        /// new HTTP2 connection should migrate from HTTP1 to HTTP2, close the connection and shutdown the pool
        let conn1: HTTPConnectionPool.Connection = .__testOnly_connection(id: conn1ID, eventLoop: el1)
        XCTAssertNoThrow(try connections.succeedConnectionCreationHTTP2(conn1ID, maxConcurrentStreams: 10))
        let migrationAction = state.newHTTP2ConnectionCreated(conn1, maxConcurrentStreams: 10)
        XCTAssertEqual(migrationAction.request, .none)
        XCTAssertEqual(migrationAction.connection, .closeConnection(conn1, isShutdown: .yes(unclean: true)))
        XCTAssertNoThrow(try connections.closeConnection(conn1))
        XCTAssertTrue(connections.isEmpty)
    }
