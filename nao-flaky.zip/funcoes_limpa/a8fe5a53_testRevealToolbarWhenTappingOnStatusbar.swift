    func testRevealToolbarWhenTappingOnStatusbar() {
        if !iPad() {
            // Workaround when testing on iPhone. If the orientation is in landscape on iPhone the tests will fail.

            XCUIDevice.shared.orientation = UIDeviceOrientation.portrait
            mozWaitForElementToExist(app.textFields[AccessibilityIdentifiers.Browser.AddressToolbar.searchTextField])

            navigator.openURL(website1["url"]!, waitForLoading: true)
            // Adding the waiter right after navigating to the webpage in order to make the test more stable
            waitUntilPageLoad()
            mozWaitForElementToExist(app.buttons[AccessibilityIdentifiers.Toolbar.settingsMenuButton], timeout: 10)
            let PageOptionsMenu = app.buttons[AccessibilityIdentifiers.Toolbar.settingsMenuButton]
            let statusbarElement: XCUIElement = XCUIApplication(
                bundleIdentifier: "com.apple.springboard"
            ).statusBars.element(boundBy: 1)
            app.swipeUp()
            XCTAssertFalse(PageOptionsMenu.isHittable)
            statusbarElement.tap(force: true)
            XCTAssertTrue(PageOptionsMenu.isHittable)
            statusbarElement.tap(force: true)
            let topElement = app.webViews
                .otherElements["Internet for people, not profit — Mozilla"]
                .children(matching: .other)
                .matching(identifier: "navigation")
                .element(boundBy: 0)
                .staticTexts["Mozilla"]
            mozWaitForElementToExist(topElement, timeout: 10)
            XCTAssertTrue(topElement.isHittable)
        }
   }
