    func testConnectionCreationIsRetriedUntilRequestIsFailed() {
        let httpBin = HTTPBin(proxy: .simulate(authorization: "abc123"))
        defer { XCTAssertNoThrow(try httpBin.shutdown()) }
        let eventLoopGroup = MultiThreadedEventLoopGroup(numberOfThreads: 2)
        let eventLoop = eventLoopGroup.next()
        defer { XCTAssertNoThrow(try eventLoopGroup.syncShutdownGracefully()) }

        let request = try! HTTPClient.Request(url: "http://localhost:9000")
        let poolDelegate = TestDelegate(eventLoop: eventLoop)

        let pool = HTTPConnectionPool(
            eventLoopGroup: eventLoopGroup,
            sslContextCache: .init(),
            tlsConfiguration: .none,
            clientConfiguration: .init(
                proxy: .init(host: "localhost", port: httpBin.port, type: .http(.basic(credentials: "invalid")))
            ),
            key: .init(request),
            delegate: poolDelegate,
            idGenerator: .init(),
            backgroundActivityLogger: .init(label: "test")
        )
        defer {
            pool.shutdown()
            XCTAssertNoThrow(try poolDelegate.future.wait())
        }

        XCTAssertEqual(httpBin.createdConnections, 0)

        var maybeRequest: HTTPClient.Request?
        var maybeRequestBag: RequestBag<ResponseAccumulator>?
        XCTAssertNoThrow(maybeRequest = try HTTPClient.Request(url: "https://localhost:\(httpBin.port)"))
        XCTAssertNoThrow(
            maybeRequestBag = try RequestBag(
                request: XCTUnwrap(maybeRequest),
                eventLoopPreference: .indifferent,
                task: .init(eventLoop: eventLoopGroup.next(), logger: .init(label: "test")),
                redirectHandler: nil,
                connectionDeadline: .now() + .seconds(5),
                requestOptions: .forTests(),
                delegate: ResponseAccumulator(request: XCTUnwrap(maybeRequest))
            )
        )

        guard let requestBag = maybeRequestBag else { return XCTFail("Expected to get a request") }

        pool.executeRequest(requestBag)
        XCTAssertThrowsError(try requestBag.task.futureResult.wait()) {
            XCTAssertEqual($0 as? HTTPClientError, .proxyAuthenticationRequired)
        }
        XCTAssertGreaterThanOrEqual(httpBin.createdConnections, 8)
        XCTAssertEqual(httpBin.activeConnections, 0)
    }
