  func test_weakCompareExchange_relaxed_sequentiallyConsistent() {
    let v: UnsafeAtomic<Fred> = .create(Fred.one)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Fred)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: Fred.one,
        desired: Fred.two,
        successOrdering: .relaxed,
        failureOrdering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, Fred.one)
    XCTAssertEqual(v.load(ordering: .relaxed), Fred.two)

    (exchanged, original) = v.weakCompareExchange(
      expected: Fred.one,
      desired: Fred.two,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, Fred.two)
    XCTAssertEqual(v.load(ordering: .relaxed), Fred.two)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: Fred.two,
        desired: Fred.one,
        successOrdering: .relaxed,
        failureOrdering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, Fred.two)
    XCTAssertEqual(v.load(ordering: .relaxed), Fred.one)

    (exchanged, original) = v.weakCompareExchange(
      expected: Fred.two,
      desired: Fred.one,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, Fred.one)
    XCTAssertEqual(v.load(ordering: .relaxed), Fred.one)
  }
