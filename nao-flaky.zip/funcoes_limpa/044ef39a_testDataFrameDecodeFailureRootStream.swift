    func testDataFrameDecodeFailureRootStream() {
        let frameBytes: [UInt8] = [
            0x00, 0x00, 0x01,  // 3-byte payload length (1 byte)
            0x00,  // 1-byte frame type (DATA)
            0x01,  // 1-byte flags (END_STREAM)
            0x00, 0x00, 0x00, 0x00,  // 4-byte stream identifier (INVALID)
            0x00,  // payload
        ]
        let badFrameBuf = byteBuffer(withBytes: frameBytes)
        var decoder = HTTP2FrameDecoder(
            allocator: self.allocator,
            expectClientMagic: false,
            maximumSequentialContinuationFrames: self.maximumSequentialContinuationFrames
        )

        decoder.append(bytes: badFrameBuf)
        XCTAssertThrowsError(
            try decoder.nextFrame(),
            "Should throw a protocol error",
            { err in
                guard let connErr = err as? InternalError, case .codecError(code: .protocolError) = connErr else {
                    XCTFail("Should have thrown a codec error of type PROTOCOL_ERROR")
                    return
                }
            }
        )
    }
