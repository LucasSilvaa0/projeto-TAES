    func testGenerateAndStoreBatch() {
        let records = self.db.write { tx in
            let records = self.kyberPreKeyStore.generateKyberPreKeyRecords(
                count: 5,
                signedBy: self.identityKey,
                tx: tx
            )

            try! self.kyberPreKeyStore.storeKyberPreKeyRecords(records: records, tx: tx)

            return records
        }

        self.db.read { tx in
            for record in records {
                let fetchedRecord = kyberPreKeyStore.loadKyberPreKey(id: record.id, tx: tx)
                XCTAssertNotNil(fetchedRecord)
            }
        }
    }
