  func test_loadThenBitwiseOr_acquiring() {
    let a: Int8 = 3
    let b: Int8 = 8
    let c: Int8 = 12
    let result1: Int8 = a | b
    let result2: Int8 = result1 | c

    let v: UnsafeAtomic<Int8> = .create(a)
    defer { v.destroy() }

    let old1: Int8 = v.loadThenBitwiseOr(with: b, ordering: .acquiring)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: Int8 = v.loadThenBitwiseOr(with: c, ordering: .acquiring)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
