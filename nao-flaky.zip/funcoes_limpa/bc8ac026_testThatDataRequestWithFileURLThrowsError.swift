    func testThatDataRequestWithFileURLThrowsError() {
        // Given
        let fileURL = url(forResource: "valid_data", withExtension: "json")
        let expectation = expectation(description: "Request should succeed.")
        var response: DataResponse<Data?, AFError>?

        // When
        AF.request(fileURL)
            .response { resp in
                response = resp
                expectation.fulfill()
            }

        waitForExpectations(timeout: timeout)

        // Then
        XCTAssertEqual(response?.result.isSuccess, true)
    }
