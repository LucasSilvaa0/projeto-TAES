    func testEncodeAmpersandInText() {
        let input = "<Foo>bar &amp; baz</Foo>"
        let output = "<Foo>bar &amp; baz</Foo>\n"
        XCTAssertEqual(try format(input), output)
    }
