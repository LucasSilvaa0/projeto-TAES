  func test_load_acquiring() {
    let v: UnsafeAtomic<Int8> = .create(12)
    defer { v.destroy() }
    XCTAssertEqual(v.load(ordering: .acquiring), 12)

    let w: UnsafeAtomic<Int8> = .create(23)
    defer { w.destroy() }
    XCTAssertEqual(w.load(ordering: .acquiring), 23)
  }
