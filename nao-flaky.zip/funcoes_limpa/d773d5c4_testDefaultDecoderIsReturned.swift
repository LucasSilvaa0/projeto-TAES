    func testDefaultDecoderIsReturned() {
        let context = _mockImageDecodingContext()
        let decoder = ImageDecoderRegistry().decoder(for: context)
        XCTAssertTrue(decoder is ImageDecoder)
    }
