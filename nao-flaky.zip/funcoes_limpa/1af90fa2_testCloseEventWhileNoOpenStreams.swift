    func testCloseEventWhileNoOpenStreams() {
        let delegate = MockHTTP2IdleHandlerDelegate()
        let idleHandler = HTTP2IdleHandler(delegate: delegate, logger: Logger(label: "test"))
        let embedded = EmbeddedChannel(handlers: [idleHandler])
        XCTAssertNoThrow(try embedded.connect(to: .makeAddressResolvingHost("localhost", port: 0)).wait())

        let settingsFrame = HTTP2Frame(
            streamID: 0,
            payload: .settings(.settings([.init(parameter: .maxConcurrentStreams, value: 10)]))
        )
        XCTAssertEqual(delegate.maxStreams, nil)
        XCTAssertNoThrow(try embedded.writeInbound(settingsFrame))
        XCTAssertEqual(delegate.maxStreams, 10)

        XCTAssertTrue(embedded.isActive)
        embedded.pipeline.triggerUserOutboundEvent(HTTPConnectionEvent.shutdownRequested, promise: nil)
        XCTAssertFalse(embedded.isActive)
    }
