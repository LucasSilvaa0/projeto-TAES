    func testNestedDependencies() {
        // Enqueue action
        queue.wait(for: [.parentEvent, .activityEvent], then: { })
        XCTAssertFalse(queue.hasSignalled(.parentEvent))

        // Create a parent event that depends on 3 sub-events
        queue.establishDependencies(for: .parentEvent, against: [
            .startingEvent,
            .middleEvent,
            .laterEvent
        ])

        // Start and finish activity event
        queue.started(.activityEvent)
        queue.completed(.activityEvent)
        // Action should not yet run
        XCTAssertFalse(queue.hasSignalled(.parentEvent))

        // Complete 2 of 3 sub-events of parent
        queue.signal(event: .startingEvent)
        queue.signal(event: .middleEvent)
        // Action not run
        XCTAssertFalse(queue.hasSignalled(.parentEvent))

        // Complete 3rd sub-event of parent
        queue.signal(event: .laterEvent)
        // At this point all dependencies should be complete.
        XCTAssertTrue(queue.hasSignalled(.parentEvent))
    }
