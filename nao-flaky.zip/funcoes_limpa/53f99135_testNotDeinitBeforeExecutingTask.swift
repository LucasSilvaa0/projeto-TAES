    func testNotDeinitBeforeExecutingTask() {
        let finishedCondition = Condition()
        var finished = false

        Thread {
            finishedCondition.whileLocked{
                finished = true
                finishedCondition.signal()
            }
        }.start()

        finishedCondition.whileLocked{
            while !finished {
                finishedCondition.wait()
            }
        }

        XCTAssertTrue(finished)
    }
