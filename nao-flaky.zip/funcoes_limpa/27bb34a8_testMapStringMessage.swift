  func testMapStringMessage() {
    var msg = SwiftProtoTesting_Message2()
    XCTAssertEqual(msg.mapStringMessage, [:])
    var valueMsg1 = SwiftProtoTesting_Message2()
    valueMsg1.optionalInt32 = 1085
    msg.mapStringMessage = ["85": valueMsg1]
    XCTAssertEqual(msg.mapStringMessage.count, 1)
    if let v = msg.mapStringMessage["85"] {
      XCTAssertEqual(v.optionalInt32, 1085)
    } else {
      XCTFail("Lookup failed")
    }
    XCTAssertEqual(msg.mapStringMessage, ["85": valueMsg1])
    var valueMsg2 = SwiftProtoTesting_Message2()
    valueMsg2.optionalInt32 = 1185
    msg.mapStringMessage["185"] = valueMsg2
    XCTAssertEqual(msg.mapStringMessage.count, 2)
    if let v = msg.mapStringMessage["85"] {
      XCTAssertEqual(v.optionalInt32, 1085)
    } else {
      XCTFail("Lookup failed")
    }
    if let v = msg.mapStringMessage["185"] {
      XCTAssertEqual(v.optionalInt32, 1185)
    } else {
      XCTFail("Lookup failed")
    }
    XCTAssertEqual(msg.mapStringMessage, ["85": valueMsg1, "185": valueMsg2])
  }
