    func testInApp_WithNotMatchingIncludeButMatchingExclude() {
        XCTAssertFalse(
            fixture.getSut(inAppIncludes: ["iOS-Swifta"], inAppExcludes: ["iOS-Swift"])
                .is(inApp: "/private/var/containers/Bundle/Application/D987FC7A-629E-41DD-A043-5097EB29E2F4/iOS-Swift.app/iOS-Swift")
        )
    }
