  func test_store_releasing() {
    let v: UnsafeAtomic<Hyacinth?> = .create(Hyacinth.bucket)
    defer { v.destroy() }
    v.store(nil, ordering: .releasing)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    let w: UnsafeAtomic<Hyacinth?> = .create(nil)
    defer { w.destroy() }
    w.store(Hyacinth.bucket, ordering: .releasing)
    XCTAssertEqual(w.load(ordering: .relaxed), Hyacinth.bucket)
  }
