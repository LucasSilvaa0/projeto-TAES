  func test_SCA() {
    let envProducer = UpdateBackingEnvelope
      .producer(from: self.mockData(checkoutState: .authorizing, sca: true))
    let env = MockGraphQLClient.shared.client.data(from: envProducer)

    XCTAssertEqual(env?.updateBacking.checkout.id, "id")
    XCTAssertEqual(env?.updateBacking.checkout.backing.clientSecret, "client-secret")
    XCTAssertEqual(env?.updateBacking.checkout.backing.requiresAction, true)
    XCTAssertEqual(env?.updateBacking.checkout.state, .authorizing)
  }
