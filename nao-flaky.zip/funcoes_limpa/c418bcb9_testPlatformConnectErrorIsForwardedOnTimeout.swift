    func testPlatformConnectErrorIsForwardedOnTimeout() {
        let bin = HTTPBin(.http2(compress: false), reusePort: true)
        let clientGroup = MultiThreadedEventLoopGroup(numberOfThreads: 2)
        let el1 = clientGroup.next()
        let el2 = clientGroup.next()
        defer { XCTAssertNoThrow(try clientGroup.syncShutdownGracefully()) }
        var config = HTTPClient.Configuration()
        config.tlsConfiguration = .clientDefault
        config.tlsConfiguration?.certificateVerification = .none
        config.httpVersion = .automatic
        config.timeout.connect = .milliseconds(1000)
        let client = HTTPClient(
            eventLoopGroupProvider: .shared(clientGroup),
            configuration: config,
            backgroundActivityLogger: Logger(label: "HTTPClient", factory: StreamLogHandler.standardOutput(label:))
        )
        defer { XCTAssertNoThrow(try client.syncShutdown()) }

        var maybeRequest1: HTTPClient.Request?
        XCTAssertNoThrow(maybeRequest1 = try HTTPClient.Request(url: "https://localhost:\(bin.port)/get"))
        guard let request1 = maybeRequest1 else { return }

        let task1 = client.execute(
            request: request1,
            delegate: ResponseAccumulator(request: request1),
            eventLoop: .delegateAndChannel(on: el1)
        )
        var response1: ResponseAccumulator.Response?
        XCTAssertNoThrow(response1 = try task1.wait())

        XCTAssertEqual(.ok, response1?.status)
        XCTAssertEqual(response1?.version, .http2)
        let serverPort = bin.port

        let serverGroup = MultiThreadedEventLoopGroup(numberOfThreads: 1)
        defer { XCTAssertNoThrow(try serverGroup.syncShutdownGracefully()) }
        var maybeServer: Channel?
        XCTAssertNoThrow(
            maybeServer = try ServerBootstrap(group: serverGroup)
                .serverChannelOption(ChannelOptions.socketOption(.so_reuseaddr), value: 1)
                .serverChannelOption(ChannelOptions.socket(SocketOptionLevel(SOL_SOCKET), SO_REUSEPORT), value: 1)
                .childChannelInitializer { channel in
                    channel.close()
                }
                .childChannelOption(ChannelOptions.socketOption(.so_reuseaddr), value: 1)
                .bind(host: "127.0.0.1", port: serverPort)
                .wait()
        )
        // shutting down the old server closes all connections immediately
        XCTAssertNoThrow(try bin.shutdown())
        // client is now in HTTP/2 state and the HTTPBin is closed
        guard let server = maybeServer else { return }
        defer { XCTAssertNoThrow(try server.close().wait()) }

        var maybeRequest2: HTTPClient.Request?
        XCTAssertNoThrow(maybeRequest2 = try HTTPClient.Request(url: "https://localhost:\(serverPort)/"))
        guard let request2 = maybeRequest2 else { return }

        let task2 = client.execute(
            request: request2,
            delegate: ResponseAccumulator(request: request2),
            eventLoop: .delegateAndChannel(on: el2)
        )
        XCTAssertThrowsError(try task2.wait()) { error in
            XCTAssertNil(
                error as? HTTPClientError,
                "error should be some platform specific error that the connection is closed/reset by the other side"
            )
        }
    }
