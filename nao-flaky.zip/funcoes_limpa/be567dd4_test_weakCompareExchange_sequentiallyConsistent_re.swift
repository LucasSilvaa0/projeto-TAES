  func test_weakCompareExchange_sequentiallyConsistent_relaxed() {
    let v: UnsafeAtomic<UnsafeMutableRawPointer> = .create(_mraw1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeMutableRawPointer)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _mraw1,
        desired: _mraw2,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, _mraw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    (exchanged, original) = v.weakCompareExchange(
      expected: _mraw1,
      desired: _mraw2,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _mraw2,
        desired: _mraw1,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw1)

    (exchanged, original) = v.weakCompareExchange(
      expected: _mraw2,
      desired: _mraw1,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mraw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw1)
  }
