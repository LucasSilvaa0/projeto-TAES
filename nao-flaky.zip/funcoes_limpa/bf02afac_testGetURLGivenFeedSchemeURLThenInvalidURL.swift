    func testGetURLGivenFeedSchemeURLThenInvalidURL() {
        let initialUrl = "feed://example.com/rss.xml"
        let subject = DefaultURLFormatter()

        let result = subject.getURL(entry: initialUrl)

        XCTAssertNil(result)
    }
