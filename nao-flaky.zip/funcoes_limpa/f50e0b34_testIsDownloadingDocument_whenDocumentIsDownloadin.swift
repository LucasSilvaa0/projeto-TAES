    func testIsDownloadingDocument_whenDocumentIsDownloading_returnsTrue() {
        let tab = Tab(profile: mockProfile, windowUUID: windowUUID)
        let document = MockTemporaryDocument(withFileURL: URL(string: "https://www.example.com")!)
        document.isDownloading = true

        tab.enqueueDocument(document)

        XCTAssertTrue(tab.isDownloadingDocument())
    }
