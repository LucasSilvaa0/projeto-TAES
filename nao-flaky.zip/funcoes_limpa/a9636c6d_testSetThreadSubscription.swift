    func testSetThreadSubscription() {
        let config = TokenConfiguration("user:12345")
        let headers = Helper.makeAuthHeader(username: "user", password: "12345")
        let session = OctoKitURLTestSession(expectedURL: "https://api.github.com/notifications/threads/1/subscription",
                                            expectedHTTPMethod: "PUT",
                                            expectedHTTPHeaders: headers,
                                            jsonFile: "notification_thread_subscription",
                                            statusCode: 200)
        let task = Octokit(config, session: session).setThreadSubscription(threadId: "1") { response in
            switch response {
            case let .success(notification):
                XCTAssertEqual(notification.id, 1)
            case let .failure(error):
                XCTAssertNil(error)
            }
        }
        XCTAssertNotNil(task)
        XCTAssertTrue(session.wasCalled)
    }
