    func testSubscriptNSStringWithIntRange() {
        let expression = AnyExpression("foo[1..<3]", constants: [
            "foo": "foo" as NSString,
        ])
        XCTAssertEqual(try expression.evaluate(), "oo")
    }
