  func testWatchProjectButtonClicked_DiscoveryLocationContext() {
    let segmentClient = MockTrackingClient()
    let ksrAnalytics = KSRAnalytics(
      segmentClient: segmentClient,
      appTrackingTransparency: self.appTrackingTransparency
    )

    ksrAnalytics.trackWatchProjectButtonClicked(
      project: Project.template,
      page: .discovery,
      params: DiscoveryParams.recommendedDefaults,
      typeContext: .watch
    )

    XCTAssertEqual(["CTA Clicked"], segmentClient.events)
    XCTAssertEqual("discover", segmentClient.properties.last?["context_page"] as? String)
    XCTAssertEqual("watch_project", segmentClient.properties.last?["context_cta"] as? String)
    XCTAssertEqual("watch", segmentClient.properties.last?["context_type"] as? String)

    self.assertProjectProperties(segmentClient.properties.last)
    self.assertDiscoveryProperties(segmentClient.properties.last)
  }
