  func testFirstUnique() {
    // When duplicate elements are encountered, all permutations use the first
    // instance of the duplicated elements.
    let numbers = Self.numbers.map(IntBox.init)
    for k in 0...numbers.count {
      for p in numbers.uniquePermutations(ofCount: k) {
        XCTAssertTrue(p.filter { $0.value == 1 }.allSatisfy { $0 === numbers[0] })
      }
    }
  }
