  func test_load_relaxed() {
    let v: UnsafeAtomic<UnsafeMutablePointer<Foo>> = .create(_mfoo1)
    defer { v.destroy() }
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo1)

    let w: UnsafeAtomic<UnsafeMutablePointer<Foo>> = .create(_mfoo2)
    defer { w.destroy() }
    XCTAssertEqual(w.load(ordering: .relaxed), _mfoo2)
  }
