    func testHasUpdatedRecently() {
        // Make sure we have an APNS Token
        write { tx in
            SSKEnvironment.shared.preferencesRef.setPushToken("123", tx: tx)
        }
        let now = Date().ows_millisecondsSince1970

        // Should not want to rotate, because the NSE hasn't even had a chance
        // to write anything.
        read {
            APNSRotationStore.nowMs = { now }
            XCTAssertFalse(APNSRotationStore.canRotateAPNSToken(transaction: $0))
        }

        write {
            // mark the app version.
            APNSRotationStore.nowMs = { now }
            APNSRotationStore.setAppVersionTimeForAPNSRotationIfNeeded(transaction: $0)
        }

        read {
            // Simulate time having passed
            APNSRotationStore.nowMs = { now + APNSRotationStore.Constants.appVersionBakeTimeMs + 1 }
            // Now check, we should be eligible to rotate.
            XCTAssert(APNSRotationStore.canRotateAPNSToken(transaction: $0))
        }
    }
