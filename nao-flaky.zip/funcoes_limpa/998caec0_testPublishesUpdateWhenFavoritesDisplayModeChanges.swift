    func testPublishesUpdateWhenFavoritesDisplayModeChanges() {
        let expectation = XCTestExpectation(description: #function)
        let sut = createSUT()

        sut.externalUpdates.sink {
            XCTAssertTrue(Thread.isMainThread)
            expectation.fulfill()
        }
        .store(in: &cancellables)

        NotificationCenter.default.post(name: AppUserDefaults.Notifications.favoritesDisplayModeChange, object: nil)

        wait(for: [expectation], timeout: 1.0)
    }
