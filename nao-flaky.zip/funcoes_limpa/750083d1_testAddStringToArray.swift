    func testAddStringToArray() {
        let expression = AnyExpression("'foo' + [1,2]")
        XCTAssertEqual(try expression.evaluate(), "foo[1, 2]")
    }
