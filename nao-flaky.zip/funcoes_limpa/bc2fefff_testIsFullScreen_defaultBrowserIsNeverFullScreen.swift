    func testIsFullScreen_defaultBrowserIsNeverFullScreen() {
        let launchType = LaunchType.defaultBrowser
        XCTAssertFalse(launchType.isFullScreenAvailable(isIphone: true))
        XCTAssertFalse(launchType.isFullScreenAvailable(isIphone: false))
    }
