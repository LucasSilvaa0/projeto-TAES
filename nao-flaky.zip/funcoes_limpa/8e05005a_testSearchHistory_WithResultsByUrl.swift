    func testSearchHistory_WithResultsByUrl() {
        let expectation = self.expectation(description: "Wait for search history")
        let places = profile.places
        addSite(places, url: "http://amazon.com/", title: "Amazon")
        addSite(places, url: "http://mozilla.developer.org/", title: "Mozilla")
        addSite(places, url: "https://apple.developer.com/", title: "Apple")

        places.queryAutocomplete(matchingSearchQuery: "dev", limit: 25).upon { result in
            XCTAssertTrue(result.isSuccess)
            let results = result.successValue!
            XCTAssertEqual(results.count, 2)
            expectation.fulfill()
        }

        self.waitForExpectations(timeout: 10, handler: nil)
    }
