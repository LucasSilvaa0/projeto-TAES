  func testSearch_NoProject() {
    self.vm.inputs.configureWith(project: nil)

    XCTAssertEqual([], self.segmentTrackingClient.events)

    self.vm.inputs.viewDidLoad()

    self.vm.inputs.viewWillAppear()

    self.hasMessageThreads.assertValues([])
    self.isSearching.assertValues([false])

    self.vm.inputs.searchTextChanged("hello")

    self.hasMessageThreads.assertValues([])
    self.isSearching.assertValues([false, true])

    self.scheduler.advance()

    self.hasMessageThreads.assertValues([true])
    self.isSearching.assertValues([false, true, false])

    withEnvironment(apiService: MockService(fetchMessageThreadsResponse: [])) {
      self.vm.inputs.searchTextChanged("hello world")

      self.hasMessageThreads.assertValues([true, false])
      self.isSearching.assertValues([false, true, false, true])

      self.scheduler.advance()

      self.hasMessageThreads.assertValues([true, false])
      self.isSearching.assertValues([false, true, false, true, false])

      self.vm.inputs.searchTextChanged("")
      self.vm.inputs.searchTextChanged(nil)

      self.hasMessageThreads.assertValues([true, false])
      self.isSearching.assertValues([false, true, false, true, false])

      self.scheduler.advance()

      self.hasMessageThreads.assertValues([true, false])
      self.isSearching.assertValues([false, true, false, true, false])
    }
  }
