  func test_weakCompareExchange_relaxed_acquiring() {
    let v: UnsafeAtomic<UInt64> = .create(12)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UInt64)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: 12,
        desired: 23,
        successOrdering: .relaxed,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.weakCompareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .relaxed,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: 23,
        desired: 12,
        successOrdering: .relaxed,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    (exchanged, original) = v.weakCompareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .relaxed,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)
  }
