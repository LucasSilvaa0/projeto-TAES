    func testParseHexAddress_Overflow_ReturnsUInt64Max() {
        let uIntMaxVastOverflow = "0xFFFFFFFFFFFFFFFFFFFF"
        XCTAssertEqual(UInt64.max, sentry_UInt64ForHexAddress(uIntMaxVastOverflow))
    }
