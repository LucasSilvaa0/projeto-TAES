  func test_bitwiseAndThenLoad_sequentiallyConsistent() {
    let a: UInt16 = 3
    let b: UInt16 = 8
    let c: UInt16 = 12
    let result1: UInt16 = a & b
    let result2: UInt16 = result1 & c

    let v: UnsafeAtomic<UInt16> = .create(a)
    defer { v.destroy() }

    let new1: UInt16 = v.bitwiseAndThenLoad(with: b, ordering: .sequentiallyConsistent)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: UInt16 = v.bitwiseAndThenLoad(with: c, ordering: .sequentiallyConsistent)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
