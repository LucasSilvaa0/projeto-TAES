     func testGrandChildViewController() {
         let root = UIViewController()

         let child = UIViewController()
         root.addChild(child)

         let grandChild1 = UIViewController()
         child.addChild(grandChild1)

         let grandChild2 = UIViewController()
         child.addChild(grandChild2)

         XCTAssertEqual(Set([root, child, grandChild2, grandChild1]), Set(SentryViewController.descendants(of: root)))
     }
