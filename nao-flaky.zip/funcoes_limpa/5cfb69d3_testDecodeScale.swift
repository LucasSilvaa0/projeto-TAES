    func testDecodeScale() {
        #if os(iOS) || os(tvOS) || os(visionOS)
        let image = testImage
        XCTAssertEqual(image.size, CGSize(width: 64, height: 64))
        XCTAssertEqual(image.scale, 1.0)

        let image_2x = KingfisherWrapper<KFCrossPlatformImage>.image(cgImage: image.cgImage!, scale: 2.0, refImage: image)
        XCTAssertEqual(image_2x.size, CGSize(width: 32, height: 32))
        XCTAssertEqual(image_2x.scale, 2.0)
        
        let decoded = image.kf.decoded
        XCTAssertEqual(decoded.size, CGSize(width: 64, height: 64))
        XCTAssertEqual(decoded.scale, 1.0)
        
        let decodedDifferentScale = image.kf.decoded(scale: 2.0)
        XCTAssertEqual(decodedDifferentScale.size, CGSize(width: 32, height: 32))
        XCTAssertEqual(decodedDifferentScale.scale, 2.0)
        
        let decoded_2x = image_2x.kf.decoded
        XCTAssertEqual(decoded_2x.size, CGSize(width: 32, height: 32))
        XCTAssertEqual(decoded_2x.scale, 2.0)
        #endif
    }
