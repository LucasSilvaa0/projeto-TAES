  func test_exchange_releasing() {
    let v: UnsafeAtomic<UnsafeRawPointer> = .create(_raw1)
    defer { v.destroy() }

    XCTAssertEqual(v.exchange(_raw1, ordering: .releasing), _raw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw1)

    XCTAssertEqual(v.exchange(_raw2, ordering: .releasing), _raw1)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)

    XCTAssertEqual(v.exchange(_raw2, ordering: .releasing), _raw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _raw2)
  }
