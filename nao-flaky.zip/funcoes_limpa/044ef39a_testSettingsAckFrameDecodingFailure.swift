    func testSettingsAckFrameDecodingFailure() {
        let frameBytes: [UInt8] = [
            0x00, 0x00, 0x00,  // 3-byte payload length (0 bytes)
            0x04,  // 1-byte frame type (SETTINGS)
            0x01,  // 1-byte flags (ACK)
            0x00, 0x00, 0x00, 0x00,  // 4-byte stream identifier
        ]
        var buf = byteBuffer(withBytes: frameBytes)

        var decoder = HTTP2FrameDecoder(
            allocator: self.allocator,
            expectClientMagic: false,
            maximumSequentialContinuationFrames: self.maximumSequentialContinuationFrames
        )

        // MUST be sent on the root stream
        buf.setInteger(UInt8(1), at: 8)
        decoder.append(bytes: buf)
        XCTAssertThrowsError(
            try decoder.nextFrame(),
            "Should throw a protocol error",
            { err in
                guard let connErr = err as? InternalError, case .codecError(code: .protocolError) = connErr else {
                    XCTFail("Should have thrown a codec error of type PROTOCOL_ERROR")
                    return
                }
            }
        )
        buf.setInteger(UInt8(0), at: 8)
        buf.moveReaderIndex(to: 0)

        // size must be 0 for ACKs
        buf.setInteger(UInt8(1), at: 2)
        buf.writeInteger(UInt8(0))  // append an extra byte so we read it all
        decoder.append(bytes: buf)
        XCTAssertThrowsError(
            try decoder.nextFrame(),
            "Should throw a frame size error",
            { err in
                guard let connErr = err as? InternalError, case .codecError(code: .frameSizeError) = connErr else {
                    XCTFail("Should have thrown a codec error of type FRAME_SIZE_ERROR")
                    return
                }
            }
        )
    }
