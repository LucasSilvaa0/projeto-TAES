  func test_weakCompareExchange_acquiringAndReleasing_acquiring() {
    let v: UnsafeAtomic<UnsafeMutablePointer<Foo>> = .create(_mfoo1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeMutablePointer<Foo>)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _mfoo1,
        desired: _mfoo2,
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, _mfoo1)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo2)

    (exchanged, original) = v.weakCompareExchange(
      expected: _mfoo1,
      desired: _mfoo2,
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mfoo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _mfoo2,
        desired: _mfoo1,
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, _mfoo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo1)

    (exchanged, original) = v.weakCompareExchange(
      expected: _mfoo2,
      desired: _mfoo1,
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mfoo1)
    XCTAssertEqual(v.load(ordering: .relaxed), _mfoo1)
  }
