    func testSectionDimension_landscapeIphone_defaultRowNumber() {
        let subject = createSubject()
        let trait = MockTraitCollection().getTraitCollection()
        let interface = TopSitesUIInterface(isLandscape: true,
                                            interfaceIdiom: .phone,
                                            trait: trait,
                                            availableWidth: DeviceSize.iPhone14.height)

        let dimension = subject.getSectionDimension(for: createSites(), numberOfRows: 2, interface: interface)
        XCTAssertEqual(dimension.numberOfRows, 2)
        XCTAssertEqual(dimension.numberOfTilesPerRow, 8)
    }
