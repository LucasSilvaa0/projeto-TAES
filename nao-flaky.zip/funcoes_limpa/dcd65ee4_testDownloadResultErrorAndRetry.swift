func testDownloadResultErrorAndRetry() {
        let exp = expectation(description: #function)
        
        let url = testURLs[0]

        stub(url, errorCode: -1)
        downloader.downloadImage(with: url) { result in
            XCTAssertNotNil(result.error)
            
            LSNocilla.sharedInstance().clearStubs()

            stub(url, data: testImageData)
            // Retry the download
            self.downloader.downloadImage(with: url) { result in
                XCTAssertNil(result.error)
                exp.fulfill()
            }
        }
        
        waitForExpectations(timeout: 3, handler: nil)
    }
