    func testProtocolType() {
        let runtimeType = RuntimeType(UITableViewDelegate.self)
        guard case .protocol = runtimeType.kind else {
            XCTFail()
            return
        }
        XCTAssert(runtimeType.swiftType == Protocol.self)
    }
