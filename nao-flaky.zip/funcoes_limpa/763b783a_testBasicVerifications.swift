    func testBasicVerifications() {
        let byteBufferContainingJustAnX = ByteBuffer(string: "X")
        let expectedInOuts: [(String, [HTTPServerRequestPart])] = [
            (
                "GET / HTTP/1.1\r\n\r\n",
                [
                    .head(.init(version: .http1_1, method: .GET, uri: "/")),
                    .end(nil),
                ]
            ),
            (
                "POST /foo HTTP/1.1\r\n\r\n",
                [
                    .head(.init(version: .http1_1, method: .POST, uri: "/foo")),
                    .end(nil),
                ]
            ),
            (
                "POST / HTTP/1.1\r\ncontent-length: 1\r\n\r\nX",
                [
                    .head(
                        .init(
                            version: .http1_1,
                            method: .POST,
                            uri: "/",
                            headers: .init([("content-length", "1")])
                        )
                    ),
                    .body(byteBufferContainingJustAnX),
                    .end(nil),
                ]
            ),
            (
                "POST / HTTP/1.1\r\ntransfer-encoding: chunked\r\n\r\n1\r\nX\r\n0\r\n\r\n",
                [
                    .head(
                        .init(
                            version: .http1_1,
                            method: .POST,
                            uri: "/",
                            headers: .init([("transfer-encoding", "chunked")])
                        )
                    ),
                    .body(byteBufferContainingJustAnX),
                    .end(nil),
                ]
            ),
            (
                "POST / HTTP/1.1\r\ntransfer-encoding: chunked\r\none: two\r\n\r\n1\r\nX\r\n0\r\nfoo: bar\r\n\r\n",
                [
                    .head(
                        .init(
                            version: .http1_1,
                            method: .POST,
                            uri: "/",
                            headers: .init([("transfer-encoding", "chunked"), ("one", "two")])
                        )
                    ),
                    .body(byteBufferContainingJustAnX),
                    .end(.init([("foo", "bar")])),
                ]
            ),
        ]

        let expectedInOutsBB: [(ByteBuffer, [HTTPServerRequestPart])] = expectedInOuts.map { io in
            (ByteBuffer(string: io.0), io.1)
        }
        XCTAssertNoThrow(
            try ByteToMessageDecoderVerifier.verifyDecoder(
                inputOutputPairs: expectedInOutsBB,
                decoderFactory: { HTTPRequestDecoder() }
            )
        )
    }
