  func testOptionalFloat() {
    var msg = SwiftProtoTesting_TestAllTypes()
    XCTAssertEqual(msg.optionalFloat, 0.0)
    XCTAssertFalse(msg.hasOptionalFloat)
    msg.optionalFloat = 11.0
    XCTAssertTrue(msg.hasOptionalFloat)
    XCTAssertEqual(msg.optionalFloat, 11.0)
    msg.clearOptionalFloat()
    XCTAssertEqual(msg.optionalFloat, 0.0)
    XCTAssertFalse(msg.hasOptionalFloat)
  }
