    func testSubscriptSubstringWithInvalidHalfOpenIndexRange() {
        let expression = AnyExpression("foo[range]", constants: [
            "foo": "barfoo".suffix(3),
            "range": "barfoo".range(of: "bar")!,
        ])
        XCTAssertThrowsError(try expression.evaluate() as Any) { error in
            XCTAssertEqual(error as? Expression.Error, .stringBounds("foo", -3))
        }
    }
