    func test_ZeroSizeScreenShot_GetsDiscarded() {
        let testWindow = TestWindow(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        fixture.uiApplication.windows = [testWindow]

        let data = self.fixture.sut.appScreenshotsData()

        XCTAssertEqual(0, data.count, "No screenshot should be taken, cause the image has zero size.")
    }
