    func testSerializeWithTypeTransaction() {
        let event = TestData.event
        event.type = "transaction"
        
        let actual = event.serialize()
        XCTAssertEqual(TestData.timestamp.timeIntervalSince1970, actual["start_timestamp"] as? TimeInterval)
    }
