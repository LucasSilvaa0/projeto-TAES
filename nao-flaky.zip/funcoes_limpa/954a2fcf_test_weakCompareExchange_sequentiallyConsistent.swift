  func test_weakCompareExchange_sequentiallyConsistent() {
    let v: UnsafeAtomic<UInt32> = .create(12)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UInt32)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: 12,
        desired: 23,
        ordering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.weakCompareExchange(
      expected: 12,
      desired: 23,
      ordering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: 23,
        desired: 12,
        ordering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    (exchanged, original) = v.weakCompareExchange(
      expected: 23,
      desired: 12,
      ordering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)
  }
