    func testViewModelChangePrefsOrNotAsExpected() {
        let expectedSessionCount: Int32 = 3
        let expectedDidShow = true

        setTestData(installType: .fresh, sessionCount: expectedSessionCount, didShowOnboarding: false)
        verify(expectedShouldShow: true)

        let didShowPref = UserDefaults.standard.bool(forKey: PrefsKeys.KeyDidShowDefaultBrowserOnboarding)
        XCTAssertEqual(didShowPref, expectedDidShow)

        let sessionCount = prefs.intForKey(PrefsKeys.Session.Count)
        XCTAssertEqual(sessionCount, expectedSessionCount)
    }
