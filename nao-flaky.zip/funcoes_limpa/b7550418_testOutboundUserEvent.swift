    func testOutboundUserEvent() {
        self.channel.pipeline.triggerUserOutboundEvent((), promise: nil)

        XCTAssertEqual(
            ["channelRegistered", "register", "triggerUserOutboundEvent"],
            self.handler.allTriggeredEvents()
        )
        XCTAssertNoThrow(try self.handler.checkValidity())
        XCTAssertEqual(1, self.handler.triggerUserOutboundEventCalls)
    }
