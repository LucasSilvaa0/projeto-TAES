func testDelayRetryIntervalCalculating() {
        let secondInternal = DelayRetryStrategy.Interval.seconds(10)
        XCTAssertEqual(secondInternal.timeInterval(for: 0), 10)

        let accumulatedInternal = DelayRetryStrategy.Interval.accumulated(3)
        XCTAssertEqual(accumulatedInternal.timeInterval(for: 0), 3)
        XCTAssertEqual(accumulatedInternal.timeInterval(for: 1), 6)
        XCTAssertEqual(accumulatedInternal.timeInterval(for: 2), 9)
        XCTAssertEqual(accumulatedInternal.timeInterval(for: 3), 12)

        let customInternal = DelayRetryStrategy.Interval.custom { TimeInterval($0 * 2) }
        XCTAssertEqual(customInternal.timeInterval(for: 0), 0)
        XCTAssertEqual(customInternal.timeInterval(for: 1), 2)
        XCTAssertEqual(customInternal.timeInterval(for: 2), 4)
        XCTAssertEqual(customInternal.timeInterval(for: 3), 6)
    }
