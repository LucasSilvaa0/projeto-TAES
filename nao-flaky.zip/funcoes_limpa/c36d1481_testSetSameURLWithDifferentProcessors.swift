    @MainActor func testSetSameURLWithDifferentProcessors() {
        let exp = expectation(description: #function)
        let url = testURLs[0]
        
        stub(url, data: testImageData)
        
        let size1 = CGSize(width: 10, height: 10)
        let p1 = ResizingImageProcessor(referenceSize: size1)
        
        let size2 = CGSize(width: 20, height: 20)
        let p2 = ResizingImageProcessor(referenceSize: size2)
        
        let group = DispatchGroup()
        
        group.enter()
        imageView.kf.setImage(with: url, options: [.processor(p1)]) { result in
            XCTAssertNotNil(result.error)
            XCTAssertTrue(result.error!.isNotCurrentTask)
            group.leave()
        }
        
        group.enter()
        imageView.kf.setImage(with: url, options: [.processor(p2)]) { result in
            XCTAssertNotNil(result.value)
            XCTAssertEqual(result.value!.image.size, size2)
            group.leave()
        }
        
        group.notify(queue: .main) { exp.fulfill() }
        waitForExpectations(timeout: 3, handler: nil)
    }
