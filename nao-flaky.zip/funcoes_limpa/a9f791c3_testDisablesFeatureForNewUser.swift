    func testDisablesFeatureForNewUser() {
        let sut = createSUT()
        statistics.installDate = nil

        sut.configure()

        XCTAssertEqual(storage.newTabPageIntroMessageEnabled, false)
    }
