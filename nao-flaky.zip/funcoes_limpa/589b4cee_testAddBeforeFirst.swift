    func testAddBeforeFirst() {
        let channel = EmbeddedChannel()
        defer {
            XCTAssertNoThrow(try channel.finish())
        }

        let firstHandler = IndexWritingHandler(1)
        XCTAssertNoThrow(try channel.pipeline.syncOperations.addHandler(firstHandler))
        XCTAssertNoThrow(try channel.pipeline.syncOperations.addHandler(IndexWritingHandler(2)))
        XCTAssertNoThrow(
            try channel.pipeline.syncOperations.addHandler(
                IndexWritingHandler(3),
                position: .before(firstHandler)
            )
        )

        channel.assertReadIndexOrder([3, 1, 2])
        channel.assertWriteIndexOrder([2, 1, 3])
    }
