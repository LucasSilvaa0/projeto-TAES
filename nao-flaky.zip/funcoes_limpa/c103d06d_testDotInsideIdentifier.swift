    func testDotInsideIdentifier() {
        let expression = Expression("foo.bar", options: .boolSymbols)
        XCTAssertEqual(expression.symbols, [.variable("foo.bar")])
    }
