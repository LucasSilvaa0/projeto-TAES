    func testParsesActivities() {
        let activities = bitbucketCould.activities

        XCTAssertEqual(activities, [
            BitBucketCloud.Activity(comment: nil),
            BitBucketCloud.Activity(comment: nil),
        ])
    }
