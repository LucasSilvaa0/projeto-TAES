  func testObserveChildCount() {
    self.app.buttons["Toggle observing child count"].tap()
    XCTAssertEqual(self.app.staticTexts["Child count: 0"].exists, true)
    self.assertLogs {
      """
      OldContainsNewTestCase.body
      ViewStore<OldContainsNewTestCase.ViewState, OldContainsNewTestCase.Feature.Action>.deinit
      ViewStore<OldContainsNewTestCase.ViewState, OldContainsNewTestCase.Feature.Action>.init
      WithViewStore<OldContainsNewTestCase.ViewState, OldContainsNewTestCase.Feature.Action>.body
      """
    }
  }
