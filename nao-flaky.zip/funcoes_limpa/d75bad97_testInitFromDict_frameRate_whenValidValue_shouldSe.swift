    func testInitFromDict_frameRate_whenValidValue_shouldSetValue() {
        // -- Act --
        let options = SentryReplayOptions(dictionary: [
            "frameRate": 5
        ])

        // -- Assert --
        XCTAssertEqual(options.frameRate, 5)
    }
