  func testJSONDecoding_WithBadData() {
    let activity: Activity! = Activity.decodeJSONDictionary([
      "category": "update"
    ])

    XCTAssertNil(activity)
  }
