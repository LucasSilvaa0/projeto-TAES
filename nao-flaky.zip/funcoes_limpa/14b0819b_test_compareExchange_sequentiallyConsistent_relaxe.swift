  func test_compareExchange_sequentiallyConsistent_relaxed() {
    let v: UnsafeAtomic<Bool> = .create(true)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Bool) = v.compareExchange(
      expected: true,
      desired: false,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, true)
    XCTAssertEqual(v.load(ordering: .relaxed), false)

    (exchanged, original) = v.compareExchange(
      expected: true,
      desired: false,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, false)
    XCTAssertEqual(v.load(ordering: .relaxed), false)

    (exchanged, original) = v.compareExchange(
      expected: false,
      desired: true,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, false)
    XCTAssertEqual(v.load(ordering: .relaxed), true)

    (exchanged, original) = v.compareExchange(
      expected: false,
      desired: true,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, true)
    XCTAssertEqual(v.load(ordering: .relaxed), true)
  }
