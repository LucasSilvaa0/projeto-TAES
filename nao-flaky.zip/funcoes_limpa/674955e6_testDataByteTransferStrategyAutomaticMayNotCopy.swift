    func testDataByteTransferStrategyAutomaticMayNotCopy() {
        let byteCount = 500_000  // this needs to be larger than ByteBuffer's heuristic's threshold.
        self.buf.clear()
        self.buf.writeString(String(repeating: "x", count: byteCount))
        var byteBufferPointerValue: UInt = 0xbad
        var dataPointerValue: UInt = 0xdead
        self.buf.withUnsafeReadableBytes { ptr in
            byteBufferPointerValue = UInt(bitPattern: ptr.baseAddress)
        }
        if let data = self.buf.readData(length: byteCount, byteTransferStrategy: .automatic) {
            data.withUnsafeBytes { ptr in
                dataPointerValue = UInt(bitPattern: ptr.baseAddress)
            }
        } else {
            XCTFail("unable to read Data from ByteBuffer")
        }

        XCTAssertEqual(byteBufferPointerValue, dataPointerValue)
    }
