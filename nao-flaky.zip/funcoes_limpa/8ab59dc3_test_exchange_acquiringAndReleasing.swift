  func test_exchange_acquiringAndReleasing() {
    let v: UnsafeAtomic<UnsafeMutableRawPointer?> = .create(nil)
    defer { v.destroy() }

    XCTAssertEqual(v.exchange(nil, ordering: .acquiringAndReleasing), nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    XCTAssertEqual(v.exchange(_mraw2, ordering: .acquiringAndReleasing), nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    XCTAssertEqual(v.exchange(_mraw2, ordering: .acquiringAndReleasing), _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)
  }
