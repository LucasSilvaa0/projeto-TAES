    func testCoreCountWorks() {
        XCTAssertGreaterThan(System.coreCount, 0)
    }
