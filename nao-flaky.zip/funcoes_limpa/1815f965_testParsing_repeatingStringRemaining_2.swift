  func testParsing_repeatingStringRemaining_2() {
    AssertParse(Baz.self, ["--names"]) { baz in
      XCTAssertFalse(baz.verbose)
      XCTAssertTrue(baz.names.isEmpty)
    }
  }
