    func testDataScrubbed_lazyFormatted() {
        let testCases: [Data: String] = [
            .init([0]): "<00…>",
            .init([0, 0, 0]): "<00…>",
            .init([1]): "<01…>",
            .init([1, 2, 3, 0x10, 0x20]): "<01…>",
            .init([0xff]): "<ff…>",
            .init([0xff, 0xff, 0xff]): "<ff…>"
        ]

        for (inputData, expectedOutput) in testCases {
            let input = (inputData as NSData).description
            XCTAssertEqual(
                format(input),
                expectedOutput,
                "Failed redaction: \(input)"
            )
        }
    }
