    func testWhenVariantIsInCurrentExperimentThenVariantIsNotRemovedFromStorage() {

        let variant = VariantIOS(name: Constants.variant, weight: 100, isIncluded: VariantIOS.When.always, features: [])
        let mockVariantManager = MockVariantManager(currentVariant: variant)

        mockStorage.atb = "\(Constants.atb)\(Constants.variant)"
        mockStorage.variant = Constants.variant

        AtbAndVariantCleanup.cleanup(statisticsStorage: mockStorage, variantManager: mockVariantManager)

        XCTAssertEqual(Constants.variant, mockStorage.variant)

    }
