  func test_weakCompareExchange_relaxed_acquiring() {
    let v: UnsafeAtomic<Bool> = .create(true)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Bool)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: true,
        desired: false,
        successOrdering: .relaxed,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, true)
    XCTAssertEqual(v.load(ordering: .relaxed), false)

    (exchanged, original) = v.weakCompareExchange(
      expected: true,
      desired: false,
      successOrdering: .relaxed,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, false)
    XCTAssertEqual(v.load(ordering: .relaxed), false)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: false,
        desired: true,
        successOrdering: .relaxed,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, false)
    XCTAssertEqual(v.load(ordering: .relaxed), true)

    (exchanged, original) = v.weakCompareExchange(
      expected: false,
      desired: true,
      successOrdering: .relaxed,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, true)
    XCTAssertEqual(v.load(ordering: .relaxed), true)
  }
