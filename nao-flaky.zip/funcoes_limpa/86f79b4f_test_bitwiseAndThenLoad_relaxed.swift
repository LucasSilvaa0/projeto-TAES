  func test_bitwiseAndThenLoad_relaxed() {
    let a: Int32 = 3
    let b: Int32 = 8
    let c: Int32 = 12
    let result1: Int32 = a & b
    let result2: Int32 = result1 & c

    let v: UnsafeAtomic<Int32> = .create(a)
    defer { v.destroy() }

    let new1: Int32 = v.bitwiseAndThenLoad(with: b, ordering: .relaxed)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: Int32 = v.bitwiseAndThenLoad(with: c, ordering: .relaxed)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
