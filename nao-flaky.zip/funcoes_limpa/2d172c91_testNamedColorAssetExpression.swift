    func testNamedColorAssetExpression() {
        let node = LayoutNode()
        let expression = LayoutExpression(colorExpression: "MyColor{1}", for: node)
        XCTAssertThrowsError(try expression?.evaluate() as? UIColor) { error in
            if #available(iOS 11.0, *) {
                XCTAssert("\(error)".contains("Invalid color name"))
            } else {
                XCTAssert("\(error)".contains("iOS 11"))
            }
        }
    }
