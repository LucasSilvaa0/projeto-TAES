    func testFormatExpirationDate() {
        // We test this by "round-tripping".
        let testCases: [String] = [
            "",
            "0",
            "1",
            "2/",
            "9/",
            "01/",
            "02/",
            "10/",
            "11/",
            "12/",
            "1/3",
            "1/9",
            "2/3",
            "2/00",
            "2/34",
            "01/00",
            "01/23",
            "02/00",
            "02/34",
            "10/98",
            "12/34",
            // These cases aren't that important because they're invalid.
            // If these tests fail, that's probably fine.
            // We mostly want to ensure they don't crash.
            "1/345",
            "0/0",
            "0/000"
        ]

        for testCase in testCases {
            let reformatted = DonationPaymentDetailsViewController.formatExpirationDate(
                unformatted: testCase.asciiDigitsOnly
            )
            XCTAssertEqual(reformatted, testCase)
        }
    }
