    func testNilMessage() {
        let subject = createSubject()

        XCTAssertFalse(subject.hasData)
        XCTAssertTrue(subject.isEnabled)
        XCTAssertEqual(subject.headerViewModel, .emptyHeader)
        XCTAssertEqual(subject.numberOfItemsInSection(), 1)
        XCTAssertEqual(subject.sectionType, .messageCard)
        XCTAssertFalse(subject.shouldDisplayMessageCard)
    }
