  func testTarget() {
    let target = BuildKey.Target(name: "foobar")
    XCTAssertEqual(target.kind, .target)
    XCTAssertEqual(target.name, "foobar")
    XCTAssertFalse(target.keyData.isEmpty)
    XCTAssertEqual(target.key, "foobar")
    XCTAssertEqual(target, target)
    XCTAssertNotEqual(target, BuildKey.Target(name: "foobar2"))
  }
