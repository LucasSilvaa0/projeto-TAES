  func test_exchange_acquiringAndReleasing() {
    let v: UnsafeAtomic<Unmanaged<Bar>> = .create(_bar1)
    defer { v.destroy() }

    XCTAssertEqual(v.exchange(_bar1, ordering: .acquiringAndReleasing), _bar1)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar1)

    XCTAssertEqual(v.exchange(_bar2, ordering: .acquiringAndReleasing), _bar1)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    XCTAssertEqual(v.exchange(_bar2, ordering: .acquiringAndReleasing), _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)
  }
