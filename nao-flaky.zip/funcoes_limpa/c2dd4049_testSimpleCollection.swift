    func testSimpleCollection() {
        let base = NIOSSLSecureBytes(0..<100)
        XCTAssertEqual(base.count, 100)
        XCTAssertEqual(Array(base), Array(0..<100))
        XCTAssertEqual(base.first, 0)
        XCTAssertEqual(base.last, 99)
        XCTAssertEqual(base.reduce(Int(0)) { Int($0) + Int($1) }, 4950)
    }
