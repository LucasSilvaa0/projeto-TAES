    func testSubscriptArrayWithWrongRangeUpToType() {
        let range = ..<"foo".endIndex
        let expression = AnyExpression("[1,2,3,4][range]", constants: [
            "range": range,
        ])
        XCTAssertThrowsError(try expression.evaluate() as Any) { error in
            XCTAssertEqual(error as? Expression.Error, .typeMismatch(.infix("[]"), [[Any](), range]))
        }
    }
