    func testHasNoPushToken() {
        // Make sure we don't have an APNS token
        SSKEnvironment.shared.preferencesRef.removeAllValues()
        let now = Date().ows_millisecondsSince1970

        // Make sure we are otherwise eligible to rotate, so
        // that we know it is the lack of an APNS token that stopped it.
        write { transaction in
            // Mark as checked in the past so that we'd be eligible after an app update.
            APNSRotationStore.nowMs = {
                return now
                    - APNSRotationStore.Constants.appVersionBakeTimeMs
                    - 1
            }
            APNSRotationStore.setAppVersionTimeForAPNSRotationIfNeeded(transaction: transaction)

            // Fake a missed message so we'd rotate.
            self.createIncomingMessage(
                receivedTimestamp: now - UInt64.minuteInMs,
                transaction: transaction
            )
        }

        read {
            APNSRotationStore.nowMs = { now }
            // No rotation because there's no APNS token.
            XCTAssertFalse(APNSRotationStore.canRotateAPNSToken(transaction: $0))
        }

        // Set an APNS token.
        write { tx in
            SSKEnvironment.shared.preferencesRef.setPushToken("123", tx: tx)
        }

        read {
            // Nothing changed but the token, but we should now rotate.
            XCTAssert(APNSRotationStore.canRotateAPNSToken(transaction: $0))
        }
    }
