func testGenerateSingleFrameGIFImage() {
        let options = ImageCreatingOptions()
        let image = KingfisherWrapper<KFCrossPlatformImage>.animatedImage(data: testImageSingleFrameGIFData, options: options)
        XCTAssertNotNil(image)
        #if os(iOS) || os(tvOS) || os(visionOS)
        XCTAssertEqual(image!.kf.imageFrameCount!, 1)
        #else
        XCTAssertEqual(image!.kf.images!.count, 1)
        XCTAssertEqual(image!.kf.duration, Double.infinity)
        #endif
    }
