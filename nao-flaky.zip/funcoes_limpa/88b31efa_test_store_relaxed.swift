  func test_store_relaxed() {
    let v: UnsafeAtomic<Unmanaged<Bar>> = .create(_bar1)
    defer { v.destroy() }
    v.store(_bar2, ordering: .relaxed)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    let w: UnsafeAtomic<Unmanaged<Bar>> = .create(_bar2)
    defer { w.destroy() }
    w.store(_bar1, ordering: .relaxed)
    XCTAssertEqual(w.load(ordering: .relaxed), _bar1)
  }
