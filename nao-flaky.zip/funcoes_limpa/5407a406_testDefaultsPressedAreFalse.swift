    func testDefaultsPressedAreFalse() {
        let handler = KeyboardPressesHandler()
        XCTAssertEqual(handler.isOnlyCmdPressed, false)
        XCTAssertEqual(handler.isOnlyOptionPressed, false)
        XCTAssertEqual(handler.isCmdAndShiftPressed, false)
        handler.handlePressesBegan(Set(), with: nil)
    }
