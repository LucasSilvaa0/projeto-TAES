    func testCanNavigateGivenInternalAboutUrlThenAllowed() {
        let url = URL(string: "about://home.com")!
        let context = BrowsingContext(type: .internalNavigation,
                                      url: url)
        let subject = createSubject()

        let result = subject.canNavigateWith(browsingContext: context)

        XCTAssertEqual(result, .allowed)
    }
