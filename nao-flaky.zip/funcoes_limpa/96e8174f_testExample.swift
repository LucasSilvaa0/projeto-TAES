  func testExample() {
    XCTAssertEqual("Blob", (/Result<String, Error>.success).extract(from: .success("Blob")))
    XCTAssertNil((/Result<String, Error>.failure).extract(from: .success("Blob")))

    XCTAssertEqual(42, (/Int??.some .. Int?.some).extract(from: Optional(Optional(42))))
  }
