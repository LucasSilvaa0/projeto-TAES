    func testUpdateRecord() {
        let result = createRecordWithURL(
            "http://www.anandtech.com/show/9117/analyzing-intel-core-m-performance",
            title: "Analyzing Intel Core M Performance: How 5Y10 can beat 5Y71 & the OEMs' Dilemma",
            addedBy: "Stefan's iPhone")
        if let record = result.successValue {
            XCTAssertEqual(
                record.url,
                "http://www.anandtech.com/show/9117/analyzing-intel-core-m-performance"
            )
            XCTAssertEqual(
                record.title,
                "Analyzing Intel Core M Performance: How 5Y10 can beat 5Y71 & the OEMs' Dilemma"
            )
            XCTAssertEqual(record.addedBy, "Stefan's iPhone")
            XCTAssertEqual(record.unread, true)
            XCTAssertEqual(record.archived, false)
            XCTAssertEqual(record.favorite, false)

            let result = updateRecord(record, unread: false)
            if let record = result.successValue {
                XCTAssertEqual(
                    record.url,
                    "http://www.anandtech.com/show/9117/analyzing-intel-core-m-performance"
                )
                XCTAssertEqual(
                    record.title,
                    "Analyzing Intel Core M Performance: How 5Y10 can beat 5Y71 & the OEMs' Dilemma"
                )
                XCTAssertEqual(record.addedBy, "Stefan's iPhone")
                XCTAssertEqual(record.unread, false)
                XCTAssertEqual(record.archived, false)
                XCTAssertEqual(record.favorite, false)
            }
        }
    }
