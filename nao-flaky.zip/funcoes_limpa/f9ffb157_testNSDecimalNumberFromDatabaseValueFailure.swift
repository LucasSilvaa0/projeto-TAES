    func testNSDecimalNumberFromDatabaseValueFailure() {
        let databaseValue_Null = DatabaseValue.null
        let databaseValue_String = "foo".databaseValue
        let databaseValue_Blob = "bar".data(using: .utf8)!.databaseValue
        XCTAssertNil(NSDecimalNumber.fromDatabaseValue(databaseValue_Null))
        XCTAssertNil(NSDecimalNumber.fromDatabaseValue(databaseValue_String))
        XCTAssertNil(NSDecimalNumber.fromDatabaseValue(databaseValue_Blob))
    }
