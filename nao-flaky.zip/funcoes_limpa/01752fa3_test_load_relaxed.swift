  func test_load_relaxed() {
    let v: UnsafeAtomic<Int32> = .create(12)
    defer { v.destroy() }
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    let w: UnsafeAtomic<Int32> = .create(23)
    defer { w.destroy() }
    XCTAssertEqual(w.load(ordering: .relaxed), 23)
  }
