  func testSubscriptionOwnsStorePublisher() {
    var store: Store<Void, Void>? = Store(initialState: ()) {}
    weak var weakStore = store
    let cancellable = store!.publisher
      .sink { _ in }
    store = nil
    XCTAssertNotNil(weakStore)
    cancellable.cancel()
    XCTAssertNil(weakStore)
  }
