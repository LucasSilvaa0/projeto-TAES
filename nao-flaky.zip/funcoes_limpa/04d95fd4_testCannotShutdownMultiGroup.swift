    func testCannotShutdownMultiGroup() {
        XCTAssertThrowsError(try MultiThreadedEventLoopGroup.singleton.syncShutdownGracefully()) { error in
            XCTAssertEqual(.unsupportedOperation, error as? EventLoopError)
        }
    }
