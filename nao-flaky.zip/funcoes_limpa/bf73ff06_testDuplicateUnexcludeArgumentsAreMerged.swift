    func testDuplicateUnexcludeArgumentsAreMerged() {
        let input = ["", "--unexclude", "foo", "--unexclude", "bar"]
        let output = ["0": "", "unexclude": "foo,bar"]
        XCTAssertEqual(try preprocessArguments(input, [
            "unexclude",
        ]), output)
    }
