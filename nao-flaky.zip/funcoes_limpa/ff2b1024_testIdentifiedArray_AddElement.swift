  func testIdentifiedArray_AddElement() {
    var state = ParentState()
    let rowsDidChange = self.expectation(description: "rowsDidChange")

    withPerceptionTracking {
      _ = state.rows
    } onChange: {
      rowsDidChange.fulfill()
    }

    state.rows.append(ChildState())
    XCTAssertEqual(state.rows.count, 1)
    self.wait(for: [rowsDidChange], timeout: 0)
  }
