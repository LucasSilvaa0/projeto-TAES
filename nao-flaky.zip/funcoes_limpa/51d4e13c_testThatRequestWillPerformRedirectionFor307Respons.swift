    func testThatRequestWillPerformRedirectionFor307Response() {
        // Given
        let session = Session(configuration: .ephemeral)
        let redirectURLString = Endpoint().url.absoluteString

        let expectation = expectation(description: "Request should redirect to \(redirectURLString)")

        var response: DataResponse<Data?, AFError>?

        // When
        session.request(.redirectTo(redirectURLString, code: 307))
            .response { resp in
                response = resp
                expectation.fulfill()
            }

        waitForExpectations(timeout: timeout)

        // Then
        XCTAssertNotNil(response?.request)
        XCTAssertNotNil(response?.response)
        XCTAssertNotNil(response?.data)
        XCTAssertNil(response?.error)

        XCTAssertEqual(response?.response?.url?.absoluteString, redirectURLString)
        XCTAssertEqual(response?.response?.statusCode, 200)
    }
