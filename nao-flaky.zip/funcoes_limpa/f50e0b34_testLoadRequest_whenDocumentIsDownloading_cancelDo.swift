    func testLoadRequest_whenDocumentIsDownloading_cancelDownload() {
        let subject = createSubject()
        let document = MockTemporaryDocument(withFileURL: url)

        setIsPDFRefactorFeature(isEnabled: true)
        subject.webView = mockTabWebView
        document.isDownloading = true
        subject.enqueueDocument(document)

        subject.loadRequest(URLRequest(url: url))
        // remove it so in Tab deinit there is no crash for KVO
        subject.webView = nil

        XCTAssertNil(subject.temporaryDocument)

        XCTAssertEqual(
            mockTabWebView.loadFileURLCalled,
            1,
            "enqueue document should call load file url on webView"
        )
        XCTAssertEqual(
            mockTabWebView.loadCalled,
            1,
            "load request should call load on webView"
        )
        XCTAssertEqual(mockTabWebView.reloadFromOriginCalled, 0)
    }
