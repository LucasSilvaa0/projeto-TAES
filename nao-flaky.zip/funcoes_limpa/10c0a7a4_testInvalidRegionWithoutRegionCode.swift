    func testInvalidRegionWithoutRegionCode() {
        let locale = Locale(identifier: "")
        XCTAssertFalse(
            AddressLocaleFeatureValidator.isValidRegion(locale: locale),
            "Invalid region for locale without region code"
        )
    }
