    func testCombinedPartiallyDroppedSpans() {
        SentryDependencyContainer.sharedInstance().globalEventProcessor.add { event in
            if let transaction = event as? Transaction {
                transaction.spans = transaction.spans.filter {
                    $0.operation != "child1"
                }
                return transaction
            } else {
                return event
            }
        }
        
        let transaction = Transaction(
            trace: fixture.trace,
            children: [
                fixture.trace.startChild(operation: "child1"),
                fixture.trace.startChild(operation: "child2"),
                fixture.trace.startChild(operation: "child3")
            ]
        )
        
        fixture.getSut(configureOptions: { options in
            options.beforeSend = { event in
                if let transaction = event as? Transaction {
                    transaction.spans = transaction.spans.filter {
                        $0.operation != "child2"
                    }
                    return transaction
                } else {
                    return event
                }
            }
            options.beforeSendSpan = { span in
                if span.operation == "child3" {
                    return nil
                } else {
                    return span
                }
            }
        }).capture(event: transaction)
        
        XCTAssertEqual(3, fixture.transport.recordLostEventsWithCount.count)
        
        // span dropped by event processor
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(0)?.category, SentryDataCategory.span)
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(0)?.reason, SentryDiscardReason.eventProcessor)
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(0)?.quantity, 1)
        
        // span dropped by beforeSendSpan
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(1)?.category, SentryDataCategory.span)
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(1)?.reason, SentryDiscardReason.beforeSend)
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(1)?.quantity, 1)
        
        // span dropped by beforeSend
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(2)?.category, SentryDataCategory.span)
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(2)?.reason, SentryDiscardReason.beforeSend)
        XCTAssertEqual(fixture.transport.recordLostEventsWithCount.get(2)?.quantity, 1)
    }
