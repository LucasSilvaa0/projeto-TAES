  func test_compareExchange_relaxed() {
    let v: UnsafeAtomic<UInt64> = .create(12)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UInt64) = v.compareExchange(
      expected: 12,
      desired: 23,
      ordering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 12,
      desired: 23,
      ordering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      ordering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      ordering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)
  }
