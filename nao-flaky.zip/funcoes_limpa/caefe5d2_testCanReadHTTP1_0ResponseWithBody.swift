    func testCanReadHTTP1_0ResponseWithBody() {
        var state = HTTPRequestStateMachine(isChannelWritable: true)
        let requestHead = HTTPRequestHead(version: .http1_1, method: .GET, uri: "/")
        let metadata = RequestFramingMetadata(connectionClose: false, body: .fixedSize(0))
        XCTAssertEqual(
            state.startRequest(head: requestHead, metadata: metadata),
            .sendRequestHead(requestHead, sendEnd: true)
        )

        let responseHead = HTTPResponseHead(version: .http1_0, status: .internalServerError)
        let body = ByteBuffer(string: "foo bar")
        XCTAssertEqual(
            state.channelRead(.head(responseHead)),
            .forwardResponseHead(responseHead, pauseRequestBodyStream: false)
        )
        XCTAssertEqual(state.demandMoreResponseBodyParts(), .wait)
        XCTAssertEqual(state.channelReadComplete(), .wait)
        XCTAssertEqual(state.read(), .read)
        XCTAssertEqual(state.channelReadComplete(), .wait)
        XCTAssertEqual(state.channelRead(.body(body)), .wait)
        XCTAssertEqual(state.channelRead(.end(nil)), .succeedRequest(.close, [body]))
        XCTAssertEqual(state.channelInactive(), .wait)
    }
