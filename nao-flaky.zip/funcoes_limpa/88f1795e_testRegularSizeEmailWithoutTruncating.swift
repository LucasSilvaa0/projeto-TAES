    func testRegularSizeEmailWithoutTruncating() {
        let email = "daxtheduck@duck.com"
        let expectedEmail = "daxtheduck@duck.com"
        
        let result = AutofillInterfaceEmailTruncator.truncateEmail(email, maxLength: 20)
        
        XCTAssertEqual(expectedEmail, result, "emails should match")
    }
