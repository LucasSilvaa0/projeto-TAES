    func testSubmitButtonAccessibilityHint() {
        for input in inputCombinations {
            let config = SentryUserFeedbackConfiguration()
            config.configureForm = {
                $0.isNameRequired = input.config.requiresName
                $0.isEmailRequired = input.config.requiresEmail
            }
            let fixture = Fixture(config: config, testCaseConfig: input.config)
            let viewModel = fixture.controller.viewModel
            viewModel.fullNameTextField.text = input.config.nameInput
            viewModel.emailTextField.text = input.config.emailInput
            viewModel.messageTextView.text = input.config.messageInput
            func testCaseDescription() -> String {
                "(config: (requiresName: \(input.config.requiresName), requiresEmail: \(input.config.requiresEmail), nameInput: \(input.config.nameInput == nil ? "nil" : "\"\(input.config.nameInput!)\""), emailInput: \(input.config.emailInput == nil ? "nil" : "\"\(input.config.emailInput!)\""), messageInput: \(input.config.messageInput == nil ? "nil" : "\"\(input.config.messageInput!)\""), includeScreenshot: \(input.config.includeScreenshot)), expectedSubmitButtonAccessibilityHint: \(input.expectedSubmitButtonAccessibilityHint)"
            }

            switch viewModel.validate() {
            case .success(let hint):
                XCTAssert(input.shouldValidate)
                XCTAssertEqual(hint, input.expectedSubmitButtonAccessibilityHint, testCaseDescription())
            case .failure(let error):
                XCTAssertFalse(input.shouldValidate, error.description + "; " + testCaseDescription())
            }

        }
    }
