func testNormalized() {
        // Full loaded GIF image should not be normalized since it is a set of images.
        let options = ImageCreatingOptions()
        let gifImage = KingfisherWrapper<KFCrossPlatformImage>.animatedImage(data: testImageGIFData, options: options)
        
        XCTAssertNotNil(gifImage)
        XCTAssertEqual(gifImage!.kf.normalized, gifImage!)
        
        #if os(iOS) || os(tvOS) || os(visionOS)
        // No need to normalize up orientation image.
        let normalImage = testImage
        XCTAssertEqual(normalImage.imageOrientation, .up)
        XCTAssertEqual(normalImage.kf.normalized, testImage)

        let colorImage = UIImage.from(color: .red, size: CGSize(width: 100, height: 200))
        let rotatedImage = UIImage(cgImage: colorImage.cgImage!, scale: colorImage.scale, orientation: .right)

        XCTAssertEqual(rotatedImage.imageOrientation, .right)

        let rotatedNormalizedImage = rotatedImage.kf.normalized
        XCTAssertEqual(rotatedNormalizedImage.imageOrientation, .up)
        XCTAssertEqual(rotatedNormalizedImage.size, CGSize(width: 200, height: 100))
        #endif
    }
