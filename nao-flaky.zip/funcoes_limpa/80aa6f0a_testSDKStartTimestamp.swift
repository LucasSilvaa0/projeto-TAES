    func testSDKStartTimestamp() {
        let currentDateProvider = TestCurrentDateProvider()
        SentryDependencyContainer.sharedInstance().dateProvider = currentDateProvider

        XCTAssertNil(SentrySDK.startTimestamp)

        SentrySDK.start { options in
            options.dsn = SentrySDKTests.dsnAsString
            options.removeAllIntegrations()
        }

        XCTAssertEqual(SentrySDK.startTimestamp, currentDateProvider.date())

        SentrySDK.close()
        XCTAssertNil(SentrySDK.startTimestamp)
    }
