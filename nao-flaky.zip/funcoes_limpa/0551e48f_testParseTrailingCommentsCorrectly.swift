    func testParseTrailingCommentsCorrectly() {
        let input = """
        struct Foo {
            var bar = "bar"
            /// Leading comment
            public var baz = "baz" // Trailing comment
            var quux = "quux"
        }
        """

        let originalTokens = tokenize(input)
        let declarations = Formatter(originalTokens).parseDeclarations()

        XCTAssertEqual(
            sourceCode(for: declarations[0].body?[0].tokens),
            """
                var bar = "bar"

            """
        )

        XCTAssertEqual(
            sourceCode(for: declarations[0].body?[0].tokens),
            """
                var bar = "bar"

            """
        )

        XCTAssertEqual(
            sourceCode(for: declarations[0].body?[1].tokens),
            """
                /// Leading comment
                public var baz = "baz" // Trailing comment

            """
        )

        XCTAssertEqual(
            sourceCode(for: declarations[0].body?[2].tokens),
            """
                var quux = "quux"

            """
        )
    }
