    func testShowPromptAction() {
        let initialState = createSubject()
        let reducer = microsurveyReducer()

        XCTAssertEqual(initialState.showPrompt, false)

        let action = MicrosurveyPromptMiddlewareAction(
            windowUUID: .XCTestDefaultUUID,
            actionType: MicrosurveyPromptMiddlewareActionType.initialize
        )
        let newState = reducer(initialState, action)

        XCTAssertEqual(newState.showPrompt, true)
        XCTAssertEqual(newState.showSurvey, false)
    }
