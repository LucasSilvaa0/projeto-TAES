    func testWriteOneByteQUICVariableLengthIntegerWithTwoBytesReserved() {
        // We only need one byte but the encoder will use 2 because we reserved 2
        var buffer = ByteBuffer()
        let strategy = ByteBuffer.QUICBinaryEncodingStrategy.quic
        let bytesWritten = strategy.writeInteger(0b00000001, reservedCapacity: 2, to: &buffer)
        XCTAssertEqual(bytesWritten, 2)
        XCTAssertEqual(buffer.readInteger(as: UInt16.self), UInt16(0b01000000_00000001))
        XCTAssertEqual(buffer.readableBytes, 0)
    }
