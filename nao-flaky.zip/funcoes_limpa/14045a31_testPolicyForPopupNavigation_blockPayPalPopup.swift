    func testPolicyForPopupNavigation_blockPayPalPopup() {
        let subject = createSubject()
        let url = URL(string: "https://www.paypal.com")!

        let policy = subject.policyForPopupNavigation(action: MockNavigationAction(url: url))

        XCTAssertEqual(policy, .cancel)
    }
