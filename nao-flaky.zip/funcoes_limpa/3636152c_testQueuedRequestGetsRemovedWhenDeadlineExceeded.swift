    func testQueuedRequestGetsRemovedWhenDeadlineExceeded() {
        struct MyError: Error, Equatable {}
        XCTAsyncTest {
            func workaround(_ continuation: CheckedContinuation<HTTPClientResponse, Error>) {
                var state = Transaction.StateMachine(continuation)
                let queuer = MockTaskQueuer()

                state.requestWasQueued(queuer)

                let deadlineExceededAction = state.deadlineExceeded()
                guard case .cancelSchedulerOnly(let scheduler) = deadlineExceededAction else {
                    return XCTFail("Unexpected fail action: \(deadlineExceededAction)")
                }
                XCTAssertIdentical(scheduler as? MockTaskQueuer, queuer)

                let failAction = state.fail(MyError())
                guard
                    case .failResponseHead(let continuation, let error, nil, nil, bodyStreamContinuation: nil) =
                        failAction
                else {
                    return XCTFail("Unexpected fail action: \(failAction)")
                }
                XCTAssertIdentical(scheduler as? MockTaskQueuer, queuer)

                continuation.resume(throwing: error)
            }

            await XCTAssertThrowsError(try await withCheckedThrowingContinuation(workaround)) {
                XCTAssertEqualTypeAndValue($0, MyError())
            }
        }
    }
