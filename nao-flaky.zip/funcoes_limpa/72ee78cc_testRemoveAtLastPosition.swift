    func testRemoveAtLastPosition() {
        var ring = CircularBuffer<Int>(initialCapacity: 4)
        for idx in 0..<7 {
            ring.prepend(idx)
        }

        let last = ring.remove(at: ring.index(ring.endIndex, offsetBy: -1))
        XCTAssertEqual(0, last)
        XCTAssertEqual(1, ring.last)
    }
