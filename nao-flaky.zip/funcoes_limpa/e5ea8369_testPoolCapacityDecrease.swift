    func testPoolCapacityDecrease() {
        let allocator = ByteBufferAllocator()
        var pool = NIOPooledRecvBufferAllocator(
            capacity: 5,
            recvAllocator: FixedSizeRecvByteBufferAllocator(capacity: 1024)
        )

        // Fill the pool.
        var buffers: [ByteBuffer] = []
        for _ in (0..<pool.capacity) {
            let (buffer, _) = pool.buffer(allocator: allocator) { _ in }
            buffers.append(buffer)
        }
        XCTAssertEqual(pool.count, 5)
        XCTAssertEqual(pool.capacity, 5)

        // Reduce the capacity.
        pool.updateCapacity(to: 3)
        XCTAssertEqual(pool.count, 3)
        XCTAssertEqual(pool.capacity, 3)
    }
