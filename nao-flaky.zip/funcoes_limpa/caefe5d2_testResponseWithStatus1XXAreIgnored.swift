    func testResponseWithStatus1XXAreIgnored() {
        var state = HTTPRequestStateMachine(isChannelWritable: true)
        let requestHead = HTTPRequestHead(version: .http1_1, method: .GET, uri: "/")
        let metadata = RequestFramingMetadata(connectionClose: false, body: .fixedSize(0))
        XCTAssertEqual(
            state.startRequest(head: requestHead, metadata: metadata),
            .sendRequestHead(requestHead, sendEnd: true)
        )

        let continueHead = HTTPResponseHead(version: .http1_1, status: .continue)
        XCTAssertEqual(state.channelRead(.head(continueHead)), .wait)

        let responseHead = HTTPResponseHead(version: .http1_1, status: .ok)
        XCTAssertEqual(
            state.channelRead(.head(responseHead)),
            .forwardResponseHead(responseHead, pauseRequestBodyStream: false)
        )
        XCTAssertEqual(state.channelRead(.end(nil)), .succeedRequest(.none, .init()))
        XCTAssertEqual(state.channelReadComplete(), .wait)
        XCTAssertEqual(state.read(), .read)
    }
