    func testPostWithAsyncSequenceWithKnownLength() {
        XCTAsyncTest {
            var request = Request(url: "http://example.com/post")
            request.method = .POST
            let asyncSequence = ByteBuffer(string: "post body")
                .readableBytesView
                .uncheckedSendableChunks(ofCount: 2)
                .async
                .map { ByteBuffer($0) }

            request.body = .stream(asyncSequence, length: .known(Int64(9)))
            var preparedRequest: PreparedRequest?
            XCTAssertNoThrow(preparedRequest = try PreparedRequest(request))
            guard let preparedRequest = preparedRequest else { return }

            XCTAssertEqual(
                preparedRequest.poolKey,
                .init(
                    scheme: .http,
                    connectionTarget: .domain(name: "example.com", port: 80),
                    tlsConfiguration: nil,
                    serverNameIndicatorOverride: nil
                )
            )
            XCTAssertEqual(
                preparedRequest.head,
                .init(
                    version: .http1_1,
                    method: .POST,
                    uri: "/post",
                    headers: [
                        "host": "example.com",
                        "content-length": "9",
                    ]
                )
            )
            XCTAssertEqual(
                preparedRequest.requestFramingMetadata,
                .init(
                    connectionClose: false,
                    body: .fixedSize(9)
                )
            )
            guard let buffer = await XCTAssertNoThrowWithResult(try await preparedRequest.body.read()) else { return }
            XCTAssertEqual(buffer, .init(string: "post body"))
        }
    }
