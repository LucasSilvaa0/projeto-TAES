    func testVariableSymbolNotInlined() {
        let expression = Expression("5 + foo", options: .pureSymbols, symbols: [.variable("foo"): { _ in 5 }])
        XCTAssertEqual(expression.symbols, [.variable("foo"), .infix("+")])
        XCTAssertEqual(expression.description, "5 + foo")
    }
