    func testSubscriptPureIntVariable() {
        let expression = AnyExpression(Expression.parse("foo[0]"), pureSymbols: { symbol in
            symbol == .variable("foo") ? { _ in 5 } : nil
        })
        XCTAssertThrowsError(try expression.evaluate() as Any) { error in
            XCTAssertEqual(error as? Expression.Error, .typeMismatch(.array("foo"), [5, 0.0]))
        }
    }
