  func testPermissions() {
    // TODO: exhaustive tests

    XCTAssert(FilePermissions(rawValue: 0o664) == [.ownerReadWrite, .groupReadWrite, .otherRead])
    XCTAssert(FilePermissions(rawValue: 0o644) == [.ownerReadWrite, .groupRead, .otherRead])
    XCTAssert(FilePermissions(rawValue: 0o777) == [.otherReadWriteExecute, .groupReadWriteExecute, .ownerReadWriteExecute])

    // From the docs for FilePermissions
    do {
      let perms = FilePermissions(rawValue: 0o644)
      XCTAssert(perms == [.ownerReadWrite, .groupRead, .otherRead])
      XCTAssert(perms.contains(.ownerRead))
    }
  }
