    func testSurveyToPresentReturnsCorrectSurvey() {
        let settings: [String: Any] = [
            "surveys": [
                ["id": "1", "url": "https://example.com/survey1"],
                ["id": "2", "url": "https://example.com/survey2"]
            ]
        ]

        let survey = manager.surveyToPresent(settings: settings as PrivacyConfigurationData.PrivacyFeature.FeatureSettings)
        XCTAssertNotNil(survey)
        XCTAssertEqual(survey?.id, "1")
        XCTAssertEqual(survey?.url, "https://example.com/survey1")
    }
