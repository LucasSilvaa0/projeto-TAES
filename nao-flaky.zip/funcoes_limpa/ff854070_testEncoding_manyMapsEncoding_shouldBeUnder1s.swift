    func testEncoding_manyMapsEncoding_shouldBeUnder1s() {
        let repeats = 50000

        let child = (
            "repeated_message {\n"
            + "  map_fixed64_sint64 {\n"
            + "    key: 20\n"
            + "    value: 8\n"
            + "  }\n"
            + "  map_fixed64_sint64 {\n"
            + "    key: 30\n"
            + "    value: 4\n"
            + "  }\n"
            + "  map_fixed64_sint64 {\n"
            + "    key: 40\n"
            + "    value: 2\n"
            + "  }\n"
            + "}\n"
        )
        let expected = String(repeating: child, count: repeats)

        let msg = MessageTestType.with {
            let child = MessageTestType.with {
               $0.mapFixed64Sint64[20] = 8
               $0.mapFixed64Sint64[30] = 4
               $0.mapFixed64Sint64[40] = 2
            }
            let array = Array<MessageTestType>(repeating: child, count: repeats)
            $0.repeatedMessage = array
        }

        // Map fields used to trigger quadratic behavior, which meant
        // this encoding could take over 60s, but now it should
        // consistently take a fraction of a second. I've skipped
        // decoding here because decoding is much slower -- due to the
        // need to create a lot of objects -- which makes it much less
        // obvious when the encoding goes awry.
        let encoded = msg.textFormatString()
        XCTAssertEqual(expected, encoded)
    }
