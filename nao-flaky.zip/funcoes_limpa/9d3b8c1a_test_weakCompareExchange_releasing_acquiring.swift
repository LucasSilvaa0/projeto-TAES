  func test_weakCompareExchange_releasing_acquiring() {
    let v: UnsafeAtomic<Unmanaged<Bar>?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Unmanaged<Bar>?)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: nil,
        desired: _bar2,
        successOrdering: .releasing,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    (exchanged, original) = v.weakCompareExchange(
      expected: nil,
      desired: _bar2,
      successOrdering: .releasing,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _bar2,
        desired: nil,
        successOrdering: .releasing,
        failureOrdering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.weakCompareExchange(
      expected: _bar2,
      desired: nil,
      successOrdering: .releasing,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
