    func testWhenClearDataSwitchIsToggledThenTableIsUpdated() {
        let appSettings = AppUserDefaults()
        appSettings.autoClearAction = []
        
        guard let settingsController = AutoClearSettingsViewController.loadFromStoryboard(appSettings: appSettings) else {
                assertionFailure("Could not load View Controller")
                return
        }
        
        XCTAssertEqual(settingsController.numberOfSections(in: settingsController.tableView), 1)
        
        settingsController.loadViewIfNeeded()
        settingsController.clearDataToggle.isOn = true
        settingsController.clearDataToggle.sendActions(for: .valueChanged)
        
        XCTAssertEqual(settingsController.numberOfSections(in: settingsController.tableView), 3)
        
        settingsController.clearDataToggle.isOn = false
        settingsController.clearDataToggle.sendActions(for: .valueChanged)
        
        XCTAssertEqual(settingsController.numberOfSections(in: settingsController.tableView), 1)
    }
