    func testLoggerIsJustHoldingASinglePointer() {
        let expectedSize = MemoryLayout<UnsafeRawPointer>.size
        XCTAssertEqual(MemoryLayout<Logger>.size, expectedSize)
    }
