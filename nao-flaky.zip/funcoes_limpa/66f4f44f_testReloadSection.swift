    func testReloadSection() {
        makeUpdater([10, 20, 30])
        // After a reload, nothing else you do to this section has an effect.
        updater.update([.modify(index: 1,
                                changes: [
                                    .removeItem(index: 0),
                                    .updateItem(index: 1),
                                    .reloadSection,
                                    .updateItem(index: 1),
                                    .removeItem(index: 2)])])
        XCTAssertEqual(logger.log, [.reloadSections(IndexSet(integer: 1))])
    }
