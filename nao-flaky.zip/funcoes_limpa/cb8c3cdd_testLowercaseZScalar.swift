    func testLowercaseZScalar() {
        let char: Unicode.Scalar = "Z"
        XCTAssertEqual(char.lowercased(), "z")
    }
