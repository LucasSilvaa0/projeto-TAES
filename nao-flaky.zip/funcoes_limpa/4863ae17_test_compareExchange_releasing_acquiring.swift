  func test_compareExchange_releasing_acquiring() {
    let v: UnsafeAtomic<Int> = .create(12)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Int) = v.compareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .releasing,
      failureOrdering: .acquiring)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .releasing,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .releasing,
      failureOrdering: .acquiring)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .releasing,
      failureOrdering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)
  }
