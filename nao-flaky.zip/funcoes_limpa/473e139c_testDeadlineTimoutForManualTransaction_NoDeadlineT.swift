    func testDeadlineTimoutForManualTransaction_NoDeadlineTimeoutQueued() {
        let sut = fixture.getSut(waitForChildren: false, idleTimeout: 0.0)
        
        let invocationsBeforeFinish = fixture.dispatchQueue.dispatchAfterInvocations.count
        
        sut.finish()
        
        let invocationsAfterFinish = fixture.dispatchQueue.dispatchAfterInvocations.count
        
        XCTAssertEqual(invocationsBeforeFinish, invocationsAfterFinish)
    }
