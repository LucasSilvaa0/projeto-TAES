  func test_weakCompareExchange_acquiring() {
    let v: UnsafeAtomic<UnsafePointer<Foo>> = .create(_foo1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafePointer<Foo>)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _foo1,
        desired: _foo2,
        ordering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, _foo1)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo2)

    (exchanged, original) = v.weakCompareExchange(
      expected: _foo1,
      desired: _foo2,
      ordering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _foo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _foo2,
        desired: _foo1,
        ordering: .acquiring)
    } while !exchanged
    XCTAssertEqual(original, _foo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo1)

    (exchanged, original) = v.weakCompareExchange(
      expected: _foo2,
      desired: _foo1,
      ordering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _foo1)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo1)
  }
