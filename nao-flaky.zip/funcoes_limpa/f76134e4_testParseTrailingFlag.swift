    func testParseTrailingFlag() {
        XCTAssertThrowsError(try FormatString("foo %'")) { error in
            XCTAssertEqual(error as? FormatString.Error, .unexpectedEndOfString)
        }
    }
