    func testUncleanShutdownCancelsExecutingAndQueuedTasks() {
        let bin = HTTPBin(.http2(compress: false))
        defer { XCTAssertNoThrow(try bin.shutdown()) }
        let clientGroup = MultiThreadedEventLoopGroup(numberOfThreads: 1)
        defer { XCTAssertNoThrow(try clientGroup.syncShutdownGracefully()) }
        // we need an active connection to guarantee that requests are executed immediately
        // without waiting for connection establishment
        let client = self.makeClientWithActiveHTTP2Connection(to: bin, eventLoopGroupProvider: .shared(clientGroup))

        // start 20 requests which are guaranteed to never get any response
        // 10 of them will executed and the other 10 will be queued
        // because HTTPBin has a default `maxConcurrentStreams` limit of 10
        let responses = (0..<20).map { _ in
            client.get(url: "https://localhost:\(bin.port)/wait")
        }

        XCTAssertNoThrow(try client.syncShutdown())

        var results: [Result<HTTPClient.Response, Error>] = []
        XCTAssertNoThrow(
            results =
                try EventLoopFuture
                .whenAllComplete(responses, on: clientGroup.next())
                .timeout(after: .seconds(2))
                .wait()
        )

        for result in results {
            switch result {
            case .success:
                XCTFail("Shouldn't succeed")
            case .failure(let error):
                XCTAssertEqual(error as? HTTPClientError, .cancelled)
            }
        }
    }
