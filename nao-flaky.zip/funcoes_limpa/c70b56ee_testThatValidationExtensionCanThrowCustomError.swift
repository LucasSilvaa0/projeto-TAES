    func testThatValidationExtensionCanThrowCustomError() {
        // Given
        let endpoint = Endpoint()

        let expectation1 = expectation(description: "request should return 200 status code")
        let expectation2 = expectation(description: "download should return 200 status code")

        var requestError: AFError?
        var downloadError: AFError?

        // When
        AF.request(endpoint)
            .validate(with: ValidationError.missingData)
            .validate(with: ValidationError.missingFile) // should be ignored
            .response { resp in
                requestError = resp.error
                expectation1.fulfill()
            }

        AF.download(endpoint)
            .validate(with: ValidationError.missingFile)
            .validate(with: ValidationError.fileReadFailed) // should be ignored
            .response { resp in
                downloadError = resp.error
                expectation2.fulfill()
            }

        waitForExpectations(timeout: timeout)

        // Then
        XCTAssertEqual(requestError?.asAFError?.underlyingError as? ValidationError, .missingData)
        XCTAssertEqual(downloadError?.asAFError?.underlyingError as? ValidationError, .missingFile)
    }
