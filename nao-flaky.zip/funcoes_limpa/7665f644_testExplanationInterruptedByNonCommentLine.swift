    func testExplanationInterruptedByNonCommentLine() {
        let sources = [
            """
            // This is
            // the explanation
            thisIsNot()
            """,

            """
            // This is
            // the explanation

            // this is not
            thisIsNot()
            """,
        ]
        for source in sources {
            let snippet = Snippet(parsing: source, sourceFile: SnippetParseTests.fakeSourceFilename)
            XCTAssertEqual("This is\nthe explanation", snippet.explanation)
        }
    }
