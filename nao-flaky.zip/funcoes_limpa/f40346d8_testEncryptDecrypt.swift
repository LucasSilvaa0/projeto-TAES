    func testEncryptDecrypt() {
        // TestInMemorySignalProtocolStore aliceStore = new TestInMemorySignalProtocolStore();
        // TestInMemorySignalProtocolStore bobStore   = new TestInMemorySignalProtocolStore();
        // NOTE: We use MockClient to ensure consistency between of our session state.

        // initializeSessions(aliceStore, bobStore);
        initializeSessions(aliceMockClient: aliceMockClient, bobMockClient: bobMockClient)

        // ECKeyPair           trustRoot         = Curve.generateKeyPair();
        let trustRoot = IdentityKeyPair.generate()

        // SenderCertificate   senderCertificate = createCertificateFor(trustRoot, "+14151111111", 1, aliceStore.getIdentityKeyPair().getPublicKey().getPublicKey(), 31337);
        let senderCertificate = Self.createCertificateFor(
            trustRoot: trustRoot,
            senderAddress: aliceMockClient.sealedSenderAddress,
            identityKey: aliceMockClient.identityKeyPair.publicKey,
            expirationTimestamp: 31337
        )

        // SecretSessionCipher aliceCipher       = new SecretSessionCipher(aliceStore);
        let aliceCipher: SMKSecretSessionCipher = aliceMockClient.createSecretSessionCipher()

        // byte[] ciphertext = aliceCipher.encrypt(new SignalProtocolAddress("+14152222222", 1),
        // senderCertificate, "smert za smert".getBytes());
        // NOTE: The java tests don't bother padding the plaintext.
        let alicePlaintext = "smert za smert".data(using: .utf8)!
        let ciphertext = try! aliceCipher.encryptMessage(
            for: bobMockClient.aci,
            deviceId: bobMockClient.deviceId,
            paddedPlaintext: alicePlaintext,
            contentHint: .default,
            groupId: nil,
            senderCertificate: senderCertificate,
            protocolContext: NullContext()
        )

        // SealedSessionCipher bobCipher = new SealedSessionCipher(bobStore, new SignalProtocolAddress("+14152222222", 1));
        let bobCipher: SMKSecretSessionCipher = bobMockClient.createSecretSessionCipher()

        // Pair<SignalProtocolAddress, byte[]> plaintext = bobCipher.decrypt(new CertificateValidator(trustRoot.getPublicKey()), ciphertext, 31335);
        let bobPlaintext = try! bobCipher.decryptMessage(
            trustRoot: trustRoot.publicKey,
            cipherTextData: ciphertext,
            timestamp: 31335,
            localIdentifiers: bobMockClient.localIdentifiers,
            localDeviceId: .valid(bobMockClient.deviceId),
            protocolContext: nil
        )

        // assertEquals(new String(plaintext.second()), "smert za smert");
        // assertEquals(plaintext.first().getName(), "+14151111111");
        // assertEquals(plaintext.first().getDeviceId(), 1);
        XCTAssertEqual(String(data: bobPlaintext.paddedPayload, encoding: .utf8), "smert za smert")
        XCTAssertEqual(bobPlaintext.senderDeviceId, aliceMockClient.deviceId)
        XCTAssertEqual(bobPlaintext.senderAci, aliceMockClient.aci)
        XCTAssertEqual(bobPlaintext.senderE164, aliceMockClient.phoneNumber.stringValue)
    }
