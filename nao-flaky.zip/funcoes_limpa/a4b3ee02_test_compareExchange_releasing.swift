  func test_compareExchange_releasing() {
    let v: UnsafeAtomic<UnsafePointer<Foo>> = .create(_foo1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafePointer<Foo>) = v.compareExchange(
      expected: _foo1,
      desired: _foo2,
      ordering: .releasing)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _foo1)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo2)

    (exchanged, original) = v.compareExchange(
      expected: _foo1,
      desired: _foo2,
      ordering: .releasing)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _foo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo2)

    (exchanged, original) = v.compareExchange(
      expected: _foo2,
      desired: _foo1,
      ordering: .releasing)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _foo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo1)

    (exchanged, original) = v.compareExchange(
      expected: _foo2,
      desired: _foo1,
      ordering: .releasing)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _foo1)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo1)
  }
