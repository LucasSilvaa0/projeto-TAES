    func testMultiGroupThreadPrefix() {
        XCTAssert(
            MultiThreadedEventLoopGroup.singleton.description.contains("NIO-SGLTN-"),
            "\(MultiThreadedEventLoopGroup.singleton.description)"
        )

        for _ in 0..<100 {
            let someEL = MultiThreadedEventLoopGroup.singleton.next()
            XCTAssert(someEL.description.contains("NIO-SGLTN-"), "\(someEL.description)")
        }
    }
