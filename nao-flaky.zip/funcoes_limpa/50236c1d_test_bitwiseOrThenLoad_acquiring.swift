  func test_bitwiseOrThenLoad_acquiring() {
    let a: UInt32 = 3
    let b: UInt32 = 8
    let c: UInt32 = 12
    let result1: UInt32 = a | b
    let result2: UInt32 = result1 | c

    let v: UnsafeAtomic<UInt32> = .create(a)
    defer { v.destroy() }

    let new1: UInt32 = v.bitwiseOrThenLoad(with: b, ordering: .acquiring)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: UInt32 = v.bitwiseOrThenLoad(with: c, ordering: .acquiring)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
