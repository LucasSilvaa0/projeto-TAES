  func test_loadThenBitwiseXor_acquiring() {
    let a: UInt32 = 3
    let b: UInt32 = 8
    let c: UInt32 = 12
    let result1: UInt32 = a ^ b
    let result2: UInt32 = result1 ^ c

    let v: UnsafeAtomic<UInt32> = .create(a)
    defer { v.destroy() }

    let old1: UInt32 = v.loadThenBitwiseXor(with: b, ordering: .acquiring)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: UInt32 = v.loadThenBitwiseXor(with: c, ordering: .acquiring)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
