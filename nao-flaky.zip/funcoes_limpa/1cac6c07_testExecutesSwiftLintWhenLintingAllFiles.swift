    func testExecutesSwiftLintWhenLintingAllFiles() {
        let modified = [
            "Tests/SomeFile.swift",
            "Harvey/SomeOtherFile.swift",
            "Test Dir/SomeThirdFile.swift",
            "circle.yml",
        ]
        danger = githubWithFilesDSL(created: [], modified: modified, deleted: [], fileMap: [:])

        _ = SwiftLint.lint(lintStyle: .all(directory: nil),
                           danger: danger,
                           shellExecutor: executor,
                           swiftlintPath: "swiftlint",
                           currentPathProvider: fakePathProvider,
                           outputFilePath: "swiftlintReport.json",
                           readFile: mockedEmptyJSON)

        let swiftlintCommands = executor.invocations.filter { $0.command == "swiftlint" }
        XCTAssertEqual(swiftlintCommands.count, 1)
        XCTAssertEqual(swiftlintCommands.first!.environmentVariables.count, 0)
    }
