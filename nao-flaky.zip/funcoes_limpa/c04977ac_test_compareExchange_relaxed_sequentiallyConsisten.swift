  func test_compareExchange_relaxed_sequentiallyConsistent() {
    let v: UnsafeAtomic<Baz> = .create(_baz1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Baz) = v.compareExchange(
      expected: _baz1,
      desired: _baz2,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _baz1)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    (exchanged, original) = v.compareExchange(
      expected: _baz1,
      desired: _baz2,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz2)

    (exchanged, original) = v.compareExchange(
      expected: _baz2,
      desired: _baz1,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _baz2)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz1)

    (exchanged, original) = v.compareExchange(
      expected: _baz2,
      desired: _baz1,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _baz1)
    XCTAssertEqual(v.load(ordering: .relaxed), _baz1)
  }
