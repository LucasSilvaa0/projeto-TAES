  func test_weakCompareExchange_acquiringAndReleasing_relaxed() {
    let v: UnsafeAtomic<UnsafePointer<Foo>?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafePointer<Foo>?)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: nil,
        desired: _foo2,
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo2)

    (exchanged, original) = v.weakCompareExchange(
      expected: nil,
      desired: _foo2,
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _foo2)
    XCTAssertEqual(v.load(ordering: .relaxed), _foo2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _foo2,
        desired: nil,
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, _foo2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.weakCompareExchange(
      expected: _foo2,
      desired: nil,
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
