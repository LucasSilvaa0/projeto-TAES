  func testPushNotificationsDisabled() {
    let notificationType = SettingsNotificationCellViewModel.notificationFor(
      cellType: .projectUpdates,
      notificationType: .push
    )

    guard let notification = notificationType else {
      XCTFail("Notification cannot be nil")
      return
    }

    let user = User.template
      |> UserAttribute.notification(notification).keyPath .~ false

    let value = SettingsNotificationCellValue(cellType: .projectUpdates, user: user)

    self.vm.inputs.configure(with: value)

    self.pushNotificationsEnabled.assertValues([false], "Push notifications are disabled")
  }
