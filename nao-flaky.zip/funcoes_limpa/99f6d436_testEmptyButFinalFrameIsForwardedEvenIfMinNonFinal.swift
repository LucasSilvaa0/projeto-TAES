    func testEmptyButFinalFrameIsForwardedEvenIfMinNonFinalFragmentSizeIsGreaterThanZero() {
        let frame = WebSocketFrame(fin: true, opcode: .binary, data: ByteBuffer())
        XCTAssertNoThrow(try channel.writeInbound(frame))
        XCTAssertEqual(try channel.readInbound(as: WebSocketFrame.self), frame)
    }
