    func testSymbolGraphArguments() {
        do {
            let arguments = ParsedArguments(["--include-extended-types", "--experimental-skip-synthesized-symbols", "--symbol-graph-minimum-access-level", "internal"])
            
            XCTAssertEqual(arguments.symbolGraphArguments.includeExtendedTypes, true)
            XCTAssertEqual(arguments.symbolGraphArguments.skipSynthesizedSymbols, true)
            XCTAssertEqual(arguments.symbolGraphArguments.minimumAccessLevel, "internal")
        }
        
        do {
            let arguments = ParsedArguments(["--exclude-extended-types", "--experimental-skip-synthesized-symbols"])
            
            XCTAssertEqual(arguments.symbolGraphArguments.includeExtendedTypes, false)
            XCTAssertEqual(arguments.symbolGraphArguments.skipSynthesizedSymbols, true)
            XCTAssertNil(arguments.symbolGraphArguments.minimumAccessLevel)
        }
        
        do {
            let arguments = ParsedArguments(["--include-extended-types", "--experimental-skip-synthesized-symbols", "--exclude-extended-types"])
            
            XCTAssertEqual(arguments.symbolGraphArguments.includeExtendedTypes, false)
            XCTAssertEqual(arguments.symbolGraphArguments.skipSynthesizedSymbols, true)
            XCTAssertNil(arguments.symbolGraphArguments.minimumAccessLevel)
        }
        do {
            let arguments = ParsedArguments(["--exclude-extended-types", "--include-extended-types"])
            
            XCTAssertEqual(arguments.symbolGraphArguments.includeExtendedTypes, true)
            XCTAssertNil(arguments.symbolGraphArguments.skipSynthesizedSymbols)
            XCTAssertNil(arguments.symbolGraphArguments.minimumAccessLevel)
        }
    }
