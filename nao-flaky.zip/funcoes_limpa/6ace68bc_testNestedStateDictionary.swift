    func testNestedStateDictionary() {
        let node = LayoutNode(state: ["foo": ["bar": "baz"]])
        XCTAssertEqual(try node.value(forSymbol: "foo") as! [String: String], ["bar": "baz"])
        XCTAssertEqual(try node.value(forSymbol: "foo.bar") as? String, "baz")
    }
