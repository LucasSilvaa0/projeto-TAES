    func testPeekSlice_OutOfRange() {
        var buffer = ByteBuffer()
        buffer.writeRepeatingByte(0xFF, count: 3)
        // Request more bytes than available.
        let slice = buffer.peekSlice(length: 10)
        XCTAssertNil(slice, "Should return nil when requesting out-of-range slice.")
    }
