    func testTrailingParenThenSpace() {
        let expression = Expression("5) ")
        XCTAssertThrowsError(try expression.evaluate()) { error in
            XCTAssertEqual(error as? Expression.Error, .unexpectedToken(")"))
        }
    }
