  func testLoadingState() {
    self.dataSource.load([], paymentSheetCards: [], isLoading: true)

    XCTAssertEqual(3, self.dataSource.numberOfSections(in: self.tableView), "Sections padded")
    XCTAssertEqual(
      1,
      self.dataSource.numberOfItems(in: PaymentMethodsTableViewSection.loading.rawValue)
    )
    XCTAssertEqual(
      0,
      self.dataSource.numberOfItems(in: PaymentMethodsTableViewSection.paymentMethods.rawValue)
    )
    XCTAssertEqual(
      0,
      self.dataSource.numberOfItems(in: PaymentMethodsTableViewSection.addNewCard.rawValue)
    )
  }
