  func testPrepareDependencies_setsDependency() {
    prepareDependencies {
      $0.date = DateGenerator { Date(timeIntervalSinceReferenceDate: 0) }
    }
    @Dependency(\.date.now) var now
    XCTAssertEqual(now, Date(timeIntervalSinceReferenceDate: 0))
  }
