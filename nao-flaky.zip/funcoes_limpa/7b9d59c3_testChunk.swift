    func testChunk() {
        let examples: [Example] = [
            Example(arr: [], by: 2, expected: []),
            Example(arr: [1, 2], by: 0, expected: [[1], [2]]),
            Example(arr: [1, 2], by: 1, expected: [[1], [2]]),
            Example(arr: [1, 2, 3], by: 2, expected: [[1, 2], [3]]),
            Example(arr: [1, 2], by: 3, expected: [[1, 2]]),
            Example(arr: [1, 2, 3], by: 1, expected: [[1], [2], [3]]),
        ]
        for example in examples {
            // Turn the ArraySlices back into Arrays for comparison.
            let actual = chunk(example.arr as [Int], by: example.by).map { Array($0) }
            XCTAssertEqual(example.expected as NSArray, actual as NSArray) // wtf. why is XCTAssert being so weird
        }
    }
