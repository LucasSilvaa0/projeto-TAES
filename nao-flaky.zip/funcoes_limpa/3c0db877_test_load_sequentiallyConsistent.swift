  func test_load_sequentiallyConsistent() {
    let v: UnsafeAtomic<UnsafeMutablePointer<Foo>?> = .create(nil)
    defer { v.destroy() }
    XCTAssertEqual(v.load(ordering: .sequentiallyConsistent), nil)

    let w: UnsafeAtomic<UnsafeMutablePointer<Foo>?> = .create(_mfoo2)
    defer { w.destroy() }
    XCTAssertEqual(w.load(ordering: .sequentiallyConsistent), _mfoo2)
  }
