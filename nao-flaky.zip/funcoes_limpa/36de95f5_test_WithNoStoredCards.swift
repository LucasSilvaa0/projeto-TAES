  func test_WithNoStoredCards() {
    let variables = ["withStoredCards": false]
    do {
      let userFragment: GraphAPI.UserFragment = try testGraphObject(
        jsonString: validJSONWithNoStoredCards,
        variables: variables
      )

      XCTAssertTrue(UserCreditCards.userCreditCards(from: userFragment).storedCards.count == 0)
    } catch {
      XCTFail()
    }
  }
