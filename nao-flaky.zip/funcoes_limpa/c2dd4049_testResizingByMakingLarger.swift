    func testResizingByMakingLarger() {
        var base = NIOSSLSecureBytes(count: 12)
        XCTAssertGreaterThanOrEqual(base.backing.capacity, 16)
        XCTAssertEqual(base.count, 12)

        base.append(contentsOf: 0..<16)
        XCTAssertGreaterThanOrEqual(base.backing.capacity, 32)
        XCTAssertEqual(base.count, 28)

        base.append(contentsOf: 0..<4)
        XCTAssertGreaterThanOrEqual(base.backing.capacity, 32)
        XCTAssertEqual(base.count, 32)
    }
