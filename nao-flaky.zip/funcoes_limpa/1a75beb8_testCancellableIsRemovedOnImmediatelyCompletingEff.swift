  func testCancellableIsRemovedOnImmediatelyCompletingEffect() {
    let store = Store<Void, Void>(initialState: ()) {}

    XCTAssertEqual(store.rootStore.effectCancellables.count, 0)

    store.send(())

    XCTAssertEqual(store.rootStore.effectCancellables.count, 0)
  }
