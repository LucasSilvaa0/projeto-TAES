    func testThatPinningIntermediateKeyPassesEvaluationWithHostValidation() {
        // Given
        let host = "test.alamofire.org"
        let serverTrust = TestTrusts.leafValidDNSName.trust
        let keys = [TestCertificates.intermediateCA2].af.publicKeys
        let serverTrustPolicy = PublicKeysTrustEvaluator(keys: keys)

        // When
        setRootCertificateAsLoneAnchorCertificateForTrust(serverTrust)
        let result = Result { try serverTrustPolicy.evaluate(serverTrust, forHost: host) }

        // Then
        XCTAssertTrue(result.isSuccess, "server trust should pass evaluation")
    }
