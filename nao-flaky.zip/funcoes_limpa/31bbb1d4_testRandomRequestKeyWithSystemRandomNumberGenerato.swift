    func testRandomRequestKeyWithSystemRandomNumberGenerator() {
        XCTAssertEqual(
            NIOWebSocketClientUpgrader.randomRequestKey().count,
            24,
            "request key must be exactly 16 bytes long and this corresponds to 24 characters in base64"
        )
    }
