    func testStartOfConditionalStatementConditionContainingUnParenthesizedClosure() {
        let formatter = Formatter(tokenize("""
        if let btn = btns.first { !$0.isHidden } {}
        """))
        XCTAssertEqual(formatter.startOfConditionalStatement(at: 12), 0)
        XCTAssertEqual(formatter.startOfConditionalStatement(at: 21), 0)
    }
