  func testPredicate() {
    let result = (1...5).minAndMax(by: >)
    XCTAssertEqual(result?.min, 5)
    XCTAssertEqual(result?.max, 1)

    // Odd count
    let result2 = "gfabdec".minAndMax(by: >)
    XCTAssertEqual(result2?.min, "g")
    XCTAssertEqual(result2?.max, "a")
  }
