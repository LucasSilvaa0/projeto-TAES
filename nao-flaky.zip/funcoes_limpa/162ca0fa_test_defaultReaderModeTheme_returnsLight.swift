    func test_defaultReaderModeTheme_returnsLight() {
        themeManager.setManualTheme(to: .light)
        let defaultTheme = ReaderModeTheme.preferredTheme(for: nil, window: windowUUID)
        XCTAssertEqual(defaultTheme, .light, "Expected light theme (default) if not theme is selected")
    }
