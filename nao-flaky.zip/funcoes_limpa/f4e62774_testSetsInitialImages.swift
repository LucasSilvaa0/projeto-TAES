    func testSetsInitialImages() {
        let mockToolbar = MockTabToolbar()
        _ = TabToolbarHelper(toolbar: mockToolbar)
        XCTAssertEqual(mockToolbar.backButton.image(for: .normal), backButtonImage)
        XCTAssertEqual(mockToolbar.forwardButton.image(for: .normal), forwardButtonImage)
    }
