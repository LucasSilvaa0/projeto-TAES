    func testVerifyingCriticalExtensions_oneOf() {
        // When both policies specify the same exts, then the overall policy also has those exts
        XCTAssertEqual(
            Set(
                OneOfPolicies {
                    Policy(verifyingCriticalExtensions: [[1, 1]])
                    Policy(verifyingCriticalExtensions: [[1, 1]])
                }.verifyingCriticalExtensions
            ),
            [
                [1, 1]
            ]
        )
        // When both policies specify the different exts, the overall has the intersection
        XCTAssertEqual(
            Set(
                OneOfPolicies {
                    Policy(verifyingCriticalExtensions: [[1, 1], [1, 2]])
                    Policy(verifyingCriticalExtensions: [[1, 2], [1, 3]])
                }.verifyingCriticalExtensions
            ),
            [
                [1, 2]
            ]
        )
        // Here the sets are disjoint so the overall is empty
        XCTAssertEqual(
            Set(
                OneOfPolicies {
                    Policy(verifyingCriticalExtensions: [[1, 1], [1, 2]])
                    Policy(verifyingCriticalExtensions: [[1, 3], [1, 4]])
                }.verifyingCriticalExtensions
            ),
            []
        )
    }
