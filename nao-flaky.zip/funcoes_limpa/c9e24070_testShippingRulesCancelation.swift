  func testShippingRulesCancelation() {
    let mockService = MockService(fetchShippingRulesResult: Result.success(shippingRules))
    let reward = Reward.template
      |> Reward.lens.shipping.enabled .~ true

    let project = Project.template
      |> Project.lens.rewardData.rewards .~ [reward]

    withEnvironment(apiService: mockService, countryCode: "US") {
      self.vm.inputs.configureWith(data: (
        project: project,
        reward: reward,
        false,
        nil
      ))
      self.vm.inputs.viewDidLoad()

      guard let defaultShippingRule = shippingRules.first(where: { $0.location == .brooklyn }) else {
        XCTFail("Default shipping rule should exist")
        return
      }

      self.notifyDelegateOfSelectedShippingRule.assertDidNotEmitValue()

      self.scheduler.advance()

      self.notifyDelegateOfSelectedShippingRule.assertValues([defaultShippingRule])

      self.vm.inputs.shippingLocationButtonTapped()

      self.presentShippingRulesProject.assertValues([.template])
      self.presentShippingRulesAllRules.assertValues([shippingRules])
      self.presentShippingRulesSelectedRule.assertValues([defaultShippingRule])

      self.dismissShippingRules.assertDidNotEmitValue()
      self.vm.inputs.shippingRulesCancelButtonTapped()
      self.dismissShippingRules.assertValueCount(1)
    }
  }
