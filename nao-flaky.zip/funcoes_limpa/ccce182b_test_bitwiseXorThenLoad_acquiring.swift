  func test_bitwiseXorThenLoad_acquiring() {
    let a: UInt8 = 3
    let b: UInt8 = 8
    let c: UInt8 = 12
    let result1: UInt8 = a ^ b
    let result2: UInt8 = result1 ^ c

    let v: UnsafeAtomic<UInt8> = .create(a)
    defer { v.destroy() }

    let new1: UInt8 = v.bitwiseXorThenLoad(with: b, ordering: .acquiring)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: UInt8 = v.bitwiseXorThenLoad(with: c, ordering: .acquiring)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
