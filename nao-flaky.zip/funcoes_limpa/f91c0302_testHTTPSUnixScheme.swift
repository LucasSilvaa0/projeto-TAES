    func testHTTPSUnixScheme() {
        XCTAsyncTest {
            var request = Request(url: "https+unix://%2Fexample%2Ffolder.sock/some_path")
            request.headers = ["custom-header": "custom-value"]
            var preparedRequest: PreparedRequest?
            XCTAssertNoThrow(preparedRequest = try PreparedRequest(request))
            guard let preparedRequest = preparedRequest else { return }

            XCTAssertEqual(
                preparedRequest.poolKey,
                .init(
                    scheme: .httpsUnix,
                    connectionTarget: .unixSocket(path: "/example/folder.sock"),
                    tlsConfiguration: nil,
                    serverNameIndicatorOverride: nil
                )
            )
            XCTAssertEqual(
                preparedRequest.head,
                .init(
                    version: .http1_1,
                    method: .GET,
                    uri: "/some_path",
                    headers: ["custom-header": "custom-value"]
                )
            )
            XCTAssertEqual(
                preparedRequest.requestFramingMetadata,
                .init(
                    connectionClose: false,
                    body: .fixedSize(0)
                )
            )
            guard let buffer = await XCTAssertNoThrowWithResult(try await preparedRequest.body.read()) else { return }
            XCTAssertEqual(buffer, ByteBuffer())
        }
    }
