    func testWhenMobileUaAndDesktopTrueAndDefaultPolicyClosestThenFixedMobileAgentUsed() {
        let testee = UserAgent(defaultAgent: DefaultAgent.mobile)
        let config = makePrivacyConfig(from: closestConfig)
        XCTAssertEqual(ExpectedAgent.desktopClosest, testee.agent(forUrl: Constants.url, isDesktop: true, privacyConfig: config))
    }
