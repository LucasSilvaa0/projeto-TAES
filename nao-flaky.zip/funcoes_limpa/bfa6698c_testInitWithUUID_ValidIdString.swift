    func testInitWithUUID_ValidIdString() {
        let sentryId = SentryId(uuid: fixture.uuid)
        
        XCTAssertEqual(fixture.expectedUUIDV4String, sentryId.sentryIdString)
    }
