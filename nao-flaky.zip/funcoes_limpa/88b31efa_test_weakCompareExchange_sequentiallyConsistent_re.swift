  func test_weakCompareExchange_sequentiallyConsistent_relaxed() {
    let v: UnsafeAtomic<Unmanaged<Bar>> = .create(_bar1)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Unmanaged<Bar>)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _bar1,
        desired: _bar2,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, _bar1)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    (exchanged, original) = v.weakCompareExchange(
      expected: _bar1,
      desired: _bar2,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: _bar2,
        desired: _bar1,
        successOrdering: .sequentiallyConsistent,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar1)

    (exchanged, original) = v.weakCompareExchange(
      expected: _bar2,
      desired: _bar1,
      successOrdering: .sequentiallyConsistent,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _bar1)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar1)
  }
