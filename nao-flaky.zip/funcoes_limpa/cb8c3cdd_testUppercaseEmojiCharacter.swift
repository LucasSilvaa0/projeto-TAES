    func testUppercaseEmojiCharacter() {
        let char: Character = "👨‍👩‍👦‍👦"
        XCTAssertEqual(char.uppercased(), "👨‍👩‍👦‍👦")
    }
