    func testDidFailProvisionalNavigationWhenWebkitError() {
        let subject = createSubject()

        let webKitError = NSError(domain: "WebKitErrorDomain", code: 102, userInfo: nil)
        subject.webView(webView, didFailProvisionalNavigation: nil, withError: webKitError)

        XCTAssertEqual(sessionHandler.commitURLChangeCalled, 0)
        XCTAssertEqual(sessionHandler.receivedErrorCalled, 0)
    }
