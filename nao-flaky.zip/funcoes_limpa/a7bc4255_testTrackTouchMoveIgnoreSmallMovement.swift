    func testTrackTouchMoveIgnoreSmallMovement() {
        let sut = getSut()
        let event = MockUIEvent(timestamp: 2)
        let touch = MockUITouch(phase: .moved, location: CGPoint(x: 10, y: 10))
        event.addTouch(touch)
        sut.trackTouchFrom(event: event)
        
        event.timestamp = 3
        touch.location = CGPoint(x: 10, y: 9)
        sut.trackTouchFrom(event: event)
        
        let result = sut.replayEvents(from: referenceDate, until: referenceDate.addingTimeInterval(5))
        let data = result.first?.data
        let positions = data?["positions"] as? [[String: Any]]
        
        XCTAssertEqual(positions?.count, 1)
    }
