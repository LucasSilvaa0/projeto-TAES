    func testByteBufferDecodeWithInvalidCharacters() {
        let decoder = JSONDecoder()
        var encodedData = Data()
        encodedData.append(contentsOf: "\"SGVsbG8sIHdvcmxkI_==\"".utf8)
        XCTAssertThrowsError(try decoder.decode(ByteBuffer.self, from: encodedData)) { error in
            XCTAssertEqual(error as? Base64Error, .invalidCharacter)
        }
    }
