    func testDeletePendingReview() {
        let session = OctoKitURLTestSession(expectedURL: "https://api.github.com/repos/octocat/Hello-World/pulls/1/reviews/80", expectedHTTPMethod: "DELETE", jsonFile: "review", statusCode: 200)
        let task = Octokit(session: session).deletePendingReview(owner: "octocat",
                                                                 repository: "Hello-World",
                                                                 pullRequestNumber: 1,
                                                                 reviewId: 80) {
            switch $0 {
            case let .success(review):
                XCTAssertEqual(review.body, "Here is the body for the review.")
                XCTAssertEqual(review.commitID, "ecdd80bb57125d7ba9641ffaa4d7d2c19d3f3091")
                XCTAssertEqual(review.id, 80)
                XCTAssertEqual(review.state, .approved)
                XCTAssertEqual(review.submittedAt, Date(timeIntervalSince1970: 1_574_012_623.0))
                XCTAssertEqual(review.user.avatarURL, "https://github.com/images/error/octocat_happy.gif")
                XCTAssertNil(review.user.blog)
                XCTAssertNil(review.user.company)
                XCTAssertNil(review.user.email)
                XCTAssertEqual(review.user.gravatarID, "")
                XCTAssertEqual(review.user.id, 1)
                XCTAssertNil(review.user.location)
                XCTAssertEqual(review.user.login, "octocat")
                XCTAssertNil(review.user.name)
                XCTAssertNil(review.user.numberOfPublicGists)
                XCTAssertNil(review.user.numberOfPublicRepos)
                XCTAssertNil(review.user.numberOfPrivateRepos)
                XCTAssertEqual(review.user.type, "User")
            case .failure:
                XCTFail("should not get an error")
            }
        }
        XCTAssertNotNil(task)
        XCTAssertTrue(session.wasCalled)
    }
