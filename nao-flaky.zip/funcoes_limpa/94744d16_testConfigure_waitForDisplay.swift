    func testConfigure_waitForDisplay() {
        // -- Arrange --
        let sut = SentryPerformanceTrackingIntegration()

        // -- Act --
        let options = Options()
        options.tracesSampleRate = 0.1
        options.enableTimeToFullDisplayTracing = true
        sut.install(with: options)

        // -- Assert -- 
        let performanceTracker = SentryDependencyContainer.sharedInstance().uiViewControllerPerformanceTracker
        XCTAssertTrue(performanceTracker.alwaysWaitForFullDisplay)
    }
