    func testWhenFileExistsThenHasDataReturnsTrue() {
        let store = FileStore()
        XCTAssertFalse(store.hasData(for: .surrogates))
        
        XCTAssertNoThrow(try store.persist(Data(), for: .surrogates))
        XCTAssertTrue(store.hasData(for: .surrogates))
    }
