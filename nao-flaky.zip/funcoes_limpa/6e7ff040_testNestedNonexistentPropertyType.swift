    func testNestedNonexistentPropertyType() {
        let result = TestObject.allPropertyTypes()["testPoint.foo"]
        XCTAssertNil(result)
    }
