  func test_compareExchange_relaxed_sequentiallyConsistent() {
    let v: UnsafeAtomic<Unmanaged<Bar>?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Unmanaged<Bar>?) = v.compareExchange(
      expected: nil,
      desired: _bar2,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    (exchanged, original) = v.compareExchange(
      expected: nil,
      desired: _bar2,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), _bar2)

    (exchanged, original) = v.compareExchange(
      expected: _bar2,
      desired: nil,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _bar2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.compareExchange(
      expected: _bar2,
      desired: nil,
      successOrdering: .relaxed,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
