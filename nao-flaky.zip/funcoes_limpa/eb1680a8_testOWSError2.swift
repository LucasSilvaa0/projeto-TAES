    func testOWSError2() {
        let errorCode1: Int = 1001
        let errorDescription1: String = "Some copy."
        let isRetryable1: Bool = false
        let error1: Error = OWSError(errorCode: errorCode1, description: errorDescription1, isRetryable: isRetryable1)

        XCTAssertEqual((error1 as NSError).code, errorCode1)
        XCTAssertEqual((error1 as NSError).domain, OWSError.errorDomain)
        XCTAssertTrue(error1.hasUserErrorDescription)
        XCTAssertEqual(error1.userErrorDescription, errorDescription1)
        XCTAssertTrue(error1.hasIsRetryable)
        XCTAssertEqual(error1.isRetryable, isRetryable1)

        let nsError1: NSError = error1 as NSError
        XCTAssertEqual(nsError1.code, errorCode1)
        XCTAssertEqual(nsError1.domain, OWSError.errorDomain)
        XCTAssertTrue(nsError1.hasUserErrorDescription)
        XCTAssertEqual(nsError1.userErrorDescription, errorDescription1)
        XCTAssertTrue(nsError1.hasIsRetryable)
        XCTAssertEqual(nsError1.isRetryable, isRetryable1)

        do {
            try ErrorThrower(error: error1).performThrow()
            XCTFail("Thrower did not throw.")
        } catch {
            XCTAssertEqual((error as NSError).code, errorCode1)
            XCTAssertEqual((error as NSError).domain, OWSError.errorDomain)
            XCTAssertTrue(error.hasUserErrorDescription)
            XCTAssertEqual(error.userErrorDescription, errorDescription1)
            XCTAssertTrue(error.hasIsRetryable)
            XCTAssertEqual(error.isRetryable, isRetryable1)
        }

        do {
            try ErrorThrower(error: nsError1).performThrow()
            XCTFail("Thrower did not throw.")
        } catch {
            XCTAssertEqual((error as NSError).code, errorCode1)
            XCTAssertEqual((error as NSError).domain, OWSError.errorDomain)
            XCTAssertTrue(error.hasUserErrorDescription)
            XCTAssertEqual(error.userErrorDescription, errorDescription1)
            XCTAssertTrue(error.hasIsRetryable)
            XCTAssertEqual(error.isRetryable, isRetryable1)
        }
    }
