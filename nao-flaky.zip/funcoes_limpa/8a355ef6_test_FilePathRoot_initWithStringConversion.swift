  func test_FilePathRoot_initWithStringConversion() {
    #if os(Windows)
    let source = "C:\\\0 and the rest"
    #else // unix
    let source = "/\0 and the rest"
    #endif
    var root: FilePath.Root?
    root = FilePath.Root(platformString: source)
    source.withPlatformString {
      XCTAssertEqual(root, FilePath.Root(platformString: $0))
    }
    root = FilePath.Root(platformString: "")
    XCTAssertNil(root)
  }
