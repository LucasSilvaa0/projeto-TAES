    func testAllocatedCohortMatchesCurrentCohorts() {
        PixelExperiment.customLogic = PixelExperimentLogic(fire: { _ in }, customCohort: .control)

        let matches = !PixelExperiment.allocatedCohortDoesNotMatchCurrentCohorts

        XCTAssertTrue(matches, "The allocated cohort should match")
    }
