  func test_wrappingDecrementThenLoad_sequentiallyConsistent() {
    let a: Int = 3
    let b: Int = 8
    let c: Int = 12
    let result1: Int = a &- b
    let result2: Int = result1 &- c

    let v: UnsafeAtomic<Int> = .create(a)
    defer { v.destroy() }

    let new1: Int = v.wrappingDecrementThenLoad(by: b, ordering: .sequentiallyConsistent)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: Int = v.wrappingDecrementThenLoad(by: c, ordering: .sequentiallyConsistent)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
