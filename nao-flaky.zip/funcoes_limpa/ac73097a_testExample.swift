    func testExample() {
        XCTAssertEqual(11, try parser.required(key: "some_int"))
        XCTAssertEqual(11, try parser.optional(key: "some_int"))

        let expectedString: String = "asdf"
        XCTAssertEqual(expectedString, try parser.required(key: "some_string"))
        XCTAssertEqual(expectedString, try parser.optional(key: "some_string"))

        XCTAssertEqual(nil, try parser.optional(key: "does_not_exist") as String?)
        XCTAssertThrowsError(try parser.required(key: "does_not_exist") as String)
    }
