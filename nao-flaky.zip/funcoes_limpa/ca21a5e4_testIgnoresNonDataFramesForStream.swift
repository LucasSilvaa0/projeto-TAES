    func testIgnoresNonDataFramesForStream() {
        let streamOne = HTTP2StreamID(1)
        self.buffer.streamCreated(streamOne, initialWindowSize: 15)

        // Let's start by consuming the window.
        let frame = self.createDataFrame(streamOne, byteBufferSize: 15)
        XCTAssertNoThrow(try self.buffer.processOutboundFrame(frame, promise: nil).assertNothing())
        self.buffer.flushReceived()
        self.receivedFrames().assertFramesMatch([frame])

        // Now we send another data frame to buffer.
        XCTAssertNoThrow(try self.buffer.processOutboundFrame(frame, promise: nil).assertNothing())

        // We also send a WindowUpdate frame, a RST_STREAM frame, and a PRIORITY frame.
        let windowUpdateFrame = HTTP2Frame(streamID: streamOne, payload: .windowUpdate(windowSizeIncrement: 500))
        let priorityFrame = HTTP2Frame(
            streamID: streamOne,
            payload: .priority(.init(exclusive: false, dependency: 0, weight: 50))
        )
        let rstStreamFrame = HTTP2Frame(streamID: streamOne, payload: .rstStream(.protocolError))

        // All of these frames are written.
        XCTAssertNoThrow(try self.buffer.processOutboundFrame(windowUpdateFrame, promise: nil).assertForward())
        XCTAssertNoThrow(try self.buffer.processOutboundFrame(priorityFrame, promise: nil).assertForward())
        XCTAssertNoThrow(try self.buffer.processOutboundFrame(rstStreamFrame, promise: nil).assertForward())

        // But the DATA frame is not.
        XCTAssertEqual(self.receivedFrames().count, 0)

        // Even when we flush.
        self.buffer.flushReceived()
        XCTAssertEqual(self.receivedFrames().count, 0)

        // Unless we open the window.
        self.buffer.updateWindowOfStream(1, newSize: 20)
        self.buffer.flushReceived()
        self.receivedFrames().assertFramesMatch([frame])
    }
