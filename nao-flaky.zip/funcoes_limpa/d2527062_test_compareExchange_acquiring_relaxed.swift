  func test_compareExchange_acquiring_relaxed() {
    let v: UnsafeAtomic<UInt> = .create(12)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UInt) = v.compareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    (exchanged, original) = v.compareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .acquiring,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)
  }
