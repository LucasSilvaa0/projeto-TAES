    func testAppendingPathWhenPathEndsWithSlash() {
        XCTAssertEqual("/usr/".appendingPath("f-meloni"), "/usr/f-meloni")
    }
