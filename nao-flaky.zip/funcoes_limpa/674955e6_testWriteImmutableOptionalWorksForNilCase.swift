    func testWriteImmutableOptionalWorksForNilCase() {
        self.buf.writeString("hello")
        var startingWithNil: ByteBuffer? = nil
        let bytesWritten = startingWithNil.setOrWriteImmutableBuffer(self.buf)
        XCTAssertEqual(5, bytesWritten)
        XCTAssertEqual(self.buf, startingWithNil)
    }
