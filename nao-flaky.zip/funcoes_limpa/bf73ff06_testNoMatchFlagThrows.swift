    func testNoMatchFlagThrows() {
        let input = ["", "-v"]
        XCTAssertThrowsError(try preprocessArguments(input, [
            "help", "file",
        ]))
    }
