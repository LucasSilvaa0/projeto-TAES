  func testProjects() {
    let projects = (1...3).map { .template |> Project.lens.id .~ $0 }
    let projectsWithNewProject = (1...4).map { .template |> Project.lens.id .~ $0 }
    let projectsWithNewestProject = (1...5).map { .template |> Project.lens.id .~ $0 }
    let env = FetchProjectsEnvelope(type: .backed, projects: projects, hasNextPage: true, totalCount: 5)
    let env2 = FetchProjectsEnvelope(
      type: .backed,
      projects: projectsWithNewProject,
      hasNextPage: true,
      totalCount: 5
    )
    let env3 = FetchProjectsEnvelope(
      type: .backed,
      projects: projectsWithNewestProject,
      hasNextPage: false,
      totalCount: 5
    )

    withEnvironment(apiService: MockService(fetchBackerBackedProjectsResponse: env), currentUser: .template) {
      self.vm.inputs.configureWith(projectsType: .backed, sort: .endingSoon)
      self.vm.inputs.viewDidAppear(false)
      self.vm.inputs.currentUserUpdated()

      self.projects.assertValueCount(0)
      self.emptyStateIsVisible.assertValueCount(0)
      self.isRefreshing.assertValues([true])

      XCTAssertEqual([], self.segmentTrackingClient.events)
      XCTAssertEqual([], self.segmentTrackingClient.properties(forKey: "type", as: String.self))

      self.scheduler.advance()

      self.projects.assertValues([projects])
      self.emptyStateIsVisible.assertValues([false])
      self.emptyStateProjectsType.assertValues([.backed])
      self.isRefreshing.assertValues([true, false])

      self.vm.inputs.viewDidAppear(true)
      self.isRefreshing.assertValues([true, false], "Projects don't refresh.")

      self.scheduler.advance()

      self.projects.assertValues([projects])
      self.emptyStateIsVisible.assertValues([false])
      self.isRefreshing.assertValues([true, false], "Projects don't refresh.")

      let updatedUser = User.template |> \.stats.backedProjectsCount .~ 1

      // Come back after backing a project.
      withEnvironment(
        apiService: MockService(fetchBackerBackedProjectsResponse: env2),
        currentUser: updatedUser
      ) {
        self.vm.inputs.currentUserUpdated()
        self.vm.inputs.viewDidAppear(false)

        self.isRefreshing.assertValues([true, false, true])

        self.scheduler.advance()

        self.projects.assertValues([projects, projectsWithNewProject])
        self.emptyStateIsVisible.assertValues([false, false])
        self.isRefreshing.assertValues([true, false, true, false])
      }

      // Refresh.
      withEnvironment(
        apiService: MockService(fetchBackerBackedProjectsResponse: env3),
        currentUser: updatedUser
      ) {
        self.vm.inputs.refresh()

        self.isRefreshing.assertValues([true, false, true, false, true])

        self.scheduler.advance()

        self.projects.assertValues([projects, projectsWithNewProject, projectsWithNewestProject])
        self.emptyStateIsVisible.assertValues([false, false, false])
        self.isRefreshing.assertValues([true, false, true, false, true, false])
      }
    }
  }
