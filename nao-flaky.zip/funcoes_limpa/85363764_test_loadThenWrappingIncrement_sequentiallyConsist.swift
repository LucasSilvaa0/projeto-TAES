  func test_loadThenWrappingIncrement_sequentiallyConsistent() {
    let a: UInt64 = 3
    let b: UInt64 = 8
    let c: UInt64 = 12
    let result1: UInt64 = a &+ b
    let result2: UInt64 = result1 &+ c

    let v: UnsafeAtomic<UInt64> = .create(a)
    defer { v.destroy() }

    let old1: UInt64 = v.loadThenWrappingIncrement(by: b, ordering: .sequentiallyConsistent)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: UInt64 = v.loadThenWrappingIncrement(by: c, ordering: .sequentiallyConsistent)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
