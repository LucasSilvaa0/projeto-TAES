    func testBuildThreadsWithEmptyCallStack() {
        let wrapper = SentryUseNSExceptionCallstackWrapper(name: NSExceptionName(rawValue: "Exception Name"), reason: "Exception Reason", userInfo: [:], callStackReturnAddresses: [])
        
        let threads = wrapper.buildThreads()
        
        XCTAssertEqual(threads.count, 1)
        let thread = threads[0]
        XCTAssertNotNil(thread.stacktrace)
        XCTAssertEqual(thread.stacktrace?.frames.count, 0)
    }
