    func testMessagesDeletedOnThreadDeletion() {
        write { tx -> Void in
            let body = "So long, and thanks for all the fish!"

            let messages = (0..<10).map { idx -> TSIncomingMessage in
                let newMessage: TSIncomingMessage = TSIncomingMessageBuilder
                    .withDefaultValues(
                        thread: thread,
                        timestamp: UInt64(idx) + 1,
                        authorAci: otherAci,
                        messageBody: AttachmentContentValidatorMock.mockValidatedBody(body)
                    ).build()
                newMessage.anyInsert(transaction: tx)
                return newMessage
            }

            for (idx, message) in messages.enumerated() {
                guard let fetchedMessage = TSIncomingMessage.anyFetchIncomingMessage(
                    uniqueId: message.uniqueId,
                    transaction: tx
                ) else {
                    XCTFail("Failed to find inserted message!")
                    return
                }

                XCTAssertEqual(body, fetchedMessage.body)
                XCTAssertEqual(message.uniqueId, fetchedMessage.uniqueId)
                XCTAssertEqual(UInt64(idx + 1), fetchedMessage.timestamp)
                XCTAssertFalse(fetchedMessage.wasRead)
                XCTAssertEqual(thread.uniqueId, fetchedMessage.uniqueThreadId)
            }

            DependenciesBridge.shared.threadSoftDeleteManager
                .softDelete(threads: [thread], sendDeleteForMeSyncMessage: false, tx: tx)

            for message in messages {
                XCTAssertNil(TSIncomingMessage.anyFetchIncomingMessage(
                    uniqueId: message.uniqueId,
                    transaction: tx
                ))
            }

            XCTAssertEqual(0, numberOfInteractions(thread: thread, tx: tx))
        }
    }
