  func test_compareExchange_acquiring() {
    let v: UnsafeAtomic<UnsafeMutableRawPointer?> = .create(nil)
    defer { v.destroy() }

    var (exchanged, original): (Bool, UnsafeMutableRawPointer?) = v.compareExchange(
      expected: nil,
      desired: _mraw2,
      ordering: .acquiring)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    (exchanged, original) = v.compareExchange(
      expected: nil,
      desired: _mraw2,
      ordering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    (exchanged, original) = v.compareExchange(
      expected: _mraw2,
      desired: nil,
      ordering: .acquiring)
    XCTAssertTrue(exchanged)
    XCTAssertEqual(original, _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    (exchanged, original) = v.compareExchange(
      expected: _mraw2,
      desired: nil,
      ordering: .acquiring)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)
  }
