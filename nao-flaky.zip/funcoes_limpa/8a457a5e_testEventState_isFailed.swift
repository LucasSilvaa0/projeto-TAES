    func testEventState_isFailed() {
        XCTAssertFalse(queue.activityIsFailed(.activityEvent))
        queue.started(.activityEvent)
        XCTAssertFalse(queue.activityIsFailed(.activityEvent))
        queue.failed(.activityEvent)
        XCTAssertTrue(queue.activityIsFailed(.activityEvent))
    }
