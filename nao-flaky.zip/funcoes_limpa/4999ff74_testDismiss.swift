  func testDismiss() {
    self.app.buttons["Toggle feature 1 on"].tap()
    XCTAssertEqual(self.app.staticTexts["FEATURE 1"].exists, true)
    self.clearLogs()
    self.app.buttons["Dismiss"].tap()
    XCTAssertEqual(self.app.staticTexts["FEATURE 1"].exists, false)
    self.assertLogs {
      """
      EnumView.body
      ViewStore<EnumView.ViewState, EnumView.Feature.Action>.deinit
      ViewStore<EnumView.ViewState, EnumView.Feature.Action>.init
      ViewStoreOf<EnumView.Feature.Destination?>.deinit
      ViewStoreOf<EnumView.Feature.Destination?>.init
      WithViewStore<EnumView.ViewState, EnumView.Feature.Action>.body
      WithViewStoreOf<EnumView.Feature.Destination?>.body
      """
    }
  }
