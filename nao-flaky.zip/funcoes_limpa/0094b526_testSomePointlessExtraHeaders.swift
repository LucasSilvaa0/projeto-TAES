    func testSomePointlessExtraHeaders() {
        let s = "foo: bar\r\nContent-Length: 4\r\nbuz: qux\r\n\r\n1234"
        XCTAssertNoThrow(try self.channel.writeInbound(self.buffer(string: s)))
        XCTAssertNoThrow(try XCTAssertEqual("1234", self.readInboundString()))
    }
