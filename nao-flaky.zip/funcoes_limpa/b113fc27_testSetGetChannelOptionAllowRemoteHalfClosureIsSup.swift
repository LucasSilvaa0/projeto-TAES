    func testSetGetChannelOptionAllowRemoteHalfClosureIsSupported() {
        let channel = EmbeddedChannel()
        let options = channel.syncOptions
        XCTAssertNotNil(options)

        // allowRemoteHalfClosure should be false by default
        XCTAssertEqual(try options?.getOption(.allowRemoteHalfClosure), false)

        channel.allowRemoteHalfClosure = true
        XCTAssertEqual(try options?.getOption(.allowRemoteHalfClosure), true)

        XCTAssertNoThrow(try options?.setOption(.allowRemoteHalfClosure, value: false))
        XCTAssertEqual(try options?.getOption(.allowRemoteHalfClosure), false)
    }
