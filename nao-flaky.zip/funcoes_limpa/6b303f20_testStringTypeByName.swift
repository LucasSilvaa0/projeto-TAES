    func testStringTypeByName() {
        guard let runtimeType = RuntimeType.type(named: "String") else {
            XCTFail()
            return
        }
        guard case let .any(type) = runtimeType.kind else {
            XCTFail()
            return
        }
        XCTAssert(type == String.self)
        XCTAssert(runtimeType.swiftType == String.self)
    }
