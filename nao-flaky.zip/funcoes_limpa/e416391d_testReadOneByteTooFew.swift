    func testReadOneByteTooFew() {
        buffer.writeInteger(UInt8(2))
        buffer.writeString("AB")
        XCTAssertEqual(
            try buffer.readLengthPrefixed(as: UInt8.self) { buffer -> String? in
                var buffer = buffer
                return buffer.readString(length: buffer.readableBytes - 1)
            },
            "A"
        )
    }
