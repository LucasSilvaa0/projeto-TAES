    func test4EnsureSchemeIncludedAutocompletion() {
        navigator.openURL(websiteExample["url"]!)
        waitUntilPageLoad()
        navigator.goto(URLBarOpen)
        urlBarAddress.typeText("ex")
        if #available(iOS 16, *) {
            mozWaitForValueContains(urlBarAddress, value: "example.com")
            let value = urlBarAddress.value
            XCTAssertEqual(value as? String, "example.com", "Wrong autocompletion")
        }
    }
