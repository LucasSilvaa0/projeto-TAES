    func testUnexpectedToken() {
        let parser: Consumer<String> = ["foo", "bar"]
        let input = "foofoobar"
        XCTAssertThrowsError(try parser.match(input)) { error in
            let error = error as! Consumer<String>.Error
            switch error.kind {
            case .expected("bar"):
                XCTAssertEqual(error.location?.offset.column, 4)
            default:
                XCTFail()
            }
            XCTAssertEqual(error.description, "Unexpected token 'foobar' at 1:4 (expected 'bar')")
        }
    }
