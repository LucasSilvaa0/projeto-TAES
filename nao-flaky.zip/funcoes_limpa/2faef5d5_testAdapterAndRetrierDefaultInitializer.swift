    func testAdapterAndRetrierDefaultInitializer() {
        // Given
        let adapter = Adapter { urlRequest, _, completion in completion(.success(urlRequest)) }
        let retrier = Retrier { _, _, _, completion in completion(.doNotRetry) }

        // When
        let interceptor = Interceptor(adapter: adapter, retrier: retrier)

        // Then
        XCTAssertEqual(interceptor.adapters.count, 1)
        XCTAssertEqual(interceptor.retriers.count, 1)
    }
