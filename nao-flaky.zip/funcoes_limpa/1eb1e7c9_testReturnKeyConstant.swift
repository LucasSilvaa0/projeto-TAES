    func testReturnKeyConstant() {
        let expected = UIReturnKeyType.go
        let node = LayoutNode(
            view: UITextField(),
            constants: [
                "type": expected,
            ],
            expressions: [
                "returnKeyType": "type",
            ]
        )
        XCTAssertEqual(try node.value(forSymbol: "returnKeyType") as? UIReturnKeyType, expected)
    }
