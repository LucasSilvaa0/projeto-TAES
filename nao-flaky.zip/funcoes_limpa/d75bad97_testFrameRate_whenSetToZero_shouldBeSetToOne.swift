    func testFrameRate_whenSetToZero_shouldBeSetToOne() {
        // -- Arrange --
        let options = SentryReplayOptions()
        
        // -- Act --
        options.frameRate = 0
        
        // -- Assert --
        XCTAssertEqual(options.frameRate, 1)
    }
