  func test_exchange_sequentiallyConsistent() {
    let v: UnsafeAtomic<UnsafeMutableRawPointer?> = .create(nil)
    defer { v.destroy() }

    XCTAssertEqual(v.exchange(nil, ordering: .sequentiallyConsistent), nil)
    XCTAssertEqual(v.load(ordering: .relaxed), nil)

    XCTAssertEqual(v.exchange(_mraw2, ordering: .sequentiallyConsistent), nil)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    XCTAssertEqual(v.exchange(_mraw2, ordering: .sequentiallyConsistent), _mraw2)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)
  }
