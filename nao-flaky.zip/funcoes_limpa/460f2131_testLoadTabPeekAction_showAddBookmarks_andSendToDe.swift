    func testLoadTabPeekAction_showAddBookmarks_andSendToDevice() {
        let initialState = createSubject()
        let reducer = tabPeekReducer()

        XCTAssertEqual(initialState.showAddToBookmarks, false)
        XCTAssertEqual(initialState.showSendToDevice, false)

        let action = getAction(for: .loadTabPeek)
        let newState = reducer(initialState, action)

        XCTAssertEqual(newState.showAddToBookmarks, true)
        XCTAssertEqual(newState.showSendToDevice, true)
    }
