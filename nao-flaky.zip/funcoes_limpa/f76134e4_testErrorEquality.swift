    func testErrorEquality() {
        XCTAssertNotEqual(FormatString.Error.unexpectedEndOfString, .missingArgument(1))
        XCTAssertNotEqual(FormatString.Error.unexpectedToken("a"), .unexpectedEndOfString)
        XCTAssertNotEqual(FormatString.Error.duplicateFlag("a"), .unexpectedEndOfString)
        XCTAssertNotEqual(FormatString.Error.unsupportedFlag("a"), .unexpectedEndOfString)
        XCTAssertNotEqual(FormatString.Error.unsupportedSpecifier("a"), .unexpectedEndOfString)
        XCTAssertNotEqual(FormatString.Error.modifierMismatch("a", "a"), .unexpectedEndOfString)
        XCTAssertNotEqual(FormatString.Error.typeMismatch(1, Any.self, Any.self), .unexpectedEndOfString)
        XCTAssertNotEqual(FormatString.Error.argumentMismatch(1, Any.self, Any.self), .unexpectedEndOfString)
        XCTAssertNotEqual(FormatString.Error.missingArgument(3), .unexpectedEndOfString)
    }
