    func testInitWithUUIDV4String_ValidIdString() {
        let spanIdWithUUIDString = SpanId(value: fixture.uuidV4String)
        let spanIdWithUUID = SpanId(uuid: fixture.uuid)
        
        XCTAssertEqual(spanIdWithUUID, spanIdWithUUIDString)
    }
