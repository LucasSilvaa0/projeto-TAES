    func testWhenCompleteBlockingSuccess() {
        let eventLoop = EmbeddedEventLoop()
        let sem = DispatchSemaphore(value: 0)
        let nonBlockingRan = NIOLockedValueBox(false)
        let p = eventLoop.makePromise(of: String.self)
        p.futureResult.whenCompleteBlocking(onto: DispatchQueue.global()) { _ in
            sem.wait()  // Block in callback
            XCTAssertTrue(nonBlockingRan.withLockedValue { $0 })
        }
        p.succeed("hello")

        let p2 = eventLoop.makePromise(of: Bool.self)
        p2.futureResult.whenSuccess { _ in
            nonBlockingRan.withLockedValue { $0 = true }
        }
        p2.succeed(true)

        sem.signal()
    }
