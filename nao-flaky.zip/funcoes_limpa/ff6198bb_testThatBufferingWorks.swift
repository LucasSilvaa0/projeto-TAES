    func testThatBufferingWorks() {
        self.connect()

        let writePromise = self.channel.eventLoop.makePromise(of: Void.self)
        self.channel.writeAndFlush(ByteBuffer(bytes: [1, 2, 3, 4, 5]), promise: writePromise)
        self.assertOutputBuffer([0x05, 0x01, 0x00])
        self.writeInbound([0x05, 0x00])
        self.assertOutputBuffer([0x05, 0x01, 0x00, 0x01, 192, 168, 1, 1, 0x00, 0x50])
        self.writeInbound([0x05, 0x00, 0x00, 0x01, 192, 168, 1, 1, 0x00, 0x50])

        XCTAssertNoThrow(try writePromise.futureResult.wait())
        self.assertOutputBuffer([1, 2, 3, 4, 5])
    }
