    func testInferNoFractionGrouping() {
        let input = "[1.00002, 1.0001, 1.103, 0.23, 0.50]"
        let options = inferFormatOptions(from: tokenize(input))
        XCTAssertFalse(options.fractionGrouping)
    }
