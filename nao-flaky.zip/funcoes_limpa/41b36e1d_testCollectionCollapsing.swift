  func testCollectionCollapsing() {
    let largeArray = Array(1...1_000)
    var other = largeArray
    other[100] = 42
    other[102] = 42
    other.insert(42, at: 300)
    other.remove(at: 700)

    XCTAssertNoDifference(
      diff(largeArray, other),
      """
        [
          … (100 unchanged),
      -   [100]: 101,
      +   [100]: 42,
          [101]: 102,
      -   [102]: 103,
      +   [102]: 42,
          … (197 unchanged),
      +   [300]: 42,
          … (399 unchanged),
      -   [699]: 700,
          … (300 unchanged)
        ]
      """
    )
  }
