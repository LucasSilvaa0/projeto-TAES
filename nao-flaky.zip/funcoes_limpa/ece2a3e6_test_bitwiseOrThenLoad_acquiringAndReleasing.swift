  func test_bitwiseOrThenLoad_acquiringAndReleasing() {
    let a: Int16 = 3
    let b: Int16 = 8
    let c: Int16 = 12
    let result1: Int16 = a | b
    let result2: Int16 = result1 | c

    let v: UnsafeAtomic<Int16> = .create(a)
    defer { v.destroy() }

    let new1: Int16 = v.bitwiseOrThenLoad(with: b, ordering: .acquiringAndReleasing)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: Int16 = v.bitwiseOrThenLoad(with: c, ordering: .acquiringAndReleasing)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
