    func testIsInFutureWithPastDate() {
        let sut = SentryDateUtil(currentDateProvider: currentDateProvider)
        
        XCTAssertFalse(sut.is(inFuture: currentDateProvider.date().addingTimeInterval(-1)))
   }
