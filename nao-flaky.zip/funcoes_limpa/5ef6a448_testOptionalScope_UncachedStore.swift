  func testOptionalScope_UncachedStore() {
    let store = StoreOf<Feature>(initialState: Feature.State(child: Feature.State())) {
    }

    XCTExpectFailure {
      _ =
        store
        .scope(state: { $0 }, action: { $0 })
        .scope(state: \.child, action: \.child.presented)?
        .send(.show)
    } issueMatcher: {
      $0.compactDescription == """
        failed - Scoping from uncached StoreOf<Feature> is not compatible with observation.

        This can happen for one of two reasons:

        • A parent view scopes on a store using transform functions, which has been deprecated, \
        instead of with key paths and case paths. Read the migration guide for 1.5 to update these \
        scopes: https://pointfreeco.github.io/swift-composable-architecture/main/documentation/\
        composablearchitecture/migratingto1.5

        • A parent feature is using deprecated navigation APIs, such as 'IfLetStore', \
        'SwitchStore', 'ForEachStore', or any navigation view modifiers taking stores instead of \
        bindings. Read the migration guide for 1.7 to update those APIs: \
        https://pointfreeco.github.io/swift-composable-architecture/main/documentation/\
        composablearchitecture/migratingto1.7
        """
    }
    store.send(.child(.dismiss))
  }
