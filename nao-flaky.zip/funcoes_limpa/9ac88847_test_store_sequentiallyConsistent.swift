  func test_store_sequentiallyConsistent() {
    let v: UnsafeAtomic<UnsafeMutableRawPointer?> = .create(nil)
    defer { v.destroy() }
    v.store(_mraw2, ordering: .sequentiallyConsistent)
    XCTAssertEqual(v.load(ordering: .relaxed), _mraw2)

    let w: UnsafeAtomic<UnsafeMutableRawPointer?> = .create(_mraw2)
    defer { w.destroy() }
    w.store(nil, ordering: .sequentiallyConsistent)
    XCTAssertEqual(w.load(ordering: .relaxed), nil)
  }
