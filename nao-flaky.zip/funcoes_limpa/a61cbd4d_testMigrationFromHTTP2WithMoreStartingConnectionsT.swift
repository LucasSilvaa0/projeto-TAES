    func testMigrationFromHTTP2WithMoreStartingConnectionsThanMaximumAllowedConccurentConnections() {
        let elg = EmbeddedEventLoopGroup(loops: 4)
        let generator = HTTPConnectionPool.Connection.ID.Generator()
        var connections = HTTPConnectionPool.HTTP1Connections(
            maximumConcurrentConnections: 2,
            generator: generator,
            maximumConnectionUses: nil
        )

        let el1 = elg.next()
        let el2 = elg.next()
        let el3 = elg.next()

        let conn1ID = generator.next()
        let conn2ID = generator.next()
        let conn3ID = generator.next()

        connections.migrateFromHTTP2(
            starting: [(conn1ID, el1), (conn2ID, el2), (conn3ID, el3)],
            backingOff: []
        )

        // first two connections should be added as general purpose connections
        let conn1: HTTPConnectionPool.Connection = .__testOnly_connection(id: conn1ID, eventLoop: el1)
        let (_, context1) = connections.newHTTP1ConnectionEstablished(conn1)
        XCTAssertEqual(context1.use, .generalPurpose)
        XCTAssertTrue(context1.eventLoop === el1)
        let conn2: HTTPConnectionPool.Connection = .__testOnly_connection(id: conn2ID, eventLoop: el2)
        let (_, context2) = connections.newHTTP1ConnectionEstablished(conn2)
        XCTAssertEqual(context2.use, .generalPurpose)
        XCTAssertTrue(context2.eventLoop === el2)

        // additional connection should be added as overflow connection
        let conn3: HTTPConnectionPool.Connection = .__testOnly_connection(id: conn3ID, eventLoop: el3)
        let (_, context3) = connections.newHTTP1ConnectionEstablished(conn3)
        XCTAssertEqual(context3.use, .eventLoop(el3))
        XCTAssertTrue(context3.eventLoop === el3)
    }
