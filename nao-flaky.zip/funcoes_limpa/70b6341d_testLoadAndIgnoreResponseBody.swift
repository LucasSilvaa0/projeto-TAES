    func testLoadAndIgnoreResponseBody() {
        let session = RequestKitURLTestSession(expectedURL: "https://example.com/some_route", expectedHTTPMethod: "POST", response: nil, statusCode: 204)

        var receivedSuccessResponse = false

        let task = TestInterface().loadAndIgnoreResponseBody(session) { response in
            switch response {
            case .success:
                receivedSuccessResponse = true
            case .failure:
                XCTAssert(false, "should not retrieve a failure response")
            }
        }

        XCTAssertNotNil(task)
        XCTAssertTrue(session.wasCalled)
        XCTAssertTrue(receivedSuccessResponse)
    }
