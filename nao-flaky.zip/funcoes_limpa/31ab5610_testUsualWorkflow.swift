    func testUsualWorkflow() {

        // create state machine and immediately connect
        var stateMachine = ClientStateMachine()
        XCTAssertTrue(stateMachine.shouldBeginHandshake)
        XCTAssertNoThrow(XCTAssertEqual(try stateMachine.connectionEstablished(), .sendGreeting))
        XCTAssertFalse(stateMachine.proxyEstablished)

        // send the client greeting
        XCTAssertNoThrow(try stateMachine.sendClientGreeting(.init(methods: [.noneRequired])))
        XCTAssertFalse(stateMachine.shouldBeginHandshake)
        XCTAssertFalse(stateMachine.proxyEstablished)

        // provide the given server greeting, check what to do next
        var serverGreeting = ByteBuffer(bytes: [0x05, 0x00])
        XCTAssertNoThrow(XCTAssertEqual(try stateMachine.receiveBuffer(&serverGreeting), .sendRequest))
        XCTAssertFalse(stateMachine.shouldBeginHandshake)
        XCTAssertFalse(stateMachine.proxyEstablished)

        // finish authentication
        XCTAssertFalse(stateMachine.shouldBeginHandshake)
        XCTAssertFalse(stateMachine.proxyEstablished)

        // send the client request
        XCTAssertNoThrow(
            try stateMachine.sendClientRequest(
                .init(command: .bind, addressType: .address(try! .init(ipAddress: "192.168.1.1", port: 80)))
            )
        )
        XCTAssertFalse(stateMachine.shouldBeginHandshake)
        XCTAssertFalse(stateMachine.proxyEstablished)

        // recieve server response
        var serverResponse = ByteBuffer(bytes: [0x05, 0x00, 0x00, 0x01, 0x01, 0x02, 0x03, 0x04, 0x00, 0x50])
        XCTAssertNoThrow(XCTAssertEqual(try stateMachine.receiveBuffer(&serverResponse), .proxyEstablished))

        // proxy should be good to go
        XCTAssertFalse(stateMachine.shouldBeginHandshake)
        XCTAssertTrue(stateMachine.proxyEstablished)
    }
