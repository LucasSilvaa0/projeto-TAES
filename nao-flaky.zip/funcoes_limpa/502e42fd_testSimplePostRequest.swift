    func testSimplePostRequest() {
        XCTAsyncTest {
            let loop = NIOAsyncTestingEventLoop()
            defer { XCTAssertNoThrow(try loop.syncShutdownGracefully()) }

            var request = HTTPClientRequest(url: "https://localhost/")
            request.method = .POST
            request.body = .bytes("Hello world!".utf8, length: .unknown)
            var maybePreparedRequest: PreparedRequest?
            XCTAssertNoThrow(maybePreparedRequest = try PreparedRequest(request))
            guard let preparedRequest = maybePreparedRequest else {
                return XCTFail("Expected to have a request here.")
            }
            let (transaction, responseTask) = await Transaction.makeWithResultTask(
                request: preparedRequest,
                preferredEventLoop: loop
            )

            let executor = MockRequestExecutor(eventLoop: loop)
            executor.runRequest(transaction)
            await loop.run()
            executor.resumeRequestBodyStream()
            XCTAssertNoThrow(
                try executor.receiveRequestBody {
                    XCTAssertEqual($0.getString(at: 0, length: $0.readableBytes), "Hello world!")
                }
            )
            XCTAssertNoThrow(try executor.receiveEndOfStream())

            let responseHead = HTTPResponseHead(version: .http1_1, status: .ok, headers: ["foo": "bar"])
            transaction.receiveResponseHead(responseHead)
            transaction.succeedRequest(nil)

            let response = try await responseTask.value
            XCTAssertEqual(response.status, .ok)
            XCTAssertEqual(response.version, .http1_1)
            XCTAssertEqual(response.headers, ["foo": "bar"])
        }
    }
