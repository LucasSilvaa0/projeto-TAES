  func testNameSynopsis() {
    XCTAssertEqual(Name.long("foo").synopsisString, "--foo")
    XCTAssertEqual(Name.short("f").synopsisString, "-f")
    XCTAssertEqual(Name.longWithSingleDash("foo").synopsisString, "-foo")
  }
