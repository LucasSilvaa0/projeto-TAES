    func testOmnibarAccessoryWhenAIChatFeatureDisabled() {
        let settings = MockAIChatSettingsProvider()
        settings.isAIChatFeatureEnabled = false
        let handler = OmnibarAccessoryHandler(settings: settings, featureFlagger: mockFeatureFlagger)

        let accessoryType = handler.omnibarAccessory(for: OmnibarAccessoryHandlerTests.DDGSearchURL)

        XCTAssertEqual(accessoryType, OmniBar.AccessoryType.share)
    }
