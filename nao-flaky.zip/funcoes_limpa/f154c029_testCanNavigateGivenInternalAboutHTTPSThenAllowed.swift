    func testCanNavigateGivenInternalAboutHTTPSThenAllowed() {
        let url = URL(string: "https://mozilla.com")!
        let context = BrowsingContext(type: .internalNavigation,
                                      url: url)
        let subject = createSubject()

        let result = subject.canNavigateWith(browsingContext: context)

        XCTAssertEqual(result, .allowed)
    }
