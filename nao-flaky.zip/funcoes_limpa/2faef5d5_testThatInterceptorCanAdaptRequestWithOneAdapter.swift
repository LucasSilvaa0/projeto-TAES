    func testThatInterceptorCanAdaptRequestWithOneAdapter() {
        // Given
        let urlRequest = Endpoint().urlRequest
        let session = Session()

        let adapter = Adapter { _, _, completion in completion(.failure(MockError())) }
        let interceptor = Interceptor(adapters: [adapter])

        var result: Result<URLRequest, any Error>!

        // When
        interceptor.adapt(urlRequest, for: session) { result = $0 }

        // Then
        XCTAssertTrue(result.isFailure)
        XCTAssertTrue(result.failure is MockError)
    }
