  func testNSAttributedString() {
    let attributedString = NSMutableAttributedString(string: "")
    attributedString.append(NSAttributedString(string: "Hello, "))
    attributedString.append(
      NSAttributedString(string: "Blob", attributes: [.init(rawValue: "name"): true])
    )
    attributedString.append(NSAttributedString(string: "!"))
    var dump = ""
    customDump(
      attributedString,
      to: &dump
    )
    XCTAssertNoDifference(
      dump,
      """
      "Hello, Blob!"
      """
    )
  }
