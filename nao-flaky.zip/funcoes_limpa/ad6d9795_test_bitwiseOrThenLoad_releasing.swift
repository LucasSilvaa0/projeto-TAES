  func test_bitwiseOrThenLoad_releasing() {
    let a: UInt = 3
    let b: UInt = 8
    let c: UInt = 12
    let result1: UInt = a | b
    let result2: UInt = result1 | c

    let v: UnsafeAtomic<UInt> = .create(a)
    defer { v.destroy() }

    let new1: UInt = v.bitwiseOrThenLoad(with: b, ordering: .releasing)
    XCTAssertEqual(new1, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let new2: UInt = v.bitwiseOrThenLoad(with: c, ordering: .releasing)
    XCTAssertEqual(new2, result2)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
