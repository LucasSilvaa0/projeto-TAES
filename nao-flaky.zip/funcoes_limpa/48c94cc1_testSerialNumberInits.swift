    func testSerialNumberInits() {
        XCTAssertEqual(Certificate.SerialNumber(bytes: [0, 1, 2, 3, 4, 5, 6, 7, 8]).bytes, [1, 2, 3, 4, 5, 6, 7, 8])
        XCTAssertEqual(
            Certificate.SerialNumber(bytes: [0, 1, 2, 3, 4, 5, 6, 7, 8][...]).bytes,
            [1, 2, 3, 4, 5, 6, 7, 8]
        )
        XCTAssertEqual(
            Certificate.SerialNumber(bytes: AnyCollection([0, 1, 2, 3, 4, 5, 6, 7, 8])).bytes,
            [1, 2, 3, 4, 5, 6, 7, 8]
        )
    }
