  func testUpdateUserDefaultsWithFeature_FeatureIsEnabled() {
    let mockRemoteConfigClient = MockRemoteConfigClient()
      |> \.features .~ [
        RemoteConfigFeature.editPledgeOverTimeEnabled.rawValue: false
      ]

    withEnvironment(remoteConfigClient: mockRemoteConfigClient) {
      self.vm.inputs.viewDidLoad()

      self.scheduler.advance()

      self.updateUserDefaultsWithFeatures.assertDidNotEmitValue()

      self.vm.inputs.setFeatureAtIndexEnabled(index: 0, isEnabled: true)

      self.scheduler.advance()

      let (_, isEnabled1) = self.updateUserDefaultsWithFeatures.values[0][0]

      XCTAssertTrue(isEnabled1)
    }
  }
