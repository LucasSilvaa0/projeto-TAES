    func testWhenAtbIsOldThenCohortIsGeneralizedForAppRetention() {

        store.atb = "v117-2"
        store.appRetentionAtb = "v117-2"

        let waitForCompletion = expectation(description: "wait for completion")
        loader.refreshAppRetentionAtb {
            waitForCompletion.fulfill()
        }

        wait(for: [waitForCompletion], timeout: 5.0)

        XCTAssertNotNil(store.appRetentionAtb)
        XCTAssertEqual(store.atb, "v117-1")
    }
