    func testTriggerUserOutboundEvent() {
        let event = "user event"
        channel.triggerUserOutboundEvent(event, promise: nil)
        XCTAssertEqual(lastEvent, .triggerUserOutboundEvent(event: event))
    }
