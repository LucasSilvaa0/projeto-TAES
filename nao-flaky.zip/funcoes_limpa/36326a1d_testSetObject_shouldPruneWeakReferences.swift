    func testSetObject_shouldPruneWeakReferences() {
        // -- Arrange --
        let map = SentryWeakMap<TestKey, TestValue>()
        var key1: TestKey? = TestKey()
        let value1 = TestValue()
        map.setObject(value1, forKey: key1)

        let key2 = TestKey()
        let value2A = TestValue()
        let value2B = TestValue()
        map.setObject(value2A, forKey: key2)

        // Deallocate key1, which should remove the weak reference to value1
        key1 = nil
        let sizeBeforePrune = map.count()

        // -- Act --
        map.setObject(value2B, forKey: key2)
        let sizeAfterPrune = map.count()

        // -- Assert --
        XCTAssertEqual(sizeBeforePrune, 2)
        XCTAssertEqual(sizeAfterPrune, 1)
    }
