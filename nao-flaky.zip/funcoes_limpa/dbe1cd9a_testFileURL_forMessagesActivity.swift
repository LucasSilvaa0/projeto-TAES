    func testFileURL_forMessagesActivity() {
        let testActivityType = UIActivity.ActivityType.message

        let urlActivityItemProvider = URLActivityItemProvider(url: testFileURL, allowSentFromFirefoxTreatment: false)
        let urlDataIdentifier = urlActivityItemProvider.activityViewController(
            createStubActivityViewController(),
            dataTypeIdentifierForActivityType: testActivityType
        )
        let itemForActivity = urlActivityItemProvider.activityViewController(
            createStubActivityViewController(),
            itemForActivityType: testActivityType
        )

        XCTAssertEqual(urlDataIdentifier, UTType.fileURL.identifier)
        XCTAssertEqual(itemForActivity as? URL, testFileURL)
    }
