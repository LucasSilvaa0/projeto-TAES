    func testDTM_privateModeEnabled_originalThemeRemainsAccessibleAfterChange() {
        let sut = createSubject(with: userDefaults)
        let expectedResult = ThemeType.light
        let currentThemeExpectedResult = ThemeType.privateMode

        sut.setManualTheme(to: .dark)
        sut.setPrivateTheme(isOn: true, for: windowUUID)
        sut.setManualTheme(to: .light)

        XCTAssertEqual(sut.getCurrentTheme(for: windowUUID).type, currentThemeExpectedResult)
        XCTAssertEqual(sut.getUserManualTheme(), expectedResult)
    }
