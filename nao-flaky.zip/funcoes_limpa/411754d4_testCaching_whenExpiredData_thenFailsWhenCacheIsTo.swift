    func testCaching_whenExpiredData_thenFailsWhenCacheIsTooOld() {
        let data = getData(from: tiles)
        let response = getResponse(from: 200)
        let request = getRequest()
        let subject = createSubject()
        subject.cache(response: response, for: request, with: data)

        subject.fetchTiles(timestamp: Date.tomorrow.toTimestamp()) { result in
            switch result {
            case let .failure(error as UnifiedAdsProvider.Error):
                XCTAssertEqual(error, UnifiedAdsProvider.Error.noDataAvailable)
            default:
                XCTFail("Expected failure, got \(result) instead")
            }
        }
    }
