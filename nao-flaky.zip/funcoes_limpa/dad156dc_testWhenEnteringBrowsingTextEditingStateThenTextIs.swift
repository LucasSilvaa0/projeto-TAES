    func testWhenEnteringBrowsingTextEditingStateThenTextIsMaintained() {
        let testee = SmallOmniBarState.BrowsingTextEditingState(dependencies: MockOmnibarDependency(voiceSearchHelper: enabledVoiceSearchHelper, featureFlagger: mockFeatureFlagger), isLoading: false)
        XCTAssertFalse(testee.clearTextOnStart)
    }
