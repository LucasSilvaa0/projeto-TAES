  func test_weakCompareExchange_acquiringAndReleasing_sequentiallyConsistent() {
    let v: UnsafeAtomic<DoubleWord> = .create(DoubleWord(first: 100, second: 64))
    defer { v.destroy() }

    var (exchanged, original): (Bool, DoubleWord)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: DoubleWord(first: 100, second: 64),
        desired: DoubleWord(first: 50, second: 32),
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, DoubleWord(first: 100, second: 64))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 50, second: 32))

    (exchanged, original) = v.weakCompareExchange(
      expected: DoubleWord(first: 100, second: 64),
      desired: DoubleWord(first: 50, second: 32),
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, DoubleWord(first: 50, second: 32))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 50, second: 32))

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: DoubleWord(first: 50, second: 32),
        desired: DoubleWord(first: 100, second: 64),
        successOrdering: .acquiringAndReleasing,
        failureOrdering: .sequentiallyConsistent)
    } while !exchanged
    XCTAssertEqual(original, DoubleWord(first: 50, second: 32))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 100, second: 64))

    (exchanged, original) = v.weakCompareExchange(
      expected: DoubleWord(first: 50, second: 32),
      desired: DoubleWord(first: 100, second: 64),
      successOrdering: .acquiringAndReleasing,
      failureOrdering: .sequentiallyConsistent)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, DoubleWord(first: 100, second: 64))
    XCTAssertEqual(v.load(ordering: .relaxed), DoubleWord(first: 100, second: 64))
  }
