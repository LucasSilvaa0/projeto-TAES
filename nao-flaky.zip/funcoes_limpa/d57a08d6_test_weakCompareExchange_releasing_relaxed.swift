  func test_weakCompareExchange_releasing_relaxed() {
    let v: UnsafeAtomic<Int8> = .create(12)
    defer { v.destroy() }

    var (exchanged, original): (Bool, Int8)
    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: 12,
        desired: 23,
        successOrdering: .releasing,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    (exchanged, original) = v.weakCompareExchange(
      expected: 12,
      desired: 23,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 23)

    repeat {
      (exchanged, original) = v.weakCompareExchange(
        expected: 23,
        desired: 12,
        successOrdering: .releasing,
        failureOrdering: .relaxed)
    } while !exchanged
    XCTAssertEqual(original, 23)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)

    (exchanged, original) = v.weakCompareExchange(
      expected: 23,
      desired: 12,
      successOrdering: .releasing,
      failureOrdering: .relaxed)
    XCTAssertFalse(exchanged)
    XCTAssertEqual(original, 12)
    XCTAssertEqual(v.load(ordering: .relaxed), 12)
  }
