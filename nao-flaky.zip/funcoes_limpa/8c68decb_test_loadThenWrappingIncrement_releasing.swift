  func test_loadThenWrappingIncrement_releasing() {
    let a: UInt16 = 3
    let b: UInt16 = 8
    let c: UInt16 = 12
    let result1: UInt16 = a &+ b
    let result2: UInt16 = result1 &+ c

    let v: UnsafeAtomic<UInt16> = .create(a)
    defer { v.destroy() }

    let old1: UInt16 = v.loadThenWrappingIncrement(by: b, ordering: .releasing)
    XCTAssertEqual(old1, a)
    XCTAssertEqual(v.load(ordering: .relaxed), result1)

    let old2: UInt16 = v.loadThenWrappingIncrement(by: c, ordering: .releasing)
    XCTAssertEqual(old2, result1)
    XCTAssertEqual(v.load(ordering: .relaxed), result2)
  }
